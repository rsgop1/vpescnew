import os

TELEGRAM_BOT_TOKEN = os.environ.get('TELEGRAM_BOT_TOKEN', '')
TELEGRAM_GROUP_ID = int(os.environ.get('TELEGRAM_GROUP_ID', '0'))
TELEGRAM_CHANNEL_ID = int(os.environ.get('TELEGRAM_CHANNEL_ID', '0'))
TELEGRAM_ADMIN_ID = int(os.environ.get('TELEGRAM_ADMIN_ID', '0'))

ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'admin')
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', '')
JWT_SECRET = os.environ.get('JWT_SECRET', '')

ADMIN_UPI_ID = os.environ.get('ADMIN_UPI_ID', '')
ADMIN_LTC_ADDRESS = os.environ.get('ADMIN_LTC_ADDRESS', '')

DEFAULT_FEE_PERCENT = 1.0
DATABASE_URL = os.environ.get('DATABASE_URL', '')

# ─── AI Dispute Judge (OpenRouter) ─────────────────────────────────────────────
OPENROUTER_API_KEY = os.environ.get('OPENROUTER_API_KEY', '')
AI_JUDGE_MODEL = os.environ.get('AI_JUDGE_MODEL', 'nvidia/nemotron-3-nano-omni-30b-a3b-reasoning:free')
# Deals at/below this amount get fully auto-resolved by the AI when it's confident.
# Larger deals still get an AI verdict + reasoning, but require admin confirmation.
AI_AUTO_THRESHOLD = int(os.environ.get('AI_AUTO_THRESHOLD', '200'))
AI_AUTO_CONFIDENCE_MIN = int(os.environ.get('AI_AUTO_CONFIDENCE_MIN', '65'))
