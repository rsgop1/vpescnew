"""Vault-Pay Escrow Bot — v3 Complete Rewrite (bug-free, clean flow)"""
import asyncio, json, logging, random, re
from datetime import datetime, timezone, timedelta

from telegram import (
    Update, InlineKeyboardButton, InlineKeyboardMarkup,
    BotCommand, BotCommandScopeAllPrivateChats, BotCommandScopeAllGroupChats,
)
from telegram.constants import ParseMode, ChatType
from telegram.ext import (
    Application, ApplicationBuilder, CommandHandler, CallbackQueryHandler,
    MessageHandler, ContextTypes, filters,
)
from telegram.error import BadRequest, Forbidden

import db
from config import (
    TELEGRAM_BOT_TOKEN, TELEGRAM_GROUP_ID, TELEGRAM_CHANNEL_ID,
    TELEGRAM_ADMIN_ID, ADMIN_UPI_ID, DEFAULT_FEE_PERCENT,
)

log = logging.getLogger(__name__)

# ─── In-memory state ──────────────────────────────────────────────────────────
DRAFT: dict[int, dict] = {}           # user_id → deal creation draft
WALLET_STATE: dict[int, dict] = {}    # user_id → wallet flow state
PIN_AWAIT: dict[int, str] = {}         # user_id → deal_id (awaiting PIN)
DISPUTE_AWAIT: dict[int, str] = {}     # user_id → deal_id (awaiting dispute text)
RELAY: dict[int, dict] = {}            # user_id → {deal_id, other_id, role}
MM_STATE: dict = {}                    # deal_id → middleman deal state dict
MM_DM_AWAIT: dict[int, dict] = {}     # user_id → {role, deal_id, step}
CUSTOM_TOC_AWAIT: dict[int, bool] = {}  # user_id → True (waiting for custom ToS text in group)
VOUCH_PROOF_AWAIT: dict[int, dict] = {} # user_id → {vouch_id, target_id, target_un, proofs}
EVIDENCE_AWAIT: dict[int, dict] = {}   # user_id → {deal_id, count} (dispute evidence collection)
NUDGED: set = set()                     # deal_ids already nudged this session
DISPUTE_DONE: dict[str, set] = {}       # deal_id → set of user_ids who typed "done" on evidence

_bot_app: Application | None = None
_bot_username: str = ""


# ─── Helpers ──────────────────────────────────────────────────────────────────

def kb(rows: list) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        [[InlineKeyboardButton(t, callback_data=d) for t, d in row] for row in rows]
    )


def esc(text) -> str:
    """Escape text for MarkdownV2."""
    if text is None:
        return ""
    chars = r"\_*[]()~`>#+-=|{}.!"
    return "".join(f"\\{c}" if c in chars else c for c in str(text))


def escn(n, fmt=None) -> str:
    """Format a number and escape for MarkdownV2 (handles decimal dots)."""
    s = f"{n:{fmt}}" if fmt else str(n)
    return esc(s)


async def safe_edit(msg, text: str, markup=None):
    """Edit a message, swallowing benign errors."""
    try:
        await msg.edit_text(
            text, parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=markup, disable_web_page_preview=True,
        )
    except BadRequest as e:
        if "not modified" not in str(e).lower():
            log.warning(f"safe_edit: {e}")
    except Exception as e:
        log.warning(f"safe_edit: {e}")


async def try_delete(msg):
    """Delete a message silently."""
    try:
        await msg.delete()
    except Exception:
        pass


async def _auto_delete(msg, seconds: int = 5):
    """Auto-delete a message after N seconds (fire-and-forget)."""
    await asyncio.sleep(seconds)
    await try_delete(msg)


async def send_temp_reply(msg, text: str, seconds: int = 5):
    """Send a reply that auto-deletes after N seconds."""
    try:
        sent = await msg.reply_text(text, parse_mode=ParseMode.MARKDOWN_V2)
        asyncio.create_task(_auto_delete(sent, seconds))
    except Exception:
        pass


async def qans(q, text: str = None, alert: bool = False):
    """Safely answer a callback query — NEVER throws. Use everywhere."""
    try:
        if text:
            await q.answer(text, show_alert=alert)
        else:
            await q.answer()
    except Exception:
        pass


async def send_dm(user_id: int, text: str, markup=None,
                  parse_mode=ParseMode.MARKDOWN_V2):
    """Send a DM silently (handles blocked/not-started)."""
    if not _bot_app:
        return False
    try:
        await _bot_app.bot.send_message(
            user_id, text, parse_mode=parse_mode,
            reply_markup=markup, disable_web_page_preview=True,
        )
        return True
    except (Forbidden, BadRequest) as e:
        log.warning(f"DM {user_id} failed: {e}")
        return False
    except Exception as e:
        log.warning(f"DM {user_id} failed: {e}")
        return False


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def compute_fee(amount: int, fee_pct: float, fee_payer: str):
    fee_amt = round(amount * fee_pct / 100)
    if fee_payer == "buyer":
        return amount + fee_amt, amount, fee_amt
    else:
        return amount, amount - fee_amt, fee_amt


async def get_fee_pct() -> float:
    v = await db.get_setting("fee_percent", DEFAULT_FEE_PERCENT)
    try:
        return float(v)
    except Exception:
        return float(DEFAULT_FEE_PERCENT)


async def get_default_toc() -> str:
    v = await db.get_setting("default_toc", "")
    return v or "Standard escrow: Funds held by middleman and released only on buyer confirmation. No chargebacks."


# ─── Deal card builders ────────────────────────────────────────────────────────

STEPS = ["role", "product", "amount", "fee", "toc", "payment", "mention", "waiting"]
STEP_PROGRESS = {
    "role":    "🟢⚪⚪⚪⚪⚪⚪  Step 1/7",
    "product": "🟢🟢⚪⚪⚪⚪⚪  Step 2/7",
    "amount":  "🟢🟢🟢⚪⚪⚪⚪  Step 3/7",
    "fee":     "🟢🟢🟢🟢⚪⚪⚪  Step 4/7",
    "toc":     "🟢🟢🟢🟢🟢⚪⚪  Step 5/7",
    "payment": "🟢🟢🟢🟢🟢🟢⚪  Step 6/7",
    "mention": "🟢🟢🟢🟢🟢🟢🟢  Step 7/7",
    "waiting": "✅✅✅✅✅✅✅  Awaiting counterparty",
}


def build_draft_card(d: dict) -> tuple[str, InlineKeyboardMarkup | None]:
    """Build the group message for each deal creation step."""
    step = d.get("step", "role")
    role = d.get("role", "")
    role_emoji = "💰" if role == "buyer" else "📦" if role == "seller" else ""
    role_label = "Buyer" if role == "buyer" else "Seller" if role == "seller" else ""
    progress = esc(STEP_PROGRESS.get(step, ""))

    header = f"🏦 *VAULT\\-PAY ESCROW*\n{progress}\n"

    # ── Step 1: Role ──────────────────────────────────────────────────────────
    if step == "role":
        return (
            header + "\nSelect your role in this deal:\n\n"
            "💰 *Buyer* — you will be paying\n"
            "📦 *Seller* — you will be receiving",
            kb([
                [("💰 I'm the Buyer", "esc:role:buyer"),
                 ("📦 I'm the Seller", "esc:role:seller")],
                [("❌ Cancel", "esc:cancel")],
            ])
        )

    info = f"\n{role_emoji} *Role:* {esc(role_label)}"

    # ── Step 2: Product Name ───────────────────────────────────────────────────
    if step == "product":
        return (
            header + info + "\n\n"
            "📦 *What is the product/service being traded?*\n"
            "_Type the name \\(e\\.g\\. Netflix Premium 1 Month, PUBG UC 3600\\)_",
            kb([[("❌ Cancel", "esc:cancel")]])
        )

    if d.get("product_name"):
        info += f"  \\|  📦 {esc(d['product_name'][:20])}"
    if d.get("amount"):
        info += f"  \\|  *₹{d['amount']:,}*"

    # ── Step 3: Amount ────────────────────────────────────────────────────────
    if step == "amount":
        return (
            header + info + "\n\n"
            "💬 *Type the deal amount in INR* \\(numbers only\\):\n"
            "_e\\.g\\. 5000_",
            kb([[("❌ Cancel", "esc:cancel")]])
        )

    # ── Step 4: Fee ───────────────────────────────────────────────────────────
    if step == "fee":
        _fee_pct = d.get("fee_pct", 1.0)
        fee_amt = round(d["amount"] * _fee_pct / 100)
        return (
            header + info + "\n\n"
            f"🏦 *Who pays the {_fee_pct:g}% platform fee?*\n"
            f"Fee: ₹{fee_amt:,}\n\n"
            f"• *Buyer pays:* sends ₹{d['amount']:,} \\+ ₹{fee_amt:,} \\= ₹{d['amount'] + fee_amt:,}\n"
            f"• *Seller pays:* receives ₹{d['amount']:,} \\- ₹{fee_amt:,} \\= ₹{d['amount'] - fee_amt:,}",
            kb([
                [("Buyer Pays Fee", "esc:fee:buyer"),
                 ("Seller Pays Fee", "esc:fee:seller")],
                [("❌ Cancel", "esc:cancel")],
            ])
        )

    fp = d.get("fee_payer", "buyer")
    fee_amt = round(d["amount"] * d.get("fee_pct", 1.0) / 100)
    info += f"  \\|  fee→{esc(fp)}"

    # ── Step 5: ToS ───────────────────────────────────────────────────────────
    if step == "toc":
        toc_text = d.get("default_toc", "Standard escrow terms apply.")
        return (
            header + info + "\n\n"
            "📋 *Terms of Service* \\(optional\\):\n"
            f"_{esc(toc_text[:120])}_\n\n"
            "Choose a ToS option:",
            kb([
                [("✅ Accept Default ToS", "esc:toc:default")],
                [("✏️ Write Custom ToS", "esc:toc:custom"),
                 ("⏭️ Skip ToS", "esc:toc:skip")],
                [("❌ Cancel", "esc:cancel")],
            ])
        )

    if step == "custom_toc":
        return (
            header + info + "\n\n"
            "✏️ *Type your custom Terms of Service below:*\n"
            "_Max 200 characters — send as a message in this group_",
            kb([[("❌ Cancel", "esc:cancel")]])
        )

    # ── Step 6: Payment Method ────────────────────────────────────────────────
    if step == "payment":
        amount = d.get("amount", 0)
        mm_fee = round(amount / 100)
        return (
            header + info + "\n\n"
            "💳 *Choose Payment Method:*\n\n"
            f"💰 *Wallet* — Pay from your VC balance \\(fast, automated\\)\n\n"
            f"🛡️ *Middleman* — Human escrow agent handles payment via UPI\n"
            f"_\\+1% extra fee \\(₹{mm_fee:,}\\) for middleman service_",
            kb([
                [("💰 Pay via Wallet", "esc:payment:wallet"),
                 ("🛡️ Use Middleman", "esc:payment:middleman")],
                [("❌ Cancel", "esc:cancel")],
            ])
        )

    cp_role = "Seller" if role == "buyer" else "Buyer"
    pm = d.get("payment_method", "wallet")
    pm_label = "🛡️ Middleman" if pm == "middleman" else "💰 Wallet"
    info += f"  \\|  {esc(pm_label)}"

    # ── Step 7: Mention counterparty ─────────────────────────────────────────
    if step == "mention":
        return (
            header + info + "\n\n"
            f"👥 *@mention the {esc(cp_role)}* in this group:\n"
            f"_They will see an Accept button to confirm the deal_",
            kb([[("❌ Cancel", "esc:cancel")]])
        )

    # ── Step 8: Waiting for counterparty ─────────────────────────────────────
    if step == "waiting":
        cp_un = d.get("counterparty_un", "?")
        toc_line = ""
        if d.get("toc"):
            toc_line = f"\n📋 ToS: _{esc(d['toc'][:60])}_"
        return (
            header + info + toc_line + "\n\n"
            f"⏳ Waiting for @{esc(cp_un)} to accept\\.\\.\\.\n\n"
            f"👇 *@{esc(cp_un)}* — click below to join this deal:",
            kb([
                [("✅ I Accept This Deal", f"esc:accept:{d['initiator_id']}")],
                [("❌ Reject", f"esc:reject:{d['initiator_id']}")],
                [("🗑️ Cancel", "esc:cancel")],
            ])
        )

    return header + "\n_Processing\\.\\.\\._", None


def build_deal_card(deal: dict, bot_username: str = "") -> tuple[str, InlineKeyboardMarkup | None]:
    """Build the active deal card for the group message."""
    status = deal.get("status", "awaiting_payment")
    amount = deal.get("amount", 0)
    fee_pct = deal.get("fee_percent", 1.0)
    fee_payer = deal.get("fee_payer", "buyer")
    buyer_debit, seller_credit, fee_amt = compute_fee(amount, fee_pct, fee_payer)

    deal_id = deal.get("deal_id", "")
    buyer_un = esc(deal.get("buyer_un") or "buyer")
    seller_un = esc(deal.get("seller_un") or "seller")
    toc = deal.get("toc") or ""
    product_name = deal.get("product_name") or ""
    payment_method = deal.get("payment_method") or "wallet"

    bun = bot_username or _bot_username

    # Timer
    timer_line = ""
    expires_at = deal.get("expires_at")
    if expires_at and status in ("awaiting_payment", "in_progress", "buyer_paid", "mm_connecting"):
        try:
            exp_dt = datetime.fromisoformat(str(expires_at).replace("Z", "+00:00"))
            rem = exp_dt - datetime.now(timezone.utc)
            total_mins = max(0, int(rem.total_seconds() / 60))
            hrs, mins = divmod(total_mins, 60)
            if hrs > 0:
                timer_line = f"\n⏰ Expires in: *{hrs}h {mins}m*"
            elif total_mins > 0:
                timer_line = f"\n⏰ Expires in: *{total_mins}m*"
            else:
                timer_line = "\n⏰ *Expiring soon\\!*"
        except Exception:
            pass

    STATUS_MAP = {
        "awaiting_payment":    "💳 Awaiting Payment",
        "in_progress":         "🔄 Payment in Progress",
        "buyer_paid":          "✅ Buyer Paid — Confirming",
        "mm_connecting":       "🔄 Buyer Connecting to Middleman\\.\\.\\.",
        "mm_payment_received": "✅ Payment Received by Middleman",
        "mm_asset_released":   "🔓 Asset Released — Seller Getting Paid\\.\\.\\.",
        "completed":           "🎉 Deal Completed",
        "disputed":            "⚠️ Under Dispute",
        "cancelled":           "❌ Cancelled",
        "expired":             "💨 Expired \\(2h timeout\\)",
    }
    status_label = STATUS_MAP.get(status, esc(status))

    pm_label = "🛡️ Middleman" if payment_method == "middleman" else "💰 Wallet"

    text = (
        f"🤝 *DEAL \\#{esc(deal_id)}*\n"
        f"━━━━━━━━━━━━━━━━━\n"
    )
    if product_name:
        text += f"📦 Product: *{esc(product_name)}*\n"
    text += (
        f"💰 Amount: *₹{amount:,}*\n"
        f"🏦 Fee: ₹{fee_amt:,} \\({esc(fee_payer)} pays\\)\n"
        f"💳 Via: {pm_label}\n"
        f"👤 Buyer: @{buyer_un}\n"
        f"📦 Seller: @{seller_un}\n"
    )
    if toc:
        text += f"📋 ToS: _{esc(toc[:80])}_\n"
    text += f"━━━━━━━━━━━━━━━━━\n"
    text += f"📊 Status: {status_label}"
    text += timer_line

    # Duration for completed deals
    if status == "completed":
        try:
            created = deal.get("created_at") or deal.get("expires_at", "")
            released = deal.get("released_at", "")
            if created and released:
                c_dt = datetime.fromisoformat(str(created).replace("Z", "+00:00"))
                r_dt = datetime.fromisoformat(str(released).replace("Z", "+00:00"))
                secs = int((r_dt - c_dt).total_seconds())
                if secs > 0:
                    hrs, rem2 = divmod(secs, 3600)
                    mins2, secs2 = divmod(rem2, 60)
                    if hrs > 0:
                        text += f"\n⏱ Duration: *{hrs}h {mins2}m {secs2}s*"
                    else:
                        text += f"\n⏱ Duration: *{mins2}m {secs2}s*"
        except Exception:
            pass

    buttons: list[list] = []
    if status == "awaiting_payment":
        if payment_method == "middleman":
            buttons.append([("🛡️ Buyer: Pay via Middleman", f"deal:mm_pay:{deal_id}"),
                            ("❌ Cancel", f"deal:cancel:{deal_id}")])
        else:
            buttons.append([("💳 Buyer: Pay Now", f"deal:pay:{deal_id}"),
                            ("⚠️ Dispute", f"deal:dispute:{deal_id}")])
            buttons.append([("❌ Cancel Deal", f"deal:cancel:{deal_id}")])
    elif status in ("in_progress", "buyer_paid"):
        if bun:
            from telegram import InlineKeyboardButton as IKB
            chat_rows = [
                [IKB("💬 Buyer: Open Secure Chat", url=f"https://t.me/{bun}?start=relay_{deal_id}"),
                 IKB("💬 Seller: Open Secure Chat", url=f"https://t.me/{bun}?start=relay_{deal_id}")],
                [IKB("⚠️ Raise Dispute", callback_data=f"deal:dispute:{deal_id}")],
            ]
            return text, InlineKeyboardMarkup(chat_rows)
        else:
            buttons.append([("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")])
    elif status == "mm_connecting":
        if bun:
            from telegram import InlineKeyboardButton as IKB
            row = [IKB("💬 Buyer: Connect to Middleman",
                       url=f"https://t.me/{bun}?start=mm_B_{deal_id}")]
            return text, InlineKeyboardMarkup([row])
    elif status == "mm_payment_received":
        buttons.append([("🔓 Release Asset", f"deal:mm_release_ask:{deal_id}")])
        buttons.append([("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")])
    elif status == "mm_asset_released":
        if bun:
            from telegram import InlineKeyboardButton as IKB
            row = [IKB("💸 Seller: Receive Payment",
                       url=f"https://t.me/{bun}?start=mm_S_{deal_id}")]
            return text, InlineKeyboardMarkup([row])

    return text, kb(buttons) if buttons else None


# ─── Deal finalization ─────────────────────────────────────────────────────────

async def finalize_deal(context, d: dict, group_msg):
    """Save deal to DB, edit group card, DM both parties."""
    try:
        fee_pct = await get_fee_pct()
        payment_method = d.get("payment_method", "wallet")
        if payment_method == "middleman":
            fee_pct = fee_pct + 1.0  # +1% for middleman service

        buyer_debit, seller_credit, fee_amt = compute_fee(
            d["amount"], fee_pct, d.get("fee_payer", "buyer")
        )

        if d["role"] == "buyer":
            buyer_id, buyer_un = d["initiator_id"], d["initiator_un"]
            seller_id, seller_un = d["counterparty_id"], d["counterparty_un"]
        else:
            seller_id, seller_un = d["initiator_id"], d["initiator_un"]
            buyer_id, buyer_un = d["counterparty_id"], d["counterparty_un"]

        deal_seq = await db.next_deal_id()
        deal_id = str(deal_seq)
        seller_pin = str(random.randint(1000, 9999))
        expires = (datetime.now(timezone.utc) + timedelta(hours=2)).isoformat()

        deal = {
            "deal_id": deal_id,
            "chat_id": d["chat_id"],
            "buyer_id": buyer_id,
            "buyer_un": buyer_un,
            "seller_id": seller_id,
            "seller_un": seller_un,
            "amount": d["amount"],
            "fee_payer": d.get("fee_payer", "buyer"),
            "fee_percent": fee_pct,
            "toc": d.get("toc", ""),
            "role": d["role"],
            "status": "awaiting_payment",
            "seller_pin": seller_pin,
            "message_id": group_msg.message_id if group_msg else None,
            "created_at": now_iso(),
            "expires_at": expires,
            "buyer_accepted": True,
            "seller_accepted": True,
            "product_name": d.get("product_name", ""),
            "payment_method": payment_method,
        }

        await db.create_deal(deal)
        await db.get_or_create_user(buyer_id, buyer_un)
        await db.get_or_create_user(seller_id, seller_un)

        # Edit group card to active deal
        card_text, card_markup = build_deal_card(deal)
        if group_msg:
            await safe_edit(group_msg, card_text, card_markup)

        if payment_method == "wallet":
            # DM seller — wallet flow (no PIN needed, buyer releases via button)
            await send_dm(
                seller_id,
                f"✅ *Deal \\#{esc(deal_id)} is Active\\!*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"Buyer: @{esc(buyer_un)}\n"
                f"Amount: *₹{d['amount']:,}*\n\n"
                f"⏳ Waiting for buyer to lock payment from wallet\\.\n"
                f"Once locked, you'll get a secure chat link to communicate\\.\n"
                f"Buyer will release funds after you deliver\\."
            )
            # DM buyer
            await send_dm(
                buyer_id,
                f"✅ *Deal \\#{esc(deal_id)} is Active\\!*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"Seller: @{esc(seller_un)}\n"
                f"Amount: *₹{d['amount']:,}*\n\n"
                f"💡 Go to the group and click *💳 Pay Now* to lock your funds\\.\n"
                f"After payment, you'll get a secure chat with the seller\\."
            )
        else:
            # DM buyer (middleman mode)
            await send_dm(
                buyer_id,
                f"✅ *Deal \\#{esc(deal_id)} is Active — Middleman Mode\\!*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"Seller: @{esc(seller_un)}\n"
                f"Product: {esc(d.get('product_name','') or 'N/A')}\n"
                f"Amount: *₹{d['amount']:,}*\n\n"
                f"💡 Go to the group and click *🛡️ Pay via Middleman* to start\\."
            )
            await send_dm(
                seller_id,
                f"✅ *Deal \\#{esc(deal_id)} is Active — Middleman Mode\\!*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"Buyer: @{esc(buyer_un)}\n"
                f"Product: {esc(d.get('product_name','') or 'N/A')}\n"
                f"Amount: *₹{d['amount']:,}*\n\n"
                f"⏳ A middleman will handle the payment\\. Standby\\."
            )

        # Notify admin
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"🆕 *New Deal \\#{esc(deal_id)}*\n"
            f"Buyer: @{esc(buyer_un)} \\| Seller: @{esc(seller_un)}\n"
            f"Amount: ₹{d['amount']:,} \\| Via: {esc(payment_method)}"
        )

        log.info(f"Deal {deal_id} finalized — buyer={buyer_id} seller={seller_id} method={payment_method}")

    except Exception as e:
        log.error(f"finalize_deal error: {e}", exc_info=True)
        if group_msg:
            await safe_edit(
                group_msg,
                "❌ *Failed to create deal*\\. Please try /escrow again\\."
            )


# ─── /escrow command ──────────────────────────────────────────────────────────

async def cmd_escrow(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg:
        return
    chat = update.effective_chat
    user = update.effective_user

    if chat.type == ChatType.PRIVATE:
        await msg.reply_text(
            "📢 Use /escrow in a *group chat* to start a deal\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    # Check whitelisted
    if not await db.is_group_whitelisted(chat.id, TELEGRAM_GROUP_ID):
        await msg.reply_text("⛔ This group is not authorized for escrow\\.",
                             parse_mode=ParseMode.MARKDOWN_V2)
        return

    # Clear any existing draft for this user
    DRAFT.pop(user.id, None)

    default_toc = await get_default_toc()
    d = {
        "step": "role",
        "initiator_id": user.id,
        "initiator_un": user.username or str(user.id),
        "chat_id": chat.id,
        "msg_id": None,
        "role": None,
        "product_name": None,
        "amount": None,
        "fee_payer": None,
        "fee_pct": 1.0,
        "toc": None,
        "default_toc": default_toc,
        "payment_method": None,
        "counterparty_id": None,
        "counterparty_un": None,
    }

    card_text, card_markup = build_draft_card(d)
    sent = await msg.reply_text(
        card_text, parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=card_markup,
    )
    d["msg_id"] = sent.message_id
    DRAFT[user.id] = d

    # Delete the /escrow command message
    await try_delete(msg)


# ─── Escrow callback handler ──────────────────────────────────────────────────

async def handle_escrow_cb(q, context, parts, user):
    action = parts[1] if len(parts) > 1 else ""

    # Cancel — works even without a draft
    if action == "cancel":
        DRAFT.pop(user.id, None)
        await safe_edit(q.message, "❌ *Deal creation cancelled\\.*")
        await qans(q)
        return

    # Accept/Reject counterparty — no draft needed on *this* user
    if action == "accept":
        initiator_id = int(parts[2]) if len(parts) > 2 else 0
        d = DRAFT.get(initiator_id)
        if not d:
            await qans(q, "⚠️ This deal invitation has expired.", alert=True)
            return
        # Must be the mentioned counterparty
        cp_un = d.get("counterparty_un", "").lower().lstrip("@")
        clicker_un = (user.username or "").lower()
        if clicker_un and cp_un and clicker_un != cp_un:
            await qans(q, f"⛔ Only @{d['counterparty_un']} can accept this deal.", alert=True)
            return
        # Set counterparty ID now that we know it
        d["counterparty_id"] = user.id
        if not d.get("counterparty_un"):
            d["counterparty_un"] = user.username or str(user.id)
        # Delete the separate mention ping message
        if d.get("mention_msg_id") and d.get("chat_id"):
            try:
                await context.bot.delete_message(d["chat_id"], d["mention_msg_id"])
            except Exception:
                pass
        DRAFT.pop(initiator_id, None)
        await qans(q, "✅ Accepted! Creating deal...", alert=False)
        await finalize_deal(context, d, q.message)
        return

    if action == "reject":
        initiator_id = int(parts[2]) if len(parts) > 2 else 0
        d = DRAFT.pop(initiator_id, None)
        if d and d.get("mention_msg_id") and d.get("chat_id"):
            try:
                await context.bot.delete_message(d["chat_id"], d["mention_msg_id"])
            except Exception:
                pass
        rejecter = user.username or str(user.id)
        await safe_edit(
            q.message,
            f"❌ *Deal rejected by @{esc(rejecter)}\\.*\n_Run /escrow to start a new deal\\._"
        )
        await qans(q)
        return

    # All remaining actions require the initiator's draft
    d = DRAFT.get(user.id)
    if not d:
        await qans(q, "⛔ Only the deal creator can use these buttons.", alert=True)
        return

    # ── Role ──────────────────────────────────────────────────────────────────
    if action == "role":
        role = parts[2] if len(parts) > 2 else "buyer"
        d["role"] = role
        d["step"] = "product"  # NEW: go to product name step
        card_text, card_markup = build_draft_card(d)
        await safe_edit(q.message, card_text, card_markup)
        await qans(q)
        return

    # ── Fee payer ─────────────────────────────────────────────────────────────
    if action == "fee":
        fp = parts[2] if len(parts) > 2 else "buyer"
        d["fee_payer"] = fp
        d["step"] = "toc"
        card_text, card_markup = build_draft_card(d)
        await safe_edit(q.message, card_text, card_markup)
        await qans(q)
        return

    # ── ToS ───────────────────────────────────────────────────────────────────
    if action == "toc":
        choice = parts[2] if len(parts) > 2 else "skip"
        if choice == "default":
            d["toc"] = d.get("default_toc", "")
            d["step"] = "payment"
            card_text, card_markup = build_draft_card(d)
            await safe_edit(q.message, card_text, card_markup)
        elif choice == "custom":
            CUSTOM_TOC_AWAIT[user.id] = True
            d["step"] = "custom_toc"
            card_text, card_markup = build_draft_card(d)
            await safe_edit(q.message, card_text, card_markup)
        else:  # skip
            d["toc"] = ""
            d["step"] = "payment"
            card_text, card_markup = build_draft_card(d)
            await safe_edit(q.message, card_text, card_markup)
        await qans(q)
        return

    # ── Payment method ────────────────────────────────────────────────────────
    if action == "payment":
        choice = parts[2] if len(parts) > 2 else "wallet"
        d["payment_method"] = choice
        d["step"] = "mention"
        card_text, card_markup = build_draft_card(d)
        await safe_edit(q.message, card_text, card_markup)
        await qans(q)
        return

    await qans(q)


# ─── Text handler (deal steps + wallet + relay) ───────────────────────────────

async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not msg or not msg.text:
        return
    user = update.effective_user
    text = msg.text.strip()
    chat_type = update.effective_chat.type

    # ── Group: deal creation text steps ──────────────────────────────────────
    if chat_type in (ChatType.GROUP, ChatType.SUPERGROUP):
        d = DRAFT.get(user.id)
        if not d:
            return

        step = d.get("step")

        # Product name input (NEW step 2)
        if step == "product":
            name = text.strip()
            if not name or len(name) < 2:
                await try_delete(msg)
                return
            d["product_name"] = name[:80]
            d["step"] = "amount"
            card_text, card_markup = build_draft_card(d)
            try:
                await context.bot.edit_message_text(
                    card_text, chat_id=d["chat_id"],
                    message_id=d["msg_id"],
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=card_markup,
                )
            except Exception as e:
                log.warning(f"edit msg: {e}")
            await try_delete(msg)
            return

        # Custom ToS text input
        if step == "custom_toc":
            toc_text = text.strip()[:200]
            if not toc_text:
                await try_delete(msg)
                return
            CUSTOM_TOC_AWAIT.pop(user.id, None)
            d["toc"] = toc_text
            d["step"] = "payment"
            card_text, card_markup = build_draft_card(d)
            try:
                await context.bot.edit_message_text(
                    card_text, chat_id=d["chat_id"],
                    message_id=d["msg_id"],
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=card_markup,
                )
            except Exception as e:
                log.warning(f"custom_toc edit: {e}")
            await try_delete(msg)
            return

        # Amount input
        if step == "amount":
            raw = re.sub(r"[^\d]", "", text)
            if not raw:
                await try_delete(msg)
                err = await msg.reply_text("❌ Enter a valid amount \\(e\\.g\\. 500\\)\\.", parse_mode=ParseMode.MARKDOWN_V2)
                asyncio.create_task(_auto_delete(err))
                return
            amount_val = int(raw)
            if amount_val < 100:
                await try_delete(msg)
                err = await msg.reply_text("❌ Minimum amount is ₹100\\.", parse_mode=ParseMode.MARKDOWN_V2)
                asyncio.create_task(_auto_delete(err))
                return
            amount = amount_val
            if amount > 10_000_000:
                await try_delete(msg)
                err = await msg.reply_text("❌ Maximum amount is ₹1 crore\\.", parse_mode=ParseMode.MARKDOWN_V2)
                asyncio.create_task(_auto_delete(err))
                return
            d["amount"] = amount
            d["step"] = "fee"
            card_text, card_markup = build_draft_card(d)
            try:
                await context.bot.edit_message_text(
                    card_text, chat_id=d["chat_id"],
                    message_id=d["msg_id"],
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=card_markup,
                )
            except Exception as e:
                log.warning(f"edit msg: {e}")
            await try_delete(msg)
            return

        # @mention counterparty
        if step == "mention":
            # Extract @username from text
            match = re.search(r"@(\w+)", text)
            if not match:
                await try_delete(msg)
                err = await msg.reply_text("❌ Please @mention the counterparty\\.", parse_mode=ParseMode.MARKDOWN_V2)
                asyncio.create_task(_auto_delete(err))
                return
            cp_un = match.group(1)
            own_un = (user.username or "").lower()
            if cp_un.lower() == own_un:
                await try_delete(msg)
                err = await msg.reply_text("❌ You cannot mention yourself as counterparty\\.", parse_mode=ParseMode.MARKDOWN_V2)
                asyncio.create_task(_auto_delete(err))
                return

            d["counterparty_un"] = cp_un
            d["step"] = "waiting"
            card_text, card_markup = build_draft_card(d)
            try:
                await context.bot.edit_message_text(
                    card_text, chat_id=d["chat_id"],
                    message_id=d["msg_id"],
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=card_markup,
                )
            except Exception as e:
                log.warning(f"edit msg: {e}")
            await try_delete(msg)

            # Send a separate @mention ping message in the group (no parse_mode = real mention)
            try:
                ping_msg = await context.bot.send_message(
                    d["chat_id"],
                    f"👋 @{cp_un} — @{d['initiator_un']} wants to open an escrow deal with you!\n"
                    f"Amount: ₹{d['amount']:,} — tap ✅ I Accept on the card above 👆",
                )
                d["mention_msg_id"] = ping_msg.message_id
            except Exception as e:
                log.warning(f"mention ping: {e}")

            # DM counterparty if we know their ID
            cp_user = await db.get_user_by_username(cp_un)
            if cp_user:
                d["counterparty_id"] = cp_user["tg_id"]
                initiator_un = esc(d["initiator_un"])
                await send_dm(
                    cp_user["tg_id"],
                    f"🤝 *Deal Invitation from @{initiator_un}*\n"
                    f"━━━━━━━━━━━━━━━━━\n"
                    f"Amount: *₹{d['amount']:,}*\n\n"
                    f"💡 Go to the group and click *I Accept This Deal* button on the card\\.",
                )
            return

        return  # ignore other group text if no step matches

    # ── DM: wallet flow ───────────────────────────────────────────────────────
    if chat_type == ChatType.PRIVATE:
        # ── Middleman DM flow: UPI inputs ────────────────────────────────────
        if user.id in MM_DM_AWAIT:
            ctx = MM_DM_AWAIT[user.id]
            deal_id = ctx["deal_id"]
            role = ctx["role"]
            step_mm = ctx.get("step", "")

            # Middleman providing their UPI to buyer
            if role == "mm" and step_mm == "give_upi":
                upi = text.strip()
                if "@" not in upi or len(upi) < 5:
                    await msg.reply_text(
                        "❌ Invalid UPI\\. Format: `name@bank`",
                        parse_mode=ParseMode.MARKDOWN_V2,
                    )
                    return
                MM_DM_AWAIT.pop(user.id, None)
                mm_st = MM_STATE.get(deal_id, {})
                mm_st["mm_upi"] = upi
                mm_st["status"] = "waiting_buyer_pay"
                MM_STATE[deal_id] = mm_st

                deal = await db.get_deal(deal_id)
                if not deal:
                    return

                amount = deal["amount"]
                # DM buyer with payment instructions
                buyer_markup = kb([[("✅ I've Paid", f"mm:buyer_paid:{deal_id}")],
                                   [("⚠️ Dispute", f"deal:dispute:{deal_id}")]])
                await send_dm(
                    deal["buyer_id"],
                    f"💳 *Pay to Middleman — Deal \\#{esc(deal_id)}*\n"
                    f"━━━━━━━━━━━━━━━━━\n"
                    f"Amount: *₹{amount:,}*\n"
                    f"UPI ID: `{esc(upi)}`\n\n"
                    f"Pay ₹{amount:,} to the UPI above, then click ✅ below\\.",
                    markup=buyer_markup,
                )
                # DM middleman
                mm_markup = kb([[("✅ Payment Received from Buyer", f"mm:mm_recv:{deal_id}")]])
                await msg.reply_text(
                    f"⏳ *Waiting for buyer to pay\\.*\n"
                    f"Once they pay, confirm below:",
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=mm_markup,
                )
                return

            # Seller providing their UPI to receive payment
            if role == "seller" and step_mm == "give_upi":
                upi = text.strip()
                if "@" not in upi or len(upi) < 5:
                    await msg.reply_text(
                        "❌ Invalid UPI\\. Format: `name@bank`",
                        parse_mode=ParseMode.MARKDOWN_V2,
                    )
                    return
                MM_DM_AWAIT.pop(user.id, None)
                mm_st = MM_STATE.get(deal_id, {})
                mm_st["seller_upi"] = upi
                mm_st["status"] = "waiting_seller_pay"
                MM_STATE[deal_id] = mm_st

                deal = await db.get_deal(deal_id)
                if not deal:
                    return
                amount = deal["amount"]

                # DM middleman with seller UPI + button
                mm_id = mm_st.get("mm_id")
                if mm_id:
                    mm_markup = kb([[("✅ I've Paid Seller", f"mm:paid_seller:{deal_id}")]])
                    await send_dm(
                        mm_id,
                        f"📦 *Seller UPI for Deal \\#{esc(deal_id)}*\n"
                        f"━━━━━━━━━━━━━━━━━\n"
                        f"Seller: @{esc(deal['seller_un'])}\n"
                        f"UPI: `{esc(upi)}`\n"
                        f"Amount to send: *₹{amount:,}*\n\n"
                        f"Send ₹{amount:,} to the UPI above, then click ✅\\.",
                        markup=mm_markup,
                    )
                await msg.reply_text(
                    f"✅ UPI submitted\\! Middleman is processing your payment of *₹{amount:,}*\\.\n"
                    f"You'll be notified when payment is sent\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
                return

        # PIN release
        if user.id in PIN_AWAIT:
            deal_id = PIN_AWAIT[user.id]
            deal = await db.get_deal(deal_id)
            if not deal:
                PIN_AWAIT.pop(user.id, None)
                return
            if text == deal["seller_pin"]:
                PIN_AWAIT.pop(user.id, None)
                await complete_deal(context, deal, user)
            else:
                await msg.reply_text(
                    "❌ *Wrong PIN\\!* Try again or contact support\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            return

        # Vouch proof — user types "done" to finish submission
        if user.id in VOUCH_PROOF_AWAIT:
            if text.lower().strip() in ("done", "ok", "finish", "/done"):
                ctx = VOUCH_PROOF_AWAIT.pop(user.id, None)
                count = len(ctx.get("proofs", []))
                await msg.reply_text(
                    f"✅ *Proof submitted\\!* {count} screenshot\\(s\\) saved\\.\n"
                    f"Admin will review and approve your vouch\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            else:
                await msg.reply_text(
                    "📸 *Send proof screenshots* \\(up to 3\\)\\.\n"
                    "Type *done* when finished\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            return

        # Dispute evidence — persistent text collection
        if user.id in EVIDENCE_AWAIT:
            ctx = EVIDENCE_AWAIT[user.id]
            deal_id = ctx["deal_id"]
            if text.lower().strip() in ("done", "finish", "/done"):
                EVIDENCE_AWAIT.pop(user.id, None)
                await msg.reply_text(
                    "✅ *Evidence package complete\\!* Admin \\(and our AI judge\\) will review your case\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
                await _maybe_trigger_ai_judge(deal_id, user.id)
                return
            await db.add_dispute_message(deal_id, {
                "from": user.username or str(user.id),
                "type": "text", "text": text, "at": now_iso(),
            })
            await msg.reply_text(
                "📨 *Evidence saved\\!*\n"
                "Send more screenshots or text, or type *done* when finished\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            await send_dm(
                TELEGRAM_ADMIN_ID,
                f"📨 *Dispute Evidence \\(text\\)*\n"
                f"Deal: \\#{esc(deal_id)} \\| From: @{esc(user.username or str(user.id))}\n\n"
                f"{esc(text[:500])}"
            )
            return

        # Legacy one-shot dispute description (first message after dispute raised)
        if user.id in DISPUTE_AWAIT:
            deal_id = DISPUTE_AWAIT.pop(user.id, None)
            await db.add_dispute_message(deal_id, {
                "from": user.username or str(user.id),
                "text": text, "at": now_iso(),
            })
            await msg.reply_text(
                "📨 *Initial statement saved\\.*\n"
                "You can continue adding screenshots and text evidence in this chat anytime\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            await send_dm(
                TELEGRAM_ADMIN_ID,
                f"📨 *Dispute Evidence*\nDeal: \\#{esc(deal_id)}\n"
                f"From: @{esc(user.username or str(user.id))}\n\n{esc(text[:500])}"
            )
            return

        # Wallet flow
        if user.id in WALLET_STATE:
            await handle_wallet_text(update, context, text)
            return

        # Relay — buyer↔seller DM during in_progress deal
        if user.id in RELAY:
            r = RELAY[user.id]
            deal = await db.get_deal(r["deal_id"])
            if deal and deal["status"] in ("in_progress", "buyer_paid"):
                role_label = "Buyer" if r["role"] == "buyer" else "Seller"
                await send_dm(
                    r["other_id"],
                    f"💬 *{esc(role_label)} says:*\n{esc(text)}",
                )
            return


# ─── Deal action handler ──────────────────────────────────────────────────────

async def complete_deal(context, deal: dict, pinner_user=None):
    """Release funds and mark deal completed."""
    deal_id = deal["deal_id"]
    amount = deal["amount"]
    fee_pct = deal.get("fee_percent", 1.0)
    fee_payer = deal.get("fee_payer", "buyer")
    buyer_debit, seller_credit, fee_amt = compute_fee(amount, fee_pct, fee_payer)

    # Release seller's VC (they get seller_credit)
    await db.adjust_balance(deal["seller_id"], delta_balance=seller_credit)
    # Unlock buyer's locked VC and deduct
    await db.adjust_balance(deal["buyer_id"], delta_locked=-buyer_debit)
    # Add fee to treasury
    await db.add_to_treasury(fee_amt)

    # Update deal stats via raw SQL increments
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE users SET total_deals = total_deals + 1, total_volume = total_volume + $1 WHERE tg_id = $2",
            amount, deal["buyer_id"],
        )
        await conn.execute(
            "UPDATE users SET total_deals = total_deals + 1, total_volume = total_volume + $1 WHERE tg_id = $2",
            amount, deal["seller_id"],
        )

    await db.update_deal(deal_id,
                         status="completed",
                         released_at=now_iso())

    # Update tier
    for uid in (deal["buyer_id"], deal["seller_id"]):
        await update_tier(uid)

    # Edit group card
    deal["status"] = "completed"
    card_text, card_markup = build_deal_card(deal)
    pinned_msg_id = deal.get("message_id")
    try:
        if deal.get("chat_id") and pinned_msg_id:
            await context.bot.edit_message_text(
                card_text, chat_id=deal["chat_id"],
                message_id=pinned_msg_id,
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=card_markup,
            )
    except Exception as e:
        log.warning(f"complete_deal edit: {e}")

    # Pin the group message
    try:
        if deal.get("chat_id") and pinned_msg_id:
            await context.bot.pin_chat_message(
                chat_id=deal["chat_id"],
                message_id=pinned_msg_id,
                disable_notification=True,
            )
    except Exception as e:
        log.warning(f"complete_deal pin: {e}")

    # Notify both parties
    await send_dm(deal["buyer_id"],
                  f"🎉 *Deal \\#{esc(deal_id)} Complete\\!*\n"
                  f"₹{amount:,} released to @{esc(deal['seller_un'])}\\. Thank you\\!")
    await send_dm(deal["seller_id"],
                  f"🎉 *Deal \\#{esc(deal_id)} Complete\\!*\n"
                  f"*{seller_credit:,} VC* added to your wallet\\! Thank you\\!")

    # Rating requests
    rating_markup = kb([
        [("⭐", f"rate:1:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐", f"rate:2:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐⭐", f"rate:3:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐⭐⭐", f"rate:4:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐⭐⭐⭐", f"rate:5:{deal_id}:{deal['seller_id']}")],
    ])
    await send_dm(deal["buyer_id"],
                  f"🌟 *Rate @{esc(deal['seller_un'])}* for deal \\#{esc(deal_id)}:",
                  markup=rating_markup)

    # Compute duration
    duration_str = ""
    try:
        c_dt = datetime.fromisoformat(str(deal.get("created_at", "")).replace("Z", "+00:00"))
        r_dt = datetime.now(timezone.utc)
        secs = int((r_dt - c_dt).total_seconds())
        if secs > 0:
            hrs, rem2 = divmod(secs, 3600)
            mins2, secs2 = divmod(rem2, 60)
            duration_str = f" \\| ⏱ {hrs}h {mins2}m" if hrs > 0 else f" \\| ⏱ {mins2}m {secs2}s"
    except Exception:
        pass

    # Post to channel
    if TELEGRAM_CHANNEL_ID:
        try:
            product_name = deal.get("product_name") or ""
            pm = "🛡️ Middleman" if deal.get("payment_method") == "middleman" else "💰 Wallet"
            prod_line = f"📦 Product: {esc(product_name)}\n" if product_name else ""
            await context.bot.send_message(
                TELEGRAM_CHANNEL_ID,
                f"✅ *Deal \\#{esc(deal_id)} Completed*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"{prod_line}"
                f"💰 Amount: ₹{amount:,}\n"
                f"👤 Buyer: @{esc(deal['buyer_un'])}\n"
                f"📦 Seller: @{esc(deal['seller_un'])}\n"
                f"🏦 Fee: ₹{fee_amt:,} \\| Via: {esc(pm)}{duration_str}",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        except Exception as e:
            log.warning(f"channel post: {e}")

    # Clear relay
    RELAY.pop(deal["buyer_id"], None)
    RELAY.pop(deal["seller_id"], None)


async def update_tier(tg_id: int):
    u = await db.get_user(tg_id)
    if not u:
        return
    deals = u.get("total_deals", 0)
    if deals >= 50:
        tier = "elite"
    elif deals >= 20:
        tier = "trusted"
    elif deals >= 5:
        tier = "regular"
    else:
        tier = "new"
    if u.get("tier") != tier:
        await db.update_user(tg_id, tier=tier)


# ─── Middleman deal completion ──────────────────────────────────────────────────

async def complete_mm_deal(context, deal: dict):
    """Complete a middleman deal — no VC transfers, just stats/card/pin/channel."""
    deal_id = deal["deal_id"]
    amount = deal["amount"]

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE users SET total_deals = total_deals + 1, total_volume = total_volume + $1 WHERE tg_id = $2",
            amount, deal["buyer_id"],
        )
        await conn.execute(
            "UPDATE users SET total_deals = total_deals + 1, total_volume = total_volume + $1 WHERE tg_id = $2",
            amount, deal["seller_id"],
        )

    released_ts = now_iso()
    await db.update_deal(deal_id, status="completed", released_at=released_ts)

    for uid in (deal["buyer_id"], deal["seller_id"]):
        await update_tier(uid)

    deal["status"] = "completed"
    deal["released_at"] = released_ts
    card_text, _ = build_deal_card(deal)
    pinned_msg_id = deal.get("message_id")
    try:
        if deal.get("chat_id") and pinned_msg_id:
            await context.bot.edit_message_text(
                card_text, chat_id=deal["chat_id"],
                message_id=pinned_msg_id,
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=None,
            )
    except Exception as e:
        log.warning(f"mm complete edit: {e}")

    # Pin the group message
    try:
        if deal.get("chat_id") and pinned_msg_id:
            await context.bot.pin_chat_message(
                chat_id=deal["chat_id"],
                message_id=pinned_msg_id,
                disable_notification=True,
            )
    except Exception as e:
        log.warning(f"mm complete pin: {e}")

    # Notify both parties
    await send_dm(deal["buyer_id"],
                  f"🎉 *Deal \\#{esc(deal_id)} Complete\\!*\n"
                  f"Seller received ₹{amount:,}\\. Thank you for using Vault\\-Pay\\!")
    await send_dm(deal["seller_id"],
                  f"🎉 *Deal \\#{esc(deal_id)} Complete\\!*\n"
                  f"₹{amount:,} paid to your UPI\\! Thank you for using Vault\\-Pay\\!")

    # Rating requests
    rating_markup = kb([
        [("⭐", f"rate:1:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐", f"rate:2:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐⭐", f"rate:3:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐⭐⭐", f"rate:4:{deal_id}:{deal['seller_id']}"),
         ("⭐⭐⭐⭐⭐", f"rate:5:{deal_id}:{deal['seller_id']}")],
    ])
    await send_dm(deal["buyer_id"],
                  f"🌟 *Rate @{esc(deal['seller_un'])}* for deal \\#{esc(deal_id)}:",
                  markup=rating_markup)

    # Duration
    duration_str = ""
    try:
        c_dt = datetime.fromisoformat(str(deal.get("created_at", "")).replace("Z", "+00:00"))
        r_dt = datetime.fromisoformat(released_ts.replace("Z", "+00:00"))
        secs = int((r_dt - c_dt).total_seconds())
        if secs > 0:
            hrs, rem2 = divmod(secs, 3600)
            mins2, secs2 = divmod(rem2, 60)
            duration_str = f" \\| ⏱ {hrs}h {mins2}m" if hrs > 0 else f" \\| ⏱ {mins2}m {secs2}s"
    except Exception:
        pass

    # Post to channel
    if TELEGRAM_CHANNEL_ID:
        try:
            product_name = deal.get("product_name") or ""
            prod_line = f"📦 Product: {esc(product_name)}\n" if product_name else ""
            await context.bot.send_message(
                TELEGRAM_CHANNEL_ID,
                f"✅ *Deal \\#{esc(deal_id)} Completed via Middleman*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"{prod_line}"
                f"💰 Amount: ₹{amount:,}\n"
                f"👤 Buyer: @{esc(deal['buyer_un'])}\n"
                f"📦 Seller: @{esc(deal['seller_un'])}\n"
                f"🛡️ Via: Middleman{duration_str}",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        except Exception as e:
            log.warning(f"mm channel post: {e}")

    MM_STATE.pop(deal_id, None)


# ─── Middleman callback handler ────────────────────────────────────────────────

async def handle_mm_cb(q, context, parts, user):
    """Handle mm: prefix callbacks for the middleman deal flow."""
    action = parts[1] if len(parts) > 1 else ""
    deal_id = parts[2] if len(parts) > 2 else ""

    deal = await db.get_deal(deal_id)
    if not deal:
        await qans(q, "Deal not found.", alert=True)
        return

    mm_st = MM_STATE.get(deal_id, {})

    # ── Middleman enters deal ──────────────────────────────────────────────────
    if action == "enter":
        if not await db.is_middleman(user.id):
            await qans(q, "You are not an authorized middleman.", alert=True)
            return
        if mm_st.get("mm_id"):
            await qans(q, "⚠️ Another middleman already entered this deal.", alert=True)
            return
        if deal["status"] not in ("mm_connecting",):
            await qans(q, "Deal is not in connecting stage.", alert=True)
            return

        mm_st["mm_id"] = user.id
        mm_st["mm_un"] = user.username or str(user.id)
        mm_st["status"] = "mm_entered"
        MM_STATE[deal_id] = mm_st

        await qans(q, "✅ You entered the deal!", alert=True)
        MM_DM_AWAIT[user.id] = {"role": "mm", "deal_id": deal_id, "step": "give_upi"}
        try:
            await q.message.edit_text(
                f"✅ *You entered Deal \\#{esc(deal_id)}\\!*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"📦 Product: {esc(deal.get('product_name') or 'N/A')}\n"
                f"💰 Amount: ₹{deal['amount']:,}\n"
                f"👤 Buyer: @{esc(deal['buyer_un'])}\n"
                f"📦 Seller: @{esc(deal['seller_un'])}\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"*Send your UPI ID* to receive payment from buyer:",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        except Exception:
            pass
        await send_dm(
            deal["buyer_id"],
            f"✅ *Middleman Connected — Deal \\#{esc(deal_id)}*\n"
            f"Your middleman is @{esc(user.username or str(user.id))}\\.\n"
            f"⏳ They are sending you payment instructions\\.\\.\\."
        )
        return

    # ── Middleman confirms payment received from buyer ─────────────────────────
    if action == "mm_recv":
        if user.id != mm_st.get("mm_id"):
            await qans(q, "Only the assigned middleman can do this.", alert=True)
            return

        mm_st["status"] = "payment_received"
        MM_STATE[deal_id] = mm_st
        await db.update_deal(deal_id, status="mm_payment_received")
        deal["status"] = "mm_payment_received"

        card_text, card_markup = build_deal_card(deal)
        try:
            if deal.get("chat_id") and deal.get("message_id"):
                await context.bot.edit_message_text(
                    card_text, chat_id=deal["chat_id"],
                    message_id=deal["message_id"],
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=card_markup,
                )
        except Exception as e:
            log.warning(f"mm_recv edit: {e}")

        await qans(q, "✅ Confirmed! Group card updated.", alert=True)
        try:
            await q.message.edit_text(
                f"✅ *Payment Received Confirmed — Deal \\#{esc(deal_id)}*\n"
                f"Waiting for buyer to release the asset\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        except Exception:
            pass

        await send_dm(
            deal["buyer_id"],
            f"✅ *Middleman confirmed your payment — Deal \\#{esc(deal_id)}*\n\n"
            f"Money is safe with middleman\\!\n"
            f"Now go to the group and click *🔓 Release Asset* after seller delivers\\."
        )
        await send_dm(
            deal["seller_id"],
            f"✅ *Buyer has paid — Deal \\#{esc(deal_id)}*\n\n"
            f"Payment is held by middleman\\.\n"
            f"⏳ Deliver your product/service, then buyer will release\\."
        )
        return

    # ── Buyer says they paid ───────────────────────────────────────────────────
    if action == "buyer_paid":
        if user.id != deal["buyer_id"]:
            await qans(q, "Only the buyer can do this.", alert=True)
            return
        mm_id = mm_st.get("mm_id")
        await qans(q, "⏳ Notifying middleman...", alert=False)
        if mm_id:
            mm_markup = kb([[("✅ Payment Received from Buyer", f"mm:mm_recv:{deal_id}")]])
            await send_dm(
                mm_id,
                f"⚡ *Buyer says they paid — Deal \\#{esc(deal_id)}*\n"
                f"Please verify and confirm:",
                markup=mm_markup,
            )
        return

    # ── Buyer releases asset ───────────────────────────────────────────────────
    if action == "release":
        if user.id != deal["buyer_id"]:
            await qans(q, "Only the buyer can release.", alert=True)
            return
        if deal["status"] != "mm_payment_received":
            await qans(q, "Cannot release at this stage.", alert=True)
            return

        await db.update_deal(deal_id, status="mm_asset_released")
        deal["status"] = "mm_asset_released"
        mm_st["status"] = "asset_released"
        MM_STATE[deal_id] = mm_st

        card_text, card_markup = build_deal_card(deal)
        try:
            if deal.get("chat_id") and deal.get("message_id"):
                await context.bot.edit_message_text(
                    card_text, chat_id=deal["chat_id"],
                    message_id=deal["message_id"],
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=card_markup,
                )
        except Exception as e:
            log.warning(f"mm release edit: {e}")

        await qans(q, "✅ Asset released! Seller notified.", alert=True)

        seller_markup = kb([[("💸 Connect to Receive Payment", f"mm:seller_connect:{deal_id}")]])
        await send_dm(
            deal["seller_id"],
            f"🔓 *Buyer Released Asset — Deal \\#{esc(deal_id)}*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"Buyer confirmed delivery\\! You will receive ₹{deal['amount']:,}\\.\n\n"
            f"Click below to connect and provide your UPI:",
            markup=seller_markup,
        )
        mm_id = mm_st.get("mm_id")
        if mm_id:
            await send_dm(mm_id,
                          f"🔓 *Buyer released — Deal \\#{esc(deal_id)}*\n"
                          f"Seller @{esc(deal['seller_un'])} will connect to provide their UPI\\.")
        return

    # ── Buyer cancels release ──────────────────────────────────────────────────
    if action == "release_no":
        await qans(q, "Release cancelled. Deal continues.")
        return

    # ── Seller connects to receive payment ─────────────────────────────────────
    if action == "seller_connect":
        if user.id != deal["seller_id"]:
            await qans(q, "Only the seller can do this.", alert=True)
            return
        if deal["status"] != "mm_asset_released":
            await qans(q, "Cannot connect at this stage.", alert=True)
            return

        MM_DM_AWAIT[user.id] = {"role": "seller", "deal_id": deal_id, "step": "give_upi"}
        await qans(q, "✅ Connected! Please type your UPI.", alert=True)
        await send_dm(
            deal["seller_id"],
            f"✅ *Connected to Middleman — Deal \\#{esc(deal_id)}*\n\n"
            f"Type your UPI ID to receive ₹{deal['amount']:,}:",
        )
        mm_id = mm_st.get("mm_id")
        if mm_id:
            await send_dm(mm_id,
                          f"📦 *Seller connecting — Deal \\#{esc(deal_id)}*\n"
                          f"@{esc(deal['seller_un'])} is providing their UPI now\\.")
        return

    # ── Middleman confirms paid to seller ─────────────────────────────────────
    if action == "paid_seller":
        if user.id != mm_st.get("mm_id"):
            await qans(q, "Only the assigned middleman can do this.", alert=True)
            return

        await qans(q, "✅ Marked as paid. Awaiting seller confirmation.", alert=True)
        try:
            await q.message.edit_text(
                f"✅ *Marked as Paid — Deal \\#{esc(deal_id)}*\n"
                f"Awaiting seller confirmation\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        except Exception:
            pass

        seller_markup = kb([
            [("✅ Payment Received", f"mm:seller_recv_ask:{deal_id}")],
            [("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")],
        ])
        await send_dm(
            deal["seller_id"],
            f"💸 *Middleman says payment sent — Deal \\#{esc(deal_id)}*\n"
            f"Amount: ₹{deal['amount']:,}\n\n"
            f"Check your UPI and confirm receipt below\\.",
            markup=seller_markup,
        )
        return

    # ── Seller asks to confirm receipt ─────────────────────────────────────────
    if action == "seller_recv_ask":
        if user.id != deal["seller_id"]:
            await qans(q, "Only the seller can confirm.", alert=True)
            return
        confirm_markup = kb([
            [("✅ Yes, Confirm Receipt", f"mm:seller_recv:{deal_id}")],
            [("❌ No, Not Received", f"mm:seller_recv_no:{deal_id}")],
        ])
        await qans(q, "Confirmation sent!", alert=False)
        await send_dm(
            deal["seller_id"],
            f"🔐 *Final Confirmation — Deal \\#{esc(deal_id)}*\n\n"
            f"Confirm receipt of ₹{deal['amount']:,}\\.\n"
            f"Once confirmed, deal closes permanently\\.",
            markup=confirm_markup,
        )
        return

    # ── Seller confirms received — deal complete! ─────────────────────────────
    if action == "seller_recv":
        if user.id != deal["seller_id"]:
            await qans(q, "Only the seller can confirm.", alert=True)
            return

        await qans(q, "🎉 Deal completed!", alert=True)
        await complete_mm_deal(context, deal)
        mm_id = mm_st.get("mm_id")
        if mm_id:
            await send_dm(mm_id,
                          f"🎉 *Deal \\#{esc(deal_id)} Completed\\!*\n"
                          f"Seller confirmed receipt\\. Deal closed\\. Well done\\!")
        return

    # ── Seller says not received ───────────────────────────────────────────────
    if action == "seller_recv_no":
        await qans(q, "Please raise a dispute via the group if there's an issue.", alert=True)
        return

    await qans(q)


async def handle_deal_action(q, context, parts, user):
    action = parts[1] if len(parts) > 1 else ""
    deal_id = parts[2] if len(parts) > 2 else ""

    deal = await db.get_deal(deal_id)
    if not deal:
        await qans(q, "Deal not found.", alert=True)
        return

    # ── Pay Now → Send DM confirmation ────────────────────────────────────────
    if action == "pay":
        if user.id != deal["buyer_id"]:
            await qans(q, "⛔ Only the buyer can initiate payment.", alert=True)
            return
        if deal["status"] != "awaiting_payment":
            await qans(q, "Deal is not in payment stage.", alert=True)
            return

        u = await db.get_or_create_user(user.id, user.username)
        if u.get("frozen"):
            await qans(q, "🧊 Your wallet is frozen. Contact admin.", alert=True)
            return

        fee_pct = deal.get("fee_percent", 1.0)
        buyer_debit, seller_credit, fee_amt = compute_fee(
            deal["amount"], fee_pct, deal.get("fee_payer", "buyer")
        )
        bal = u.get("balance_vc", 0)

        if bal < buyer_debit:
            shortfall = buyer_debit - bal
            await qans(q,
                       f"❌ Insufficient balance! Need {buyer_debit:,} VC, "
                       f"short by {shortfall:,} VC. Use /wallet to deposit.",
                       alert=True)
            return

        # Send DM confirmation — don't lock yet
        confirm_markup = kb([
            [("✅ Yes, Lock ₹{:,} VC".format(buyer_debit), f"deal:pay_confirm:{deal_id}")],
            [("❌ Cancel", f"deal:pay_cancel:{deal_id}")],
        ])
        await send_dm(
            user.id,
            f"💳 *Confirm Payment — Deal \\#{esc(deal_id)}*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"📦 Deal Amount: *₹{deal['amount']:,}*\n"
            f"🏦 Platform Fee: *₹{fee_amt:,}* \\({esc(deal.get('fee_payer','buyer'))} pays\\)\n"
            f"💸 *Total Deducted: {buyer_debit:,} VC*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"💰 Your Balance: *{bal:,} VC*\n"
            f"After Pay: *{bal - buyer_debit:,} VC*\n\n"
            f"⚠️ Funds will be *held by bot* until you release\\.\n"
            f"Confirm to lock your funds in escrow:",
            markup=confirm_markup,
        )
        await qans(q, "✅ Check your DM to confirm payment!", alert=True)
        return

    # ── Pay Confirm (from DM) — lock wallet, activate relay ──────────────────
    if action == "pay_confirm":
        if user.id != deal["buyer_id"]:
            await qans(q, "⛔ Only the buyer can do this.", alert=True)
            return
        if deal["status"] != "awaiting_payment":
            await qans(q, "Deal is already in progress or completed.", alert=True)
            return

        u = await db.get_or_create_user(user.id, user.username)
        if u.get("frozen"):
            await qans(q, "🧊 Your wallet is frozen.", alert=True)
            return
        fee_pct = deal.get("fee_percent", 1.0)
        buyer_debit, seller_credit, fee_amt = compute_fee(
            deal["amount"], fee_pct, deal.get("fee_payer", "buyer")
        )
        if u.get("balance_vc", 0) < buyer_debit:
            await qans(q, "❌ Insufficient balance! Top up your wallet.", alert=True)
            return

        # Deduct from wallet and lock
        await db.adjust_balance(user.id, delta_balance=-buyer_debit, delta_locked=buyer_debit)
        await db.update_deal(deal_id, status="in_progress")

        # Update group card
        deal["status"] = "in_progress"
        try:
            if deal.get("chat_id") and deal.get("message_id"):
                card_text, card_markup = build_deal_card(deal)
                await context.bot.edit_message_text(
                    card_text, chat_id=deal["chat_id"],
                    message_id=deal["message_id"],
                    parse_mode=ParseMode.MARKDOWN_V2, reply_markup=card_markup,
                )
        except Exception as e:
            log.warning(f"pay_confirm card: {e}")

        # Set up relay for both parties
        RELAY[deal["buyer_id"]] = {
            "deal_id": deal_id, "other_id": deal["seller_id"],
            "other_un": deal["seller_un"], "role": "buyer",
        }
        RELAY[deal["seller_id"]] = {
            "deal_id": deal_id, "other_id": deal["buyer_id"],
            "other_un": deal["buyer_un"], "role": "seller",
        }

        # Confirm to buyer — edit their DM and give release button
        await safe_edit(
            q.message,
            f"✅ *Payment Locked — Deal \\#{esc(deal_id)}*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"💰 *{buyer_debit:,} VC* deducted and held securely by bot\\.\n\n"
            f"💬 *Secure Relay Chat Active\\!*\n"
            f"Text, images, files you send here in this DM go to the seller\\.\n\n"
            f"Once the seller delivers, click 🔓 Release Funds below:",
            markup=kb([
                [("🔓 Release Funds", f"deal:wallet_release:{deal_id}")],
                [("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")],
            ]),
        )
        await qans(q, "✅ Payment locked! Chat with seller in this DM.")

        # Notify seller
        await send_dm(
            deal["seller_id"],
            f"✅ *Buyer Locked Payment — Deal \\#{esc(deal_id)}*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"Buyer @{esc(deal['buyer_un'])} locked *₹{deal['amount']:,}* in escrow\\.\n\n"
            f"💬 *Secure Relay Chat Active\\!*\n"
            f"You can text, send images and files here — buyer sees everything\\.\n\n"
            f"Deliver your product/service\\. Buyer will release funds when satisfied\\.",
            markup=kb([[("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")]]),
        )
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"💰 *Wallet Payment Locked — Deal \\#{esc(deal_id)}*\n"
            f"Buyer: @{esc(deal['buyer_un'])} locked {buyer_debit:,} VC"
        )
        return

    # ── Pay Cancel (from DM) ──────────────────────────────────────────────────
    if action == "pay_cancel":
        await safe_edit(
            q.message,
            f"❌ *Payment cancelled\\.*\n\n"
            f"Go to the group and click *💳 Pay Now* when you're ready\\."
        )
        await qans(q, "Payment cancelled.")
        return

    # ── Wallet Release ─────────────────────────────────────────────────────────
    if action == "wallet_release":
        if user.id != deal["buyer_id"]:
            await qans(q, "⛔ Only the buyer can release funds.", alert=True)
            return
        if deal["status"] != "in_progress":
            await qans(q, "Cannot release at this stage.", alert=True)
            return
        fee_pct = deal.get("fee_percent", 1.0)
        buyer_debit, seller_credit, fee_amt = compute_fee(
            deal["amount"], fee_pct, deal.get("fee_payer", "buyer")
        )
        await safe_edit(
            q.message,
            f"🔓 *Confirm Fund Release — Deal \\#{esc(deal_id)}*\n\n"
            f"Releasing *₹{deal['amount']:,}* to @{esc(deal['seller_un'])}\\.\n"
            f"Seller receives: *₹{seller_credit:,}*\n\n"
            f"⚠️ *This cannot be undone\\.* Only confirm after receiving your product/service\\.",
            markup=kb([
                [("✅ Yes, Release Funds Now", f"deal:wallet_release_confirm:{deal_id}")],
                [("❌ No, Keep Holding", f"deal:wallet_release_cancel:{deal_id}")],
            ]),
        )
        await qans(q)
        return

    # ── Wallet Release Confirm ─────────────────────────────────────────────────
    if action == "wallet_release_confirm":
        if user.id != deal["buyer_id"]:
            await qans(q, "⛔ Only the buyer can release funds.", alert=True)
            return
        if deal["status"] != "in_progress":
            await qans(q, "Cannot release at this stage.", alert=True)
            return
        await safe_edit(q.message, "✅ *Releasing funds\\.\\.\\. Deal completing\\!*")
        await qans(q, "🎉 Funds released!")
        # Clean up relay
        RELAY.pop(deal["buyer_id"], None)
        RELAY.pop(deal["seller_id"], None)
        EVIDENCE_AWAIT.pop(deal["buyer_id"], None)
        EVIDENCE_AWAIT.pop(deal["seller_id"], None)
        await complete_deal(context, deal, user)
        return

    # ── Wallet Release Cancel ─────────────────────────────────────────────────
    if action == "wallet_release_cancel":
        await safe_edit(
            q.message,
            f"✅ *Funds still locked — Deal \\#{esc(deal_id)}*\n\n"
            f"Continue chatting with the seller\\.\n"
            f"Release when you're fully satisfied\\.",
            markup=kb([
                [("🔓 Release Funds", f"deal:wallet_release:{deal_id}")],
                [("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")],
            ]),
        )
        await qans(q, "Holding funds. Chat more with seller.")
        return

    # ── Buyer says paid → enter PIN ───────────────────────────────────────────
    if action == "paid":
        if user.id != deal["buyer_id"]:
            await qans(q, "Only the buyer can do this.", alert=True)
            return
        if deal["status"] != "in_progress":
            await qans(q, "Invalid state.", alert=True)
            return

        await db.update_deal(deal_id, status="buyer_paid", paid_at=now_iso())
        deal["status"] = "buyer_paid"

        # Update group card
        try:
            if deal.get("chat_id") and deal.get("message_id"):
                card_text, card_markup = build_deal_card(deal)
                await context.bot.edit_message_text(
                    card_text, chat_id=deal["chat_id"],
                    message_id=deal["message_id"],
                    parse_mode=ParseMode.MARKDOWN_V2, reply_markup=card_markup,
                )
        except Exception as e:
            log.warning(f"paid card edit: {e}")

        # Ask for PIN
        PIN_AWAIT[user.id] = deal_id
        await qans(q, "Enter the PIN the seller gave you.", alert=True)
        await send_dm(
            deal["buyer_id"],
            f"🔑 *Enter the PIN* the seller shared with you:\n"
            f"_Type the 4\\-digit PIN in this chat_"
        )

        # Notify seller
        await send_dm(
            deal["seller_id"],
            f"✅ Buyer says they paid\\!\n"
            f"They are entering your PIN now\\. Once entered, funds will be released\\.\n"
            f"🔑 Your PIN: `{deal['seller_pin']}`"
        )
        return

    # ── Raise Dispute ─────────────────────────────────────────────────────────
    if action == "dispute":
        if user.id not in (deal["buyer_id"], deal["seller_id"]):
            await qans(q, "Only deal parties can raise a dispute.", alert=True)
            return
        if deal["status"] in ("completed", "cancelled", "expired"):
            await qans(q, "Cannot dispute a completed/cancelled deal.", alert=True)
            return
        if deal["status"] == "disputed":
            await qans(q, "⚠️ Dispute already open.", alert=True)
            return

        await db.update_deal(deal_id, status="disputed")
        await db.create_dispute({"deal_id": deal_id, "opened_by": user.id})

        deal["status"] = "disputed"
        card_text, card_markup = build_deal_card(deal)
        await safe_edit(q.message, card_text, card_markup)
        await qans(q, "⚠️ Dispute raised! Admin notified. Check your DM.", alert=True)

        other_id = deal["seller_id"] if user.id == deal["buyer_id"] else deal["buyer_id"]
        other_un = deal["seller_un"] if user.id == deal["buyer_id"] else deal["buyer_un"]

        # Activate persistent evidence collection for BOTH parties
        DISPUTE_AWAIT[user.id] = deal_id  # first text = initial description
        EVIDENCE_AWAIT[user.id] = {"deal_id": deal_id, "count": 0}
        EVIDENCE_AWAIT[other_id] = {"deal_id": deal_id, "count": 0}

        # DM dispute raiser
        await send_dm(
            user.id,
            f"⚠️ *Dispute Opened — Deal \\#{esc(deal_id)}*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"Admin has been notified and will review\\.\n\n"
            f"📨 *Submit your evidence here in this DM:*\n"
            f"• Text: describe the issue\n"
            f"• Screenshots: send photos\n"
            f"• Files/videos: send directly\n\n"
            f"Type *done* when you've submitted everything\\."
        )

        # DM other party
        await send_dm(
            other_id,
            f"⚠️ *Dispute Raised — Deal \\#{esc(deal_id)}*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"@{esc(user.username or str(user.id))} has raised a dispute\\.\n"
            f"Admin will review and make a fair decision\\.\n\n"
            f"📨 *You can submit your side of the story here:*\n"
            f"• Text: your explanation\n"
            f"• Screenshots: supporting proof\n\n"
            f"Type *done* when finished\\."
        )

        # Admin notification with direct contact buttons
        from telegram import InlineKeyboardButton as IKB
        admin_rows = []
        buyer_link = f"tg://user?id={deal['buyer_id']}" if deal.get("buyer_id") else None
        seller_link = f"tg://user?id={deal['seller_id']}" if deal.get("seller_id") else None
        row = []
        if buyer_link:
            row.append(IKB(f"💬 DM Buyer", url=buyer_link))
        if seller_link:
            row.append(IKB(f"💬 DM Seller", url=seller_link))
        if row:
            admin_rows.append(row)
        admin_markup = InlineKeyboardMarkup(admin_rows) if admin_rows else None

        if _bot_app:
            try:
                await _bot_app.bot.send_message(
                    TELEGRAM_ADMIN_ID,
                    f"🚨 *Dispute Opened — Deal \\#{esc(deal_id)}*\n"
                    f"━━━━━━━━━━━━━━━━━\n"
                    f"Raised by: @{esc(user.username or str(user.id))}\n"
                    f"Buyer: @{esc(deal['buyer_un'])} \\| Seller: @{esc(deal['seller_un'])}\n"
                    f"Amount: ₹{deal['amount']:,}\n\n"
                    f"Both parties can DM evidence\\. Use admin panel to resolve\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=admin_markup,
                )
            except Exception as e:
                log.warning(f"dispute admin notify: {e}")
        return

    # ── Cancel Deal ───────────────────────────────────────────────────────────
    if action == "cancel":
        if user.id not in (deal["buyer_id"], deal["seller_id"]):
            await qans(q, "Only deal parties can cancel.", alert=True)
            return
        if deal["status"] not in ("awaiting_payment",):
            await qans(q, "Cannot cancel at this stage.", alert=True)
            return

        # Refund locked VC if any
        fee_pct = deal.get("fee_percent", 1.0)
        buyer_debit, _, _ = compute_fee(deal["amount"], fee_pct, deal.get("fee_payer", "buyer"))

        await db.update_deal(deal_id, status="cancelled")
        deal["status"] = "cancelled"
        card_text, card_markup = build_deal_card(deal)
        await safe_edit(q.message, card_text, card_markup)
        await qans(q, "Deal cancelled.")

        await send_dm(deal["buyer_id"],
                      f"❌ *Deal \\#{esc(deal_id)} cancelled\\.*")
        await send_dm(deal["seller_id"],
                      f"❌ *Deal \\#{esc(deal_id)} cancelled\\.*")
        return

    # ── Pay via Middleman ─────────────────────────────────────────────────────
    if action == "mm_pay":
        if user.id != deal["buyer_id"]:
            await qans(q, "Only the buyer can initiate payment.", alert=True)
            return
        if deal["status"] != "awaiting_payment":
            await qans(q, "Deal is not in payment stage.", alert=True)
            return

        u = await db.get_or_create_user(user.id, user.username)
        if u.get("frozen"):
            await qans(q, "🧊 Your wallet is frozen.", alert=True)
            return

        mms = await db.get_active_middlemen()
        if not mms:
            await qans(q, "⚠️ No middlemen available now. Contact admin.", alert=True)
            return

        await db.update_deal(deal_id, status="mm_connecting")
        deal["status"] = "mm_connecting"
        card_text, card_markup = build_deal_card(deal)
        await safe_edit(q.message, card_text, card_markup)
        await qans(q, "Connecting to middleman... Check your DM!", alert=True)

        MM_STATE[deal_id] = {
            "status": "waiting_mm",
            "mm_id": None,
            "mm_un": None,
            "mm_upi": None,
            "seller_upi": None,
        }

        await send_dm(
            deal["buyer_id"],
            f"🔄 *Finding Middleman — Deal \\#{esc(deal_id)}*\n"
            f"Please wait\\. Our middlemen are being notified\\.\n"
            f"You'll receive further instructions shortly\\."
        )

        for mm in mms:
            mm_markup = kb([[("✅ Enter This Deal", f"mm:enter:{deal_id}")]])
            product_name = deal.get("product_name") or "N/A"
            await send_dm(
                mm["tg_id"],
                f"🆕 *Middleman Needed — Deal \\#{esc(deal_id)}*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"📦 Product: {esc(product_name)}\n"
                f"💰 Amount: ₹{deal['amount']:,}\n"
                f"👤 Buyer: @{esc(deal['buyer_un'])}\n"
                f"📦 Seller: @{esc(deal['seller_un'])}\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"First to click below enters the deal\\.",
                markup=mm_markup,
            )
        return

    # ── Buyer asks to release asset ───────────────────────────────────────────
    if action == "mm_release_ask":
        if user.id != deal["buyer_id"]:
            await qans(q, "Only the buyer can release.", alert=True)
            return
        if deal["status"] != "mm_payment_received":
            await qans(q, "Cannot release at this stage.", alert=True)
            return
        confirm_markup = kb([
            [("✅ Yes, Release Asset", f"mm:release:{deal_id}")],
            [("❌ No, Wait", f"mm:release_no:{deal_id}")],
        ])
        await qans(q, "Confirmation sent to your DM!", alert=True)
        await send_dm(
            deal["buyer_id"],
            f"🔓 *Confirm Release — Deal \\#{esc(deal_id)}*\n\n"
            f"Seller: @{esc(deal['seller_un'])}\n"
            f"Amount: ₹{deal['amount']:,}\n\n"
            f"Are you sure you want to release the asset?",
            markup=confirm_markup,
        )
        return

    await qans(q)


# ─── Wallet system ────────────────────────────────────────────────────────────

async def send_wallet_card(msg_or_q, u: dict, edit: bool = False):
    """Send or edit the wallet dashboard card."""
    badges = json.loads(u.get("badges", "[]") or "[]")
    badge_str = " ".join(badges) if badges else "None"
    rating_count = u.get("rating_count", 0)
    rating = (u.get("rating_sum", 0) / rating_count) if rating_count > 0 else 0.0

    TIER_MAP = {
        "new": "🌱 New", "regular": "⭐ Regular",
        "trusted": "💫 Trusted", "elite": "👑 Elite",
    }
    tier = TIER_MAP.get(u.get("tier", "new"), "🌱 New")

    text = (
        f"🏦 *VAULT\\-PAY WALLET*\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"👤 @{esc(u.get('username') or 'User')}  {esc(tier)}\n"
        f"🏅 Badges: {esc(badge_str)}\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"💳 *Balance: {u.get('balance_vc', 0):,} VC*\n"
        f"🔒 Locked in Deals: {u.get('locked_vc', 0):,} VC\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"🤝 Total Deals: {u.get('total_deals', 0)}\n"
        f"💰 Total Volume: ₹{u.get('total_volume', 0):,}\n"
        f"⭐ Rating: {escn(rating, '.1f')}/5 \\({rating_count} reviews\\)\n"
        f"🏷️ Vouches: {u.get('vouches', 0)}"
    )
    markup = kb([
        [("➕ Deposit", "wal:deposit"), ("➖ Withdraw", "wal:withdraw")],
        [("📜 History", "wal:history"), ("🔗 Referral", "wal:referral")],
    ])
    if edit:
        await safe_edit(msg_or_q, text, markup)
    else:
        await msg_or_q.reply_text(text, parse_mode=ParseMode.MARKDOWN_V2,
                                  reply_markup=markup)


async def cmd_wallet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_chat.type != ChatType.PRIVATE:
        await update.message.reply_text(
            "💬 Use /wallet in *DM* with me\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    user = update.effective_user
    u = await db.get_or_create_user(user.id, user.username)
    WALLET_STATE.pop(user.id, None)  # clear any pending state
    await send_wallet_card(update.message, u, edit=False)


async def handle_wallet_cb(q, context, parts, user):
    action = parts[1] if len(parts) > 1 else ""

    if action == "back":
        WALLET_STATE.pop(user.id, None)
        u = await db.get_or_create_user(user.id, user.username)
        await send_wallet_card(q.message, u, edit=True)
        await qans(q)
        return

    if action == "deposit":
        WALLET_STATE[user.id] = {"step": "deposit_amount"}
        await safe_edit(
            q.message,
            "📥 *Deposit VC*\n\n"
            "1 VC = ₹1 \\(Indian Rupee\\)\n\n"
            f"Send payment to UPI: `{esc(ADMIN_UPI_ID)}`\n\n"
            "Type the amount you want to deposit \\(INR\\):\n"
            "_Minimum: ₹100_",
            kb([[("🔙 Back", "wal:back")]])
        )
        await qans(q)
        return

    if action == "withdraw":
        u = await db.get_or_create_user(user.id, user.username)
        bal = u.get("balance_vc", 0)
        if bal < 100:
            await qans(q, f"Minimum withdrawal is 100 VC. Your balance: {bal} VC.", alert=True)
            return
        WALLET_STATE[user.id] = {"step": "withdraw_amount", "balance": bal}
        await safe_edit(
            q.message,
            f"📤 *Withdraw VC*\n\n"
            f"Available: *{bal:,} VC*\n"
            f"Minimum: 100 VC\n\n"
            f"Type amount to withdraw \\(INR\\):",
            kb([[("🔙 Back", "wal:back")]])
        )
        await qans(q)
        return

    if action == "history":
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM transactions WHERE user_id = $1 ORDER BY at DESC LIMIT 10",
                user.id,
            )
        if not rows:
            await qans(q, "No transactions yet.", alert=True)
            return
        lines = []
        for r in rows:
            d = dict(r)
            sym = "📥" if d["type"] == "deposit" else "📤" if d["type"] == "withdrawal" else "💱"
            st = "✅" if d["status"] in ("approved", "paid", "completed") else "⏳" if d["status"] == "pending" else "❌"
            lines.append(f"{sym} {d['type'].title()} — {d['amount']:,} VC {st}")
        hist_text = "\n".join(lines)
        await safe_edit(
            q.message,
            f"📜 *Transaction History*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"{hist_text}",
            kb([[("🔙 Back", "wal:back")]])
        )
        await qans(q)
        return

    if action == "referral":
        u = await db.get_or_create_user(user.id, user.username)
        ref_code = u.get("referral_code") or f"REF{user.id}"
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            count = await conn.fetchval(
                "SELECT COUNT(*) FROM referrals WHERE referrer = $1", user.id
            ) or 0
        bot_username = (await context.bot.get_me()).username
        link = f"https://t.me/{bot_username}?start={ref_code}"
        await safe_edit(
            q.message,
            f"🔗 *Your Referral Link*\n\n"
            f"`{esc(link)}`\n\n"
            f"👥 Referrals: *{count}*\n"
            f"🎁 Earn *50 VC* for each friend who deposits\\!",
            kb([[("🔙 Back", "wal:back")]])
        )
        await qans(q)
        return

    await qans(q)


async def handle_wallet_text(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    user = update.effective_user
    ws = WALLET_STATE.get(user.id, {})
    step = ws.get("step", "")

    # ── Deposit flow ──────────────────────────────────────────────────────────
    if step == "deposit_amount":
        raw = re.sub(r"[^\d]", "", text)
        if not raw or int(raw) < 100:
            await update.message.reply_text(
                "❌ Minimum deposit is ₹100\\. Try again:",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return
        amount = int(raw)
        ws["amount"] = amount
        ws["step"] = "deposit_screenshot"
        WALLET_STATE[user.id] = ws
        await update.message.reply_text(
            f"💳 *Deposit ₹{amount:,}*\n\n"
            f"1\\. Pay *₹{amount:,}* to UPI: `{esc(ADMIN_UPI_ID)}`\n"
            f"2\\. Take a screenshot of the payment\n"
            f"3\\. Send the screenshot here 👇",
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=kb([[("❌ Cancel", "wal:back")]]),
        )
        return

    if step == "withdraw_amount":
        raw = re.sub(r"[^\d]", "", text)
        if not raw or int(raw) < 100:
            await update.message.reply_text(
                "❌ Minimum withdrawal is 100 VC\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return
        amount = int(raw)
        bal = ws.get("balance", 0)
        if amount > bal:
            await update.message.reply_text(
                f"❌ Insufficient balance\\! You have *{bal:,} VC*\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return
        ws["amount"] = amount
        ws["step"] = "withdraw_upi"
        WALLET_STATE[user.id] = ws
        await update.message.reply_text(
            f"📤 *Withdraw {amount:,} VC*\n\n"
            f"Enter your UPI ID to receive ₹{amount:,}:",
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=kb([[("❌ Cancel", "wal:back")]]),
        )
        return

    if step == "withdraw_upi":
        upi = text.strip()
        if "@" not in upi or len(upi) < 5:
            await update.message.reply_text(
                "❌ Invalid UPI ID\\. Format: `name@bank`",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return
        ws["upi"] = upi
        ws["step"] = "withdraw_confirm"
        WALLET_STATE[user.id] = ws
        amount = ws["amount"]
        await update.message.reply_text(
            f"✅ *Confirm Withdrawal*\n\n"
            f"Amount: *{amount:,} VC* \\(₹{amount:,}\\)\n"
            f"UPI: `{esc(upi)}`\n\n"
            f"Confirm to submit request\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=kb([
                [("✅ Confirm", "wal:withdraw_confirm"),
                 ("❌ Cancel", "wal:back")],
            ]),
        )
        return


async def handle_wallet_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle deposit screenshot photo in DM."""
    user = update.effective_user
    if update.effective_chat.type != ChatType.PRIVATE:
        return
    ws = WALLET_STATE.get(user.id, {})
    if ws.get("step") != "deposit_screenshot":
        # State was lost or the user sent a photo out of order (e.g. skipped typing an amount) —
        # tell them instead of silently doing nothing, which used to look like a dead button.
        await update.message.reply_text(
            "🤔 I wasn't expecting a screenshot right now\\. Open /wallet → *Deposit* and enter "
            "an amount first, then send the payment screenshot\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    file_id = None
    if update.message.photo:
        file_id = update.message.photo[-1].file_id
    elif update.message.document and (update.message.document.mime_type or "").startswith("image/"):
        file_id = update.message.document.file_id
    if not file_id:
        return

    amount = ws.get("amount", 0)
    u = await db.get_or_create_user(user.id, user.username)

    import uuid as _uuid
    tx_id = str(_uuid.uuid4())
    await db.create_transaction({
        "id": tx_id,
        "type": "deposit",
        "user_id": user.id,
        "amount": amount,
        "status": "pending",
        "data": {
            "username": user.username or str(user.id),
            "tg_id": user.id,
            "photo_file_id": file_id,
        },
        "at": now_iso(),
    })

    WALLET_STATE.pop(user.id, None)

    await update.message.reply_text(
        f"📥 *Deposit Request Submitted\\!*\n\n"
        f"Amount: *{amount:,} VC*\n"
        f"Status: 🤖 AI is verifying your screenshot\\.\\.\\.\n\n"
        f"This usually takes a few seconds\\. If the AI can't confirm it, admin will review manually\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=kb([[("🏦 Wallet", "wal:back")]]),
    )

    # Forward screenshot to admin
    await send_dm(
        TELEGRAM_ADMIN_ID,
        f"📥 *New Deposit Request*\n"
        f"User: @{esc(user.username)} \\(ID: {user.id}\\)\n"
        f"Amount: *{amount:,} VC*\n"
        f"TX: `{esc(tx_id[:12])}...`\n\n"
        f"Screenshot below 👇"
    )
    try:
        await context.bot.send_photo(TELEGRAM_ADMIN_ID, file_id,
                                     caption=f"Deposit proof — {amount} VC — @{user.username}")
    except Exception as e:
        log.warning(f"admin photo: {e}")

    # AI verifies the screenshot against the claimed amount — auto-credits on a clear match,
    # auto-rejects on a clear mismatch/fraud signal, or leaves it pending for manual review.
    asyncio.create_task(_run_deposit_ai_verify(tx_id))


async def _run_deposit_ai_verify(tx_id: str):
    try:
        import ai_judge
        await ai_judge.verify_deposit(tx_id)
    except Exception as e:
        log.error(f"deposit AI verify failed for {tx_id}: {e}", exc_info=True)


async def handle_withdraw_confirm_cb(q, context, user):
    ws = WALLET_STATE.get(user.id, {})
    if ws.get("step") != "withdraw_confirm":
        await qans(q)
        return

    amount = ws.get("amount", 0)
    upi = ws.get("upi", "")
    u = await db.get_or_create_user(user.id, user.username)

    if u.get("balance_vc", 0) < amount:
        await qans(q, "Insufficient balance!", alert=True)
        WALLET_STATE.pop(user.id, None)
        return

    # Deduct from balance
    await db.adjust_balance(user.id, delta_balance=-amount)

    import uuid as _uuid
    tx_id = str(_uuid.uuid4())
    await db.create_transaction({
        "id": tx_id,
        "type": "withdrawal",
        "user_id": user.id,
        "amount": amount,
        "status": "pending",
        "data": {
            "username": user.username or str(user.id),
            "tg_id": user.id,
            "address": upi,
        },
        "at": now_iso(),
    })

    WALLET_STATE.pop(user.id, None)
    u_updated = await db.get_or_create_user(user.id, user.username)
    await send_wallet_card(q.message, u_updated, edit=True)
    await qans(q, f"✅ Withdrawal of {amount} VC submitted!", alert=True)

    await send_dm(
        TELEGRAM_ADMIN_ID,
        f"📤 *Withdrawal Request*\n"
        f"User: @{esc(user.username)} \\(ID: {user.id}\\)\n"
        f"Amount: *{amount:,} VC*\n"
        f"UPI: `{esc(upi)}`\n"
        f"TX: `{esc(tx_id[:12])}...`"
    )


# ─── Rating handler ────────────────────────────────────────────────────────────

async def handle_rating_cb(q, context, parts, user):
    if len(parts) < 4:
        await qans(q)
        return
    stars = int(parts[1])
    deal_id = parts[2]
    target_id = int(parts[3])

    target = await db.get_user(target_id)
    if not target:
        await qans(q, "User not found.", alert=True)
        return

    new_sum = target.get("rating_sum", 0) + stars
    new_count = target.get("rating_count", 0) + 1
    await db.update_user(target_id, rating_sum=new_sum, rating_count=new_count)

    await safe_edit(
        q.message,
        f"⭐ *Thank you for rating\\!*\n"
        f"You gave @{esc(target.get('username', str(target_id)))} *{stars} star{'s' if stars > 1 else ''}*\\."
    )
    await qans(q, f"{'⭐' * stars} Rating submitted!", alert=True)


# ─── /rep & /profile ──────────────────────────────────────────────────────────

async def cmd_rep(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    if not context.args:
        await msg.reply_text(
            "Usage: /rep @username",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    target_un = context.args[0].lstrip("@").strip()
    if not target_un:
        return

    u = await db.get_user_by_username(target_un)
    if not u:
        await msg.reply_text(
            f"❌ User @{esc(target_un)} not found\\. They must have used the bot\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return

    TIER_MAP = {
        "new": "🌱 New", "regular": "⭐ Regular",
        "trusted": "💫 Trusted", "elite": "👑 Elite",
    }
    tier = TIER_MAP.get(u.get("tier", "new"), "🌱 New")
    rating_count = u.get("rating_count", 0)
    rating = (u.get("rating_sum", 0) / rating_count) if rating_count > 0 else 0.0
    total_deals = u.get("total_deals", 0)
    total_volume = u.get("total_volume", 0)
    success_rate = "N/A"
    if total_deals > 0:
        success_rate = f"{min(100, int(total_deals * 100 / max(total_deals, 1)))}%"

    badges = json.loads(u.get("badges", "[]") or "[]")
    badge_str = " ".join(badges) if badges else "None"

    scam = "🔴 FLAGGED SCAMMER" if u.get("scam_flag") else "🟢 Clean"
    frozen = " \\| 🧊 FROZEN" if u.get("frozen") else ""

    # Vouches
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        vouch_rows = await conn.fetch(
            """SELECT v.text, u2.username as from_un
               FROM vouches v
               LEFT JOIN users u2 ON u2.tg_id = v.from_id
               WHERE v.to_id = $1
               ORDER BY v.at DESC LIMIT 5""",
            u["tg_id"],
        )

    vouch_lines = ""
    if vouch_rows:
        lines = [
            f"• _{esc(v['text'] or '—')}_ — @{esc(v['from_un'] or 'anon')}"
            for v in vouch_rows
        ]
        vouch_lines = "\n*Recent Vouches:*\n" + "\n".join(lines) + "\n"

    text = (
        f"🛡️ *TRUST PROFILE: @{esc(target_un)}*\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"🏷️ Tier: {esc(tier)}\n"
        f"🏅 Badges: {esc(badge_str)}\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"🤝 Deals: {total_deals}\n"
        f"📈 Success Rate: {esc(success_rate)}\n"
        f"💰 Volume: ₹{total_volume:,}\n"
        f"⭐ Rating: {escn(rating, '.1f')}/5 \\({rating_count} reviews\\)\n"
        f"🏅 Vouches: {u.get('vouches', 0)}\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"🚨 Status: {esc(scam)}{frozen}"
        f"{vouch_lines}"
    )
    await msg.reply_text(text, parse_mode=ParseMode.MARKDOWN_V2)


# ─── /mydeals ─────────────────────────────────────────────────────────────────

async def cmd_mydeals(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    deals = await db.get_user_deals(user.id)
    if not deals:
        await update.message.reply_text(
            "📋 You have no active deals\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    lines = []
    for d in deals[:5]:
        role = "Buyer" if d["buyer_id"] == user.id else "Seller"
        other_un = d["seller_un"] if role == "Buyer" else d["buyer_un"]
        lines.append(
            f"• Deal \\#{esc(d['deal_id'])} — ₹{d['amount']:,} — {esc(role)} "
            f"with @{esc(other_un)} — _{esc(d['status'])}_"
        )
    await update.message.reply_text(
        "📋 *Your Active Deals:*\n" + "\n".join(lines),
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ─── /appeal ──────────────────────────────────────────────────────────────────

async def cmd_appeal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """/appeal <deal_id> — one re-review of a resolved dispute's verdict, human-confirmed only."""
    user = update.effective_user
    args = context.args
    if not args:
        await update.message.reply_text(
            "Usage: `/appeal DEAL_ID`\n"
            "One appeal is allowed per dispute, within 24h of resolution\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    deal_id = args[0].strip().lstrip("#")
    import ai_judge
    result = await ai_judge.file_appeal(deal_id, user.id)
    prefix = "✅" if result.get("ok") else "❌"
    await update.message.reply_text(
        f"{prefix} {esc(result.get('detail', ''))}",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ─── /referral ────────────────────────────────────────────────────────────────

async def cmd_referral(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await db.get_or_create_user(user.id, user.username)
    ref_code = u.get("referral_code") or f"REF{user.id}"
    pool = await db.get_pool()
    async with pool.acquire() as conn:
        count = await conn.fetchval(
            "SELECT COUNT(*) FROM referrals WHERE referrer = $1", user.id
        ) or 0
    bot_username = (await context.bot.get_me()).username
    link = f"https://t.me/{bot_username}?start={ref_code}"
    await update.message.reply_text(
        f"🔗 *Your Referral Link*\n\n"
        f"`{esc(link)}`\n\n"
        f"👥 Total Referrals: *{count}*\n"
        f"🎁 Earn *50 VC* per referred user who deposits\\!",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ─── /start ───────────────────────────────────────────────────────────────────

async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    u = await db.get_or_create_user(user.id, user.username)

    # Handle referral code and deep links
    if context.args:
        ref_code = context.args[0]
        if ref_code.startswith("REF"):
            referrer_id_str = ref_code[3:]
            if referrer_id_str.isdigit() and int(referrer_id_str) != user.id:
                referrer_id = int(referrer_id_str)
                pool = await db.get_pool()
                async with pool.acquire() as conn:
                    existing = await conn.fetchrow(
                        "SELECT id FROM referrals WHERE referred = $1", user.id
                    )
                    if not existing:
                        import uuid as _uuid
                        await conn.execute(
                            "INSERT INTO referrals (id, referrer, referred, at) VALUES ($1,$2,$3,$4)",
                            str(_uuid.uuid4()), referrer_id, user.id, now_iso(),
                        )
                        await db.adjust_balance(referrer_id, delta_balance=50)
                        await send_dm(referrer_id,
                                      f"🎁 *Referral Bonus\\!* @{esc(user.username)} joined\\. "
                                      f"\\+50 VC added to your wallet\\!")

        # ── Relay secure chat deep link ────────────────────────────────────────
        elif ref_code.startswith("relay_"):
            if update.effective_chat.type != ChatType.PRIVATE:
                return
            deal_id = ref_code[6:]
            deal = await db.get_deal(deal_id)
            if not deal or deal.get("status") not in ("in_progress", "buyer_paid"):
                await update.message.reply_text(
                    "❌ Secure chat not available\\. Deal not found or not in progress\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
                return
            if user.id == deal["buyer_id"]:
                role = "buyer"; other_id = deal["seller_id"]; other_un = deal["seller_un"]
            elif user.id == deal["seller_id"]:
                role = "seller"; other_id = deal["buyer_id"]; other_un = deal["buyer_un"]
            else:
                await update.message.reply_text(
                    "⛔ You are not part of this deal\\.", parse_mode=ParseMode.MARKDOWN_V2
                )
                return
            RELAY[user.id] = {"deal_id": deal_id, "other_id": other_id, "other_un": other_un, "role": role}
            action_btns = []
            if role == "buyer":
                action_btns.append([("🔓 Release Funds", f"deal:wallet_release:{deal_id}")])
            action_btns.append([("⚠️ Raise Dispute", f"deal:dispute:{deal_id}")])
            relay_hint = (
                "🔓 Click Release Funds when the seller has delivered\\."
                if role == "buyer"
                else "⏳ Deliver and wait for buyer to release funds\\."
            )
            await update.message.reply_text(
                f"💬 *Secure Deal Chat — \\#{esc(deal_id)}*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"You are the *{esc(role)}*\\. Chatting with @{esc(other_un)}\\.\n\n"
                f"Send text, photos, and files here — everything is relayed securely through the bot\\.\n\n"
                f"{relay_hint}",
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=kb(action_btns),
            )
            return

        # ── Middleman deep link: buyer ────────────────────────────────────────
        elif ref_code.startswith("mm_B_"):
            if update.effective_chat.type != ChatType.PRIVATE:
                return
            deal_id = ref_code[5:]
            deal = await db.get_deal(deal_id)
            if not deal:
                await update.message.reply_text("❌ Deal not found\\.", parse_mode=ParseMode.MARKDOWN_V2)
                return
            if user.id != deal["buyer_id"]:
                await update.message.reply_text("⛔ Only the buyer can use this link\\.", parse_mode=ParseMode.MARKDOWN_V2)
                return
            mm_st = MM_STATE.get(deal_id, {})
            if mm_st.get("mm_upi"):
                buyer_markup = kb([[("✅ I've Paid", f"mm:buyer_paid:{deal_id}")],
                                   [("⚠️ Dispute", f"deal:dispute:{deal_id}")]])
                await update.message.reply_text(
                    f"💳 *Pay to Middleman — Deal \\#{esc(deal_id)}*\n"
                    f"━━━━━━━━━━━━━━━━━\n"
                    f"Amount: *₹{deal['amount']:,}*\n"
                    f"UPI: `{esc(mm_st['mm_upi'])}`\n\n"
                    f"Pay and click ✅ below\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=buyer_markup,
                )
            elif mm_st.get("mm_id"):
                await update.message.reply_text(
                    "⏳ Middleman connected\\. Awaiting payment instructions\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            else:
                await update.message.reply_text(
                    "🔄 Finding a middleman\\. Please wait\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            return

        # ── Middleman deep link: seller ───────────────────────────────────────
        elif ref_code.startswith("mm_S_"):
            if update.effective_chat.type != ChatType.PRIVATE:
                return
            deal_id = ref_code[5:]
            deal = await db.get_deal(deal_id)
            if not deal:
                await update.message.reply_text("❌ Deal not found\\.", parse_mode=ParseMode.MARKDOWN_V2)
                return
            if user.id != deal["seller_id"]:
                await update.message.reply_text("⛔ Only the seller can use this link\\.", parse_mode=ParseMode.MARKDOWN_V2)
                return
            if deal["status"] != "mm_asset_released":
                await update.message.reply_text("⚠️ Deal is not in the payment stage yet\\.", parse_mode=ParseMode.MARKDOWN_V2)
                return
            MM_DM_AWAIT[user.id] = {"role": "seller", "deal_id": deal_id, "step": "give_upi"}
            await update.message.reply_text(
                f"✅ *Connected — Deal \\#{esc(deal_id)}*\n\n"
                f"Type your UPI ID to receive *₹{deal['amount']:,}*:",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            mm_st = MM_STATE.get(deal_id, {})
            mm_id = mm_st.get("mm_id")
            if mm_id:
                await send_dm(mm_id,
                              f"📦 *Seller connected — Deal \\#{esc(deal_id)}*\n"
                              f"@{esc(deal['seller_un'])} is providing their UPI\\.")
            return

    if update.effective_chat.type != ChatType.PRIVATE:
        return

    await update.message.reply_text(
        f"👋 Welcome to *Vault\\-Pay Escrow Bot*\\!\n\n"
        f"🤝 Secure peer\\-to\\-peer escrow for Indian traders\\.\n\n"
        f"*Commands:*\n"
        f"• /wallet — Your VC wallet\n"
        f"• /rep @user — Trust profile\n"
        f"• /mydeals — Active deals\n"
        f"• /referral — Earn rewards\n\n"
        f"📢 Use /escrow in a *group* to start a deal\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
    )


# ─── +vouch handler ───────────────────────────────────────────────────────────

async def handle_vouch(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle +vouch @user text in groups — creates pending vouch awaiting admin approval."""
    msg = update.message
    if not msg or not msg.text:
        return
    text = msg.text.strip()
    if not text.lower().startswith("+vouch"):
        return
    parts = text.split(None, 2)
    if len(parts) < 3:
        await msg.reply_text(
            "Usage: `\\+vouch @username Your reason for vouching`",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    target_un = parts[1].lstrip("@")
    vouch_text = parts[2].strip()
    if not vouch_text:
        return
    user = update.effective_user

    target = await db.get_user_by_username(target_un)
    if not target:
        await msg.reply_text(
            f"❌ @{esc(target_un)} not found\\. They must start the bot first\\.",
            parse_mode=ParseMode.MARKDOWN_V2,
        )
        return
    if target["tg_id"] == user.id:
        await msg.reply_text("❌ You cannot vouch for yourself\\.", parse_mode=ParseMode.MARKDOWN_V2)
        return

    pool = await db.get_pool()
    async with pool.acquire() as conn:
        existing = await conn.fetchrow(
            "SELECT id, status FROM vouches WHERE from_id = $1 AND to_id = $2",
            user.id, target["tg_id"],
        )
        if existing:
            status = existing["status"]
            if status == "pending":
                await msg.reply_text(
                    f"⏳ Your vouch for @{esc(target_un)} is already *pending* approval\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            else:
                await msg.reply_text(
                    f"✅ You have already vouched for @{esc(target_un)}\\.",
                    parse_mode=ParseMode.MARKDOWN_V2,
                )
            return
        import uuid as _uuid
        vouch_id = str(_uuid.uuid4())
        await conn.execute(
            """INSERT INTO vouches (id, from_id, to_id, text, at, status, proof_json)
               VALUES ($1,$2,$3,$4,$5,'pending','[]')""",
            vouch_id, user.id, target["tg_id"], vouch_text, now_iso(),
        )

    # Confirm to voucher with "Add Proof" button
    await msg.reply_text(
        f"⏳ *Vouch submitted for @{esc(target_un)}\\!*\n"
        f"━━━━━━━━━━━━━━━━━\n"
        f"Status: *Pending admin approval*\n\n"
        f"📸 *Boost approval:* Add proof screenshots \\(chat history, reviews, etc\\)\\.",
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=kb([[("📸 Add Proof Screenshots", f"vouch:add_proof:{vouch_id}")]]),
    )

    # Notify admin with approve/reject buttons
    from telegram import InlineKeyboardButton as IKB
    admin_markup = InlineKeyboardMarkup([
        [IKB("✅ Approve Vouch", callback_data=f"admin_vouch:approve:{vouch_id}"),
         IKB("❌ Reject", callback_data=f"admin_vouch:reject:{vouch_id}")],
        [IKB("💬 DM Voucher", url=f"tg://user?id={user.id}"),
         IKB("💬 DM Recipient", url=f"tg://user?id={target['tg_id']}")],
    ])
    if _bot_app:
        try:
            await _bot_app.bot.send_message(
                TELEGRAM_ADMIN_ID,
                f"🤝 *New Vouch Pending*\n"
                f"━━━━━━━━━━━━━━━━━\n"
                f"From: @{esc(user.username or str(user.id))}\n"
                f"To: @{esc(target_un)}\n\n"
                f"📝 _{esc(vouch_text[:300])}_\n\n"
                f"📸 No proof yet \\(voucher can add via button\\)\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=admin_markup,
            )
        except Exception as e:
            log.warning(f"vouch admin notify: {e}")


# ─── Vouch callbacks (vouch:add_proof) ───────────────────────────────────────

async def handle_vouch_cb(q, context, parts, user):
    action = parts[1] if len(parts) > 1 else ""
    vouch_id = parts[2] if len(parts) > 2 else ""
    if action == "add_proof":
        vouch = await db.get_vouch_by_id(vouch_id)
        if not vouch:
            await qans(q, "❌ Vouch not found.", alert=True)
            return
        if vouch["from_id"] != user.id:
            await qans(q, "⛔ This is not your vouch.", alert=True)
            return
        if vouch["status"] != "pending":
            await qans(q, f"This vouch is already {vouch.get('status','processed')}.", alert=True)
            return
        VOUCH_PROOF_AWAIT[user.id] = {"vouch_id": vouch_id, "proofs": []}
        await send_dm(
            user.id,
            f"📸 *Submit Proof Screenshots*\n"
            f"━━━━━━━━━━━━━━━━━\n"
            f"Send up to *3 screenshots* \\(chat history, reviews, transaction records\\)\\.\n"
            f"Type *done* when finished\\.",
        )
        await qans(q, "✅ Check your DM to submit proof screenshots!", alert=True)
    else:
        await qans(q)


async def handle_admin_vouch_cb(q, context, parts, user):
    action = parts[1] if len(parts) > 1 else ""
    vouch_id = parts[2] if len(parts) > 2 else ""
    if action == "approve":
        v = await db.approve_vouch(vouch_id)
        if not v:
            await qans(q, "❌ Vouch not found or already processed.", alert=True)
            return
        orig_text = q.message.text or ""
        await safe_edit(q.message, f"✅ *Vouch APPROVED*\n\n{esc(orig_text[:300])}")
        await qans(q, "✅ Vouch approved!")
        if v.get("to_id"):
            to_un = v.get("to_un") or str(v.get("to_id", ""))
            from_un = v.get("from_un") or str(v.get("from_id", ""))
            await send_dm(
                v["to_id"],
                f"🎉 *Vouch Approved\\!*\n"
                f"A verified vouch from @{esc(from_un)} has been added to your profile\\.\n"
                f"Your trust score has been updated\\!",
            )
        if v.get("from_id"):
            to_un = v.get("to_un") or str(v.get("to_id", ""))
            await send_dm(
                v["from_id"],
                f"✅ *Your vouch for @{esc(to_un)} was approved by admin\\!*",
            )
    elif action == "reject":
        v = await db.reject_vouch(vouch_id)
        if not v:
            await qans(q, "❌ Vouch not found or already processed.", alert=True)
            return
        orig_text = q.message.text or ""
        await safe_edit(q.message, f"❌ *Vouch REJECTED*\n\n{esc(orig_text[:300])}")
        await qans(q, "❌ Vouch rejected.")
        if v.get("from_id"):
            to_un = v.get("to_un") or str(v.get("to_id", ""))
            await send_dm(
                v["from_id"],
                f"❌ *Vouch Rejected*\n"
                f"Your vouch for @{esc(to_un)} was not approved\\.\n"
                f"Submit stronger proof if you believe it's valid\\.",
            )
    else:
        await qans(q)


# ─── DM photo router ──────────────────────────────────────────────────────────

async def handle_dm_photo(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Route photos in DM: relay → vouch proof → dispute evidence → wallet deposit.

    Also handles screenshots sent as an uncompressed "file"/document (image/*) — a very common
    case on Telegram Desktop (drag-and-drop or "send without compression"). Without this, those
    screenshots arrived as a `document` update, which the old photo-only handler never saw at
    all — evidence/deposit proof looked like it vanished into thin air."""
    msg = update.message
    if not msg:
        return
    file_id = None
    if msg.photo:
        file_id = msg.photo[-1].file_id
    elif msg.document and (msg.document.mime_type or "").startswith("image/"):
        file_id = msg.document.file_id
    if not file_id:
        return
    user = update.effective_user

    # Relay: forward photo to other party
    if user.id in RELAY:
        r = RELAY[user.id]
        deal = await db.get_deal(r["deal_id"])
        if deal and deal["status"] in ("in_progress", "buyer_paid"):
            role_label = "Buyer" if r["role"] == "buyer" else "Seller"
            try:
                # copy_message preserves whichever type it actually is (compressed photo or
                # uncompressed image document) — re-sending a document's file_id via send_photo
                # would fail, since Telegram ties file_id to its original upload type.
                await context.bot.copy_message(
                    chat_id=r["other_id"], from_chat_id=msg.chat_id, message_id=msg.message_id,
                    caption=f"📷 {role_label} sent a photo",
                )
            except Exception as e:
                log.warning(f"relay photo: {e}")
        return

    # Vouch proof screenshots
    if user.id in VOUCH_PROOF_AWAIT:
        ctx = VOUCH_PROOF_AWAIT[user.id]
        proofs = ctx.get("proofs", [])
        if len(proofs) >= 3:
            await msg.reply_text(
                "❌ Max 3 screenshots reached\\. Type *done* to submit\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            return
        proofs.append(file_id)
        ctx["proofs"] = proofs
        import json as _j
        await db.update_vouch_proof(ctx["vouch_id"], _j.dumps(proofs))
        remaining = 3 - len(proofs)
        if remaining > 0:
            await msg.reply_text(
                f"✅ Screenshot {len(proofs)}/3 saved\\. {remaining} slot\\(s\\) left\\. Send more or type *done*\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        else:
            VOUCH_PROOF_AWAIT.pop(user.id, None)
            await msg.reply_text(
                "✅ *All 3 screenshots saved\\!* Proof submitted — admin will review\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        if _bot_app:
            try:
                await context.bot.copy_message(
                    chat_id=TELEGRAM_ADMIN_ID, from_chat_id=msg.chat_id, message_id=msg.message_id,
                    caption=f"📸 Vouch proof [{len(proofs)}/3] — {ctx['vouch_id'][:8]} | @{user.username or user.id}",
                )
            except Exception as e:
                log.warning(f"vouch proof admin: {e}")
        return

    # Dispute evidence screenshots
    if user.id in EVIDENCE_AWAIT:
        ctx = EVIDENCE_AWAIT[user.id]
        deal_id = ctx["deal_id"]
        ctx["count"] = ctx.get("count", 0) + 1
        await db.add_dispute_message(deal_id, {
            "from": user.username or str(user.id),
            "type": "photo", "file_id": file_id, "at": now_iso(),
        })
        if _bot_app:
            try:
                await context.bot.copy_message(
                    chat_id=TELEGRAM_ADMIN_ID, from_chat_id=msg.chat_id, message_id=msg.message_id,
                    caption=f"🚨 Dispute evidence — Deal #{deal_id} | @{user.username or user.id}",
                )
            except Exception as e:
                log.warning(f"evidence photo admin: {e}")

        # A photo's caption can carry "done" (common on mobile: attach caption, then send) —
        # without this check, evidence sent with a "done" caption silently never finished.
        caption = (msg.caption or "").lower().strip()
        if caption in ("done", "finish", "/done"):
            EVIDENCE_AWAIT.pop(user.id, None)
            await msg.reply_text(
                "✅ *Evidence package complete\\!* Admin \\(and our AI judge\\) will review your case\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            await _maybe_trigger_ai_judge(deal_id, user.id)
        else:
            await msg.reply_text(
                f"📸 *Screenshot \\#{ctx['count']} saved* as evidence\\.\n"
                f"Send more or type *done* when finished\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
        return

    # Default: wallet deposit screenshot
    await handle_wallet_photo(update, context)


async def _maybe_trigger_ai_judge(deal_id: str, user_id: int):
    """Kick off the AI judge once the right people have said 'done'.

    First round: needs BOTH buyer and seller. After a "need more evidence" round, the AI only
    re-arms EVIDENCE_AWAIT for whichever party it actually asked a follow-up — so from then on
    we only need THAT party (or parties) to say done, not force the other side to re-confirm.
    """
    if (await db.get_deal(deal_id) or {}).get("payment_method", "wallet") != "wallet":
        return  # middleman deals are human-only, see ai_judge.py docstring

    done_set = DISPUTE_DONE.setdefault(deal_id, set())
    done_set.add(user_id)

    dispute = await db.get_dispute(deal_id)
    pending_raw = dispute.get("ai_pending_from") if dispute else None
    try:
        pending = json.loads(pending_raw) if pending_raw else []
    except Exception:
        pending = []

    if pending:
        required = set(pending)
    else:
        deal = await db.get_deal(deal_id)
        if not deal:
            return
        required = {deal.get("buyer_id"), deal.get("seller_id")} - {None}

    if required and required.issubset(done_set):
        DISPUTE_DONE.pop(deal_id, None)
        asyncio.create_task(_run_ai_judge_safe(deal_id))


async def _run_ai_judge_safe(deal_id: str):
    try:
        import ai_judge
        await ai_judge.judge_and_apply(deal_id)
    except Exception as e:
        log.error(f"AI judge run failed for {deal_id}: {e}")


async def chase_evidence_deadlines():
    """Autonomous evidence chase: once a party's 24h evidence deadline passes, stop waiting
    and let the AI decide with whatever evidence exists (silence counts against the silent side)."""
    try:
        import ai_judge
        deal_ids = await db.get_open_disputes_with_expired_deadline()
        for deal_id in deal_ids:
            dispute = await db.get_dispute(deal_id)
            if not dispute:
                continue
            pending = json.loads(dispute.get("ai_pending_from") or "[]")
            for uid in pending:
                EVIDENCE_AWAIT.pop(uid, None)
            await db.update_dispute(deal_id, evidence_deadline="", ai_pending_from="[]")
            note = (
                "AUTOMATED NOTE: the evidence deadline given to the party/parties above has passed "
                "without a satisfactory response. Weigh continued silence on a direct question against "
                "that party, and reach a final decision now rather than asking again."
            )
            await ai_judge.judge_and_apply(deal_id, deadline_note=note, force_final=True)
    except Exception as e:
        log.error(f"chase_evidence_deadlines failed: {e}")


# ─── Auto-nudge stale deals ───────────────────────────────────────────────────

async def nudge_stale_deals():
    """DM parties on deals stale >4h and not nudged in last 12h."""
    from datetime import datetime, timezone, timedelta
    try:
        pool = await db.get_pool()
        stale_cut = (datetime.now(timezone.utc) - timedelta(hours=4)).isoformat()
        nudge_cut = (datetime.now(timezone.utc) - timedelta(hours=12)).isoformat()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                """SELECT * FROM deals
                   WHERE status IN ('awaiting_payment','in_progress','buyer_paid','mm_connecting')
                   AND created_at < $1
                   AND (nudged_at IS NULL OR nudged_at < $2)
                   LIMIT 50""",
                stale_cut, nudge_cut,
            )
        messages = {
            "awaiting_payment": "💳 Payment hasn't been made yet\\. Go to the group and click *Pay Now*\\.",
            "in_progress": "🔄 Deal in progress\\. Seller: deliver\\. Buyer: release funds when satisfied\\.",
            "buyer_paid": "✅ Buyer marked paid\\. Seller: confirm receipt\\.",
            "mm_connecting": "🤝 Middleman connection pending\\. Contact admin if stuck\\.",
        }
        for r in rows:
            deal = dict(r)
            did = deal["deal_id"]
            if did in NUDGED:
                continue
            NUDGED.add(did)
            nudge = messages.get(deal.get("status", ""), "⏰ Your deal needs attention\\.")
            for uid in filter(None, [deal.get("buyer_id"), deal.get("seller_id")]):
                await send_dm(
                    uid,
                    f"⏰ *Deal \\#{esc(did)} — Reminder*\n\n{nudge}\n\nReturn to the group to continue\\."
                )
            pool2 = await db.get_pool()
            async with pool2.acquire() as conn2:
                await conn2.execute(
                    "UPDATE deals SET nudged_at = $1 WHERE deal_id = $2", now_iso(), did
                )
            log.info(f"Nudged deal {did}")
    except Exception as e:
        log.error(f"nudge_stale_deals: {e}", exc_info=True)


# ─── Auto-whitelist on bot added to group ────────────────────────────────────

async def on_new_member(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.new_chat_members:
        return
    me = await context.bot.get_me()
    chat = update.effective_chat
    for member in update.message.new_chat_members:
        if member.id == me.id:
            await db.add_group(chat.id, chat.title or str(chat.id), "auto")
            await update.message.reply_text(
                "✅ *Vault\\-Pay Escrow* is now active in this group\\!\n"
                "Use /escrow to start a deal\\.",
                parse_mode=ParseMode.MARKDOWN_V2,
            )
            log.info(f"Bot added to group {chat.id} — auto-whitelisted")


# ─── Central callback router — NO pre-answer (each handler calls qans) ───────

async def on_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    if not q:
        return
    data = q.data or ""
    user = q.from_user
    parts = data.split(":")

    try:
        prefix = parts[0]
        if prefix == "esc":
            await handle_escrow_cb(q, context, parts, user)
        elif prefix == "deal":
            await handle_deal_action(q, context, parts, user)
        elif prefix == "mm":
            await handle_mm_cb(q, context, parts, user)
        elif prefix == "wal":
            if len(parts) > 1 and parts[1] == "withdraw_confirm":
                await handle_withdraw_confirm_cb(q, context, user)
            else:
                await handle_wallet_cb(q, context, parts, user)
        elif prefix == "rate":
            await handle_rating_cb(q, context, parts, user)
        elif prefix == "vouch":
            await handle_vouch_cb(q, context, parts, user)
        elif prefix == "admin_vouch":
            if user.id != TELEGRAM_ADMIN_ID:
                await qans(q, "⛔ Admin only.", alert=True)
                return
            await handle_admin_vouch_cb(q, context, parts, user)
        else:
            await qans(q)
    except Exception as e:
        log.error(f"Callback error [{data}]: {e}", exc_info=True)
        await qans(q, "⚠️ An error occurred. Please try again.", alert=True)


# ─── Scheduled jobs ───────────────────────────────────────────────────────────

async def expire_deals(context: ContextTypes.DEFAULT_TYPE = None):
    """Expire deals that have passed their 2h deadline."""
    try:
        pool = await db.get_pool()
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                "SELECT * FROM deals WHERE status IN ('awaiting_payment','in_progress','buyer_paid') "
                "AND expires_at IS NOT NULL AND expires_at < $1",
                now_iso(),
            )
        for r in rows:
            deal = dict(r)
            deal_id = deal["deal_id"]
            await db.update_deal(deal_id, status="expired")

            # Refund locked VC to buyer
            if deal.get("locked_amount", 0) > 0:
                await db.adjust_balance(
                    deal["buyer_id"],
                    delta_balance=deal["locked_amount"],
                    delta_locked=-deal["locked_amount"],
                )

            # Edit group card
            deal["status"] = "expired"
            card_text, _ = build_deal_card(deal)
            try:
                if deal.get("chat_id") and deal.get("message_id"):
                    await _bot_app.bot.edit_message_text(
                        card_text,
                        chat_id=deal["chat_id"],
                        message_id=deal["message_id"],
                        parse_mode=ParseMode.MARKDOWN_V2,
                        reply_markup=None,
                    )
            except Exception as e:
                log.warning(f"expire edit: {e}")

            await send_dm(deal["buyer_id"],
                          f"⏰ *Deal \\#{esc(deal_id)} expired* \\(2h timeout\\)\\. "
                          f"Any locked VC has been refunded\\.")
            await send_dm(deal["seller_id"],
                          f"⏰ *Deal \\#{esc(deal_id)} expired* \\(2h timeout\\)\\.")
            log.info(f"Deal {deal_id} expired")
    except Exception as e:
        log.error(f"expire_deals: {e}", exc_info=True)


# ─── Broadcast (called from admin API) ───────────────────────────────────────

async def broadcast_message(text: str) -> int:
    """Send a message to all users. Returns count of successful sends."""
    if not _bot_app:
        return 0
    users = await db.get_all_users(limit=10000)
    count = 0
    for u in users:
        if u.get("notify_enabled", True):
            ok = await send_dm(u["tg_id"], esc(text), parse_mode=None)
            if ok:
                count += 1
            await asyncio.sleep(0.05)  # Telegram rate limit
    return count


# ─── Bot setup & lifecycle ────────────────────────────────────────────────────

async def start_bot():
    global _bot_app
    from apscheduler.schedulers.asyncio import AsyncIOScheduler

    _bot_app = (
        ApplicationBuilder()
        .token(TELEGRAM_BOT_TOKEN)
        .build()
    )
    app = _bot_app

    # Commands
    app.add_handler(CommandHandler("start", cmd_start))
    app.add_handler(CommandHandler("escrow", cmd_escrow))
    app.add_handler(CommandHandler("wallet", cmd_wallet))
    app.add_handler(CommandHandler("rep", cmd_rep))
    app.add_handler(CommandHandler("profile", cmd_rep))
    app.add_handler(CommandHandler("mydeals", cmd_mydeals))
    app.add_handler(CommandHandler("referral", cmd_referral))
    app.add_handler(CommandHandler("appeal", cmd_appeal))

    # +vouch (text message starting with +vouch)
    app.add_handler(MessageHandler(
        filters.TEXT & filters.Regex(r"^\+vouch"), handle_vouch
    ))

    # Group: new member
    app.add_handler(MessageHandler(filters.StatusUpdate.NEW_CHAT_MEMBERS, on_new_member))

    # Photos in DM — relay / vouch proof / dispute evidence / wallet deposit.
    # Also catch screenshots sent as an uncompressed image "file"/document — common on desktop —
    # which previously arrived as a `document` update and were silently dropped entirely.
    app.add_handler(MessageHandler(
        (filters.PHOTO | filters.Document.IMAGE) & filters.ChatType.PRIVATE, handle_dm_photo
    ))

    # All text (non-command)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))

    # Callbacks
    app.add_handler(CallbackQueryHandler(on_callback))

    # Set bot commands
    try:
        await app.bot.set_my_commands([
            BotCommand("start", "Start the bot"),
            BotCommand("wallet", "Your VC wallet (DM only)"),
            BotCommand("mydeals", "View your active deals"),
            BotCommand("referral", "Your referral link & rewards"),
        ], scope=BotCommandScopeAllPrivateChats())
        await app.bot.set_my_commands([
            BotCommand("escrow", "Start a new escrow deal"),
            BotCommand("rep", "View user trust profile"),
        ], scope=BotCommandScopeAllGroupChats())
    except Exception as e:
        log.warning(f"set_my_commands: {e}")

    # Scheduler
    # NOTE: pass the async functions directly (not `lambda: asyncio.create_task(...)`) —
    # APScheduler's AsyncIOExecutor schedules coroutine-function jobs on the loop it captured
    # at construction time. Wrapping in asyncio.create_task() instead made every single one of
    # these jobs fail every run with "no running event loop" (visible in logs), which meant deals
    # never auto-expired, nudges never sent, and the AI evidence-deadline chase never fired.
    scheduler = AsyncIOScheduler()
    scheduler.add_job(
        expire_deals,
        "interval", minutes=1, id="expire_deals",
    )
    scheduler.add_job(
        nudge_stale_deals,
        "interval", minutes=30, id="nudge_deals", replace_existing=True,
    )
    scheduler.add_job(
        chase_evidence_deadlines,
        "interval", minutes=30, id="chase_evidence_deadlines", replace_existing=True,
    )
    scheduler.start()

    # Start polling
    await app.initialize()
    await app.start()

    # Save bot username for deep links (after initialize)
    global _bot_username
    try:
        me = await app.bot.get_me()
        _bot_username = me.username or ""
        log.info(f"Bot username: @{_bot_username}")
    except Exception as e:
        log.warning(f"get_me: {e}")

    await app.updater.start_polling(drop_pending_updates=True)
    log.info("Telegram bot polling started")


async def stop_bot():
    global _bot_app
    if _bot_app:
        try:
            await _bot_app.updater.stop()
            await _bot_app.stop()
            await _bot_app.shutdown()
        except Exception as e:
            log.warning(f"stop_bot: {e}")
        _bot_app = None
    log.info("Telegram bot stopped")
