# Vault-Pay Mega Upgrade

## Objective
Fix bugs + add premium features across bot.py, db.py, admin_api.py, and frontend

## Tasks

### T001: Bug Fixes (bot.py)
- [ ] Validation errors with 5s auto-delete (amount<100, self-mention)
- [ ] Custom ToS step - "Write Custom ToS" button + text handler
- [ ] Counterparty mention separate bot message (auto-delete on accept)
- [ ] Escrow button session lock (only initiator can click, except accept/reject)
- [ ] Fee display fix: show buyer_debit (amount + fee) in pay confirmation

### T002: Wallet Pay Flow Overhaul
- [ ] Buyer clicks Pay → DM confirmation with balance (are you sure?)
- [ ] Confirm → deduct from wallet, mark deal as locked/in_progress
- [ ] Group card: "Funds held by bot" status
- [ ] Relay chat: secure bot-mediated link, both parties chat via bot DMs
- [ ] Buyer releases → confirmation DM → seller credited, deal completes

### T003: Auto-Nudge System
- [ ] Scheduler job: every 30min check stale deals
- [ ] Nudge both parties if deal sits >4h without action
- [ ] One nudge per deal (track NUDGED set)

### T004: Dispute Evidence System
- [ ] On dispute: tell both parties they can DM evidence
- [ ] DISPUTE_EVIDENCE state: collect text + photos for 24h
- [ ] /evidence command or "📸 Add Evidence" button in DM
- [ ] Admin gets full evidence package (formatted)
- [ ] Admin can DM parties through bot

### T005: Vouch System Upgrade
- [ ] +vouch sends notification to vouched user with "✅ Submit Proof" button  
- [ ] Proof submission: user can send up to 3 screenshots via bot
- [ ] Vouch stored as pending until admin approves in admin panel
- [ ] Admin panel: pending vouches with proof screenshots, approve/reject
- [ ] db.py: add vouch_status, proof_file_ids columns to vouches table

### T006: VC → INR Withdrawal (already works, verify)
- [ ] Confirm approve sends user notification with amount
- [ ] Reject sends user notification with reason
- [ ] Deposit approve: credit user wallet

### T007: DB & Admin API
- [ ] db.py: vouches table upgrade (status, proof_json cols)
- [ ] db.py: auto-nudge tracking (add nudged_at to deals)
- [ ] admin_api.py: approve/reject deposit with notification
- [ ] admin_api.py: approve/reject withdrawal with notification
- [ ] admin_api.py: pending vouches endpoints
- [ ] admin_api.py: dispute evidence endpoints

### T008: Frontend
- [ ] Financial.jsx: approve deposit → credit VC, send notification  
- [ ] Financial.jsx: reject deposit → reason input, notification
- [ ] Financial.jsx: reject withdrawal → refund VC, reason, notification
- [ ] Vouches pending section in admin panel
