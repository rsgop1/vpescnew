import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { api } from '../../lib/api'

export default function Users() {
  const [search, setSearch] = useState('')
  const [selected, setSelected] = useState(null)
  const [adjustAmt, setAdjustAmt] = useState('')
  const [adjustReason, setAdjustReason] = useState('')
  const qc = useQueryClient()

  const { data: users = [], isLoading } = useQuery({
    queryKey: ['users'],
    queryFn: () => api.get('/users').then(r => r.data),
    refetchInterval: 30000,
  })

  const adjustMut = useMutation({
    mutationFn: ({ id, amount, reason }) => api.post(`/users/${id}/adjust-balance`, { amount, reason }),
    onSuccess: () => { toast.success('Balance adjusted!'); qc.invalidateQueries({ queryKey: ['users'] }); setAdjustAmt(''); setAdjustReason('') },
    onError: (e) => toast.error(e.response?.data?.detail || 'Error'),
  })

  const filtered = users.filter(u =>
    !search ||
    u.username?.toLowerCase().includes(search.toLowerCase()) ||
    String(u.tg_id).includes(search)
  )

  const tierBadge = { new: 'badge-gray', regular: 'badge-blue', trusted: 'badge-purple', elite: 'badge-yellow' }
  const tierIcon = { new: '🌱', regular: '⭐', trusted: '💫', elite: '👑' }

  if (isLoading) return <div className="loading"><div className="spinner" /></div>

  return (
    <div>
      <div className="section-header">
        <div>
          <div className="section-title">👥 All Users</div>
          <div className="section-sub">{users.length} registered users</div>
        </div>
        <input style={{ width: 240 }} placeholder="Search username or Telegram ID..." value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      <div className="table-wrap">
        <table>
          <thead>
            <tr>
              <th>User</th><th>Balance</th><th>Locked</th><th>Deals</th><th>Volume</th><th>Rating</th><th>Tier</th><th>Status</th><th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={9}><div className="empty"><div className="empty-icon">👥</div><div className="empty-text">No users found</div></div></td></tr>
            )}
            {filtered.map(u => {
              const rating = u.rating_count > 0 ? (u.rating_sum / u.rating_count).toFixed(1) : '—'
              let badges = []
              try { badges = JSON.parse(u.badges || '[]') } catch {}
              return (
                <tr key={u.tg_id}>
                  <td>
                    <div style={{ fontWeight: 500 }}>@{u.username || '—'}</div>
                    <div className="font-mono text-muted">{u.tg_id}</div>
                  </td>
                  <td style={{ color: 'var(--accent)' }}>{(u.balance_vc || 0).toLocaleString()} VC</td>
                  <td className="text-muted">{(u.locked_vc || 0).toLocaleString()}</td>
                  <td>{u.total_deals || 0}</td>
                  <td>₹{(u.total_volume || 0).toLocaleString()}</td>
                  <td>{rating === '—' ? '—' : `${rating}⭐`}</td>
                  <td>
                    <span className={`badge ${tierBadge[u.tier] || 'badge-gray'}`}>
                      {tierIcon[u.tier] || '🌱'} {u.tier || 'new'}
                    </span>
                  </td>
                  <td>
                    {u.frozen && <span className="badge badge-blue">🧊 Frozen</span>}
                    {u.scam_flag && <span className="badge badge-red">🚨 Scam</span>}
                    {!u.frozen && !u.scam_flag && <span className="badge badge-green">✅ Active</span>}
                  </td>
                  <td>
                    <button className="btn btn-secondary btn-sm" onClick={() => setSelected(u)}>⚙️</button>
                  </td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" style={{ maxWidth: 520 }} onClick={e => e.stopPropagation()}>
            <div className="modal-title">
              <span>⚙️ @{selected.username}</span>
              <button className="btn btn-secondary btn-sm" onClick={() => setSelected(null)}>✕</button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13, marginBottom: 16 }}>
              {[
                ['Telegram ID', selected.tg_id],
                ['Balance', `${(selected.balance_vc || 0).toLocaleString()} VC`],
                ['Locked', `${(selected.locked_vc || 0).toLocaleString()} VC`],
                ['Total Deals', selected.total_deals || 0],
                ['Total Volume', `₹${(selected.total_volume || 0).toLocaleString()}`],
                ['Vouches', selected.vouches || 0],
                ['Tier', `${selected.tier || 'new'}`],
                ['Member since', selected.created_at?.slice(0, 10)],
              ].map(([k, v]) => (
                <div key={k}><div className="text-muted">{k}</div><div>{v}</div></div>
              ))}
            </div>
            <div style={{ padding: 14, background: 'var(--surface)', borderRadius: 8, marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>💰 Balance Adjustment</div>
              <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
                <input type="number" placeholder="Amount (use negative to deduct)" value={adjustAmt} onChange={e => setAdjustAmt(e.target.value)} style={{ flex: 1 }} />
              </div>
              <input placeholder="Reason for adjustment" value={adjustReason} onChange={e => setAdjustReason(e.target.value)} style={{ marginBottom: 8 }} />
              <button
                className="btn btn-primary btn-sm"
                onClick={() => adjustMut.mutate({ id: selected.tg_id, amount: parseInt(adjustAmt), reason: adjustReason })}
                disabled={!adjustAmt || adjustMut.isPending}
              >
                Apply Adjustment
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
