import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { toast } from 'sonner'
import { api } from '../../lib/api'

export default function Disputes() {
  const [selected, setSelected] = useState(null)
  const qc = useQueryClient()

  const { data: disputes = [], isLoading } = useQuery({
    queryKey: ['disputes'],
    queryFn: () => api.get('/disputes').then(r => r.data),
    refetchInterval: 15000,
  })

  const resolveMut = useMutation({
    mutationFn: ({ id, action }) => api.post(`/disputes/${id}/resolve`, { action }),
    onSuccess: () => { toast.success('Dispute resolved!'); qc.invalidateQueries({ queryKey: ['disputes'] }); setSelected(null) },
    onError: (e) => toast.error(e.response?.data?.detail || 'Error'),
  })

  const pingMut = useMutation({
    mutationFn: (id) => api.post(`/disputes/${id}/ping-seller`),
    onSuccess: () => toast.success('Seller pinged via bot!'),
    onError: (e) => toast.error(e.response?.data?.detail || 'Error'),
  })

  const aiJudgeMut = useMutation({
    mutationFn: (id) => api.post(`/disputes/${id}/ai-judge`),
    onSuccess: (r) => {
      const outcome = r.data?.outcome
      if (outcome === 'auto_resolved') toast.success(`AI auto-resolved: ${r.data.action?.replace(/_/g, ' ')}`)
      else if (outcome === 'needs_admin') toast.success('AI verdict ready — review below and confirm')
      else if (outcome === 'more_evidence') toast.success('AI asked both parties for more evidence')
      else toast.error(r.data?.detail || 'AI judge could not decide')
      qc.invalidateQueries({ queryKey: ['disputes'] })
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'AI judge failed'),
  })

  const appealMut = useMutation({
    mutationFn: ({ id, action }) => api.post(`/disputes/${id}/appeal-resolve`, { action }),
    onSuccess: (r) => {
      if (r.data?.outcome === 'dismissed') toast.success('Appeal dismissed — original verdict stands')
      else toast.success(`Appeal resolved: ${r.data?.action?.replace(/_/g, ' ')}`)
      qc.invalidateQueries({ queryKey: ['disputes'] })
      setSelected(null)
    },
    onError: (e) => toast.error(e.response?.data?.detail || 'Error'),
  })

  const parseAiVerdict = (d) => {
    if (!d?.ai_verdict_json) return null
    try { return JSON.parse(d.ai_verdict_json) } catch { return null }
  }

  const parseJury = (d) => {
    if (!d?.jury_json) return null
    try { return JSON.parse(d.jury_json) } catch { return null }
  }

  const isWalletDeal = (d) => (d.deal?.payment_method || 'wallet') === 'wallet'

  const openDisputes = disputes.filter(d => d.status === 'open')
  const resolvedDisputes = disputes.filter(d => d.status === 'resolved')

  if (isLoading) return <div className="loading"><div className="spinner" /></div>

  return (
    <div>
      <div className="section-header">
        <div>
          <div className="section-title">⚖️ Dispute Tribunal</div>
          <div className="section-sub">{openDisputes.length} open · {resolvedDisputes.length} resolved</div>
        </div>
      </div>

      {openDisputes.length === 0 && resolvedDisputes.length === 0 ? (
        <div className="card"><div className="empty"><div className="empty-icon">⚖️</div><div className="empty-text">No disputes. All clean! ✅</div></div></div>
      ) : (
        <>
          {openDisputes.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--danger)', marginBottom: 12 }}>🚨 Open Disputes ({openDisputes.length})</div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr><th>Deal ID</th><th>Buyer</th><th>Seller</th><th>Amount</th><th>Opened</th><th>Evidence</th><th>Actions</th></tr>
                  </thead>
                  <tbody>
                    {openDisputes.map(d => (
                      <tr key={d.id}>
                        <td className="font-mono">#{d.deal_id}</td>
                        <td>@{d.deal?.buyer_un || '—'}</td>
                        <td>@{d.deal?.seller_un || '—'}</td>
                        <td style={{ color: 'var(--accent)' }}>₹{(d.deal?.amount || 0).toLocaleString()}</td>
                        <td className="text-muted">{d.opened_at?.slice(0, 10)}</td>
                        <td>
                          <span className="badge badge-blue">{(d.messages || []).length} msgs</span>
                          {d.escalated && <span className="badge badge-red" style={{ marginLeft: 4 }}>🚨 escalated</span>}
                          {parseAiVerdict(d) && (
                            <div style={{ marginTop: 4, fontSize: 11 }}>
                              🤖 <span style={{ color: 'var(--accent)' }}>{parseAiVerdict(d).verdict?.replace(/_/g, ' ')}</span>
                              {' '}({parseAiVerdict(d).confidence}%)
                            </div>
                          )}
                        </td>
                        <td style={{ display: 'flex', gap: 6 }}>
                          <button className="btn btn-secondary btn-sm" onClick={() => setSelected(d)}>📋 View Case</button>
                          <button className="btn btn-warning btn-sm" onClick={() => pingMut.mutate(d.deal_id)}>📣 Ping Seller</button>
                          {isWalletDeal(d) ? (
                            <button
                              className="btn btn-sm"
                              style={{ background: 'var(--accent)', color: '#fff' }}
                              onClick={() => aiJudgeMut.mutate(d.deal_id)}
                              disabled={aiJudgeMut.isPending}
                            >
                              🤖 {parseAiVerdict(d) ? 'Re-run AI' : 'Run AI Judge'}
                            </button>
                          ) : (
                            <span className="text-muted" style={{ fontSize: 11, alignSelf: 'center' }}>🛡️ middleman — manual only</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {resolvedDisputes.length > 0 && (
            <div>
              <div style={{ fontSize: 14, fontWeight: 600, color: 'var(--muted)', marginBottom: 12 }}>✅ Resolved ({resolvedDisputes.length})</div>
              <div className="table-wrap">
                <table>
                  <thead>
                    <tr><th>Deal ID</th><th>Resolution</th><th>Resolved By</th><th>Date</th><th>Appeal</th></tr>
                  </thead>
                  <tbody>
                    {resolvedDisputes.slice(0, 20).map(d => (
                      <tr key={d.id} style={{ cursor: 'pointer' }} onClick={() => setSelected(d)}>
                        <td className="font-mono">#{d.deal_id}</td>
                        <td><span className="badge badge-green">{d.resolution?.replace(/_/g, ' ')}</span></td>
                        <td className="text-muted">{d.resolved_by === 'ai_judge' ? '🤖 AI Judge' : (d.resolved_by || 'Admin')}</td>
                        <td className="text-muted">{d.resolved_at?.slice(0, 10)}</td>
                        <td>{d.appeal_used ? <span className="badge badge-red">🚨 appealed</span> : <span className="text-muted">—</span>}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}

      {selected && (
        <div className="modal-overlay" onClick={() => setSelected(null)}>
          <div className="modal" style={{ maxWidth: 600 }} onClick={e => e.stopPropagation()}>
            <div className="modal-title">
              <span>⚖️ Case File — Deal #{selected.deal_id}</span>
              <button className="btn btn-secondary btn-sm" onClick={() => setSelected(null)}>✕</button>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13, marginBottom: 16 }}>
              <div><div className="text-muted">Buyer</div><div>@{selected.deal?.buyer_un}</div></div>
              <div><div className="text-muted">Seller</div><div>@{selected.deal?.seller_un}</div></div>
              <div><div className="text-muted">Amount</div><div style={{ color: 'var(--accent)' }}>₹{(selected.deal?.amount || 0).toLocaleString()}</div></div>
              <div><div className="text-muted">Locked</div><div>{selected.deal?.locked_amount || 0} VC</div></div>
            </div>

            {selected.deal?.toc && (
              <div style={{ marginBottom: 16, padding: 10, background: 'var(--surface)', borderRadius: 6, fontSize: 12 }}>
                <div className="text-muted" style={{ marginBottom: 4 }}>Terms</div>
                <div>{selected.deal.toc}</div>
              </div>
            )}

            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 8 }}>📨 Evidence ({(selected.messages || []).length})</div>
              {(selected.messages || []).length === 0 ? (
                <div style={{ fontSize: 13, color: 'var(--muted)', fontStyle: 'italic' }}>No evidence submitted yet.</div>
              ) : (
                <div style={{ maxHeight: 200, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 8 }}>
                  {(selected.messages || []).map((m, i) => (
                    <div key={i} style={{ padding: '8px 12px', background: 'var(--surface)', borderRadius: 6, fontSize: 12 }}>
                      <div className="text-muted" style={{ marginBottom: 2 }}>User {m.from} · {m.at?.slice(0, 16)}</div>
                      <div>{m.text || (m.photo ? '📸 Photo uploaded' : '—')}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {parseAiVerdict(selected) && (
              <div style={{ marginBottom: 16, padding: 12, background: 'rgba(59,130,246,0.08)', border: '1px solid var(--accent)', borderRadius: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6, color: 'var(--accent)' }}>
                  🤖 AI Judge Verdict — {parseAiVerdict(selected).verdict?.replace(/_/g, ' ')} ({parseAiVerdict(selected).confidence}% confidence)
                  {selected.escalated && <span className="badge badge-red" style={{ marginLeft: 8 }}>🚨 escalated</span>}
                </div>
                <div style={{ fontSize: 12, color: 'var(--muted)', marginBottom: 10 }}>
                  {parseAiVerdict(selected).reasoning}
                </div>

                {parseJury(selected) && (
                  <div style={{ marginBottom: 10, display: 'flex', flexDirection: 'column', gap: 4 }}>
                    <div className="text-muted" style={{ fontSize: 11, fontWeight: 600 }}>Jury breakdown:</div>
                    {Object.entries(parseJury(selected)).map(([name, v]) => (
                      <div key={name} style={{ fontSize: 11, color: 'var(--muted)' }}>
                        <b>{name.replace(/_/g, ' ')}:</b> {v.verdict?.replace(/_/g, ' ')} ({v.confidence}%)
                      </div>
                    ))}
                  </div>
                )}

                {selected.ai_resolved_auto ? (
                  <div style={{ fontSize: 12, marginTop: 8, color: 'var(--success)' }}>✅ Auto-resolved by AI — no action needed.</div>
                ) : selected.status !== 'resolved' && parseAiVerdict(selected).verdict !== 'need_more_evidence' ? (
                  <button
                    className="btn btn-sm"
                    style={{ background: 'var(--accent)', color: '#fff' }}
                    onClick={() => resolveMut.mutate({ id: selected.deal_id, action: parseAiVerdict(selected).verdict })}
                    disabled={resolveMut.isPending}
                  >
                    ✅ Confirm & Execute AI Verdict
                  </button>
                ) : null}
              </div>
            )}

            {selected.appeal_used && selected.appeal_verdict_json && (
              <div style={{ marginBottom: 16, padding: 12, background: 'rgba(239,68,68,0.08)', border: '1px solid var(--danger)', borderRadius: 8 }}>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 6, color: 'var(--danger)' }}>🚨 Appeal Re-Review</div>
                {(() => {
                  try {
                    const av = JSON.parse(selected.appeal_verdict_json)
                    return <div style={{ fontSize: 12, color: 'var(--muted)' }}>
                      Re-reviewed verdict: <b>{av.verdict?.replace(/_/g, ' ')}</b> ({av.confidence}% confidence)<br />
                      {av.reasoning}
                    </div>
                  } catch { return null }
                })()}
                <div className="text-muted" style={{ fontSize: 11, marginTop: 6, marginBottom: 10 }}>
                  Funds were NOT auto-changed by the appeal — use the buttons below to act on it directly.
                </div>
                {selected.escalated && (
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr 1fr', gap: 8 }}>
                    <button
                      className="btn btn-sm"
                      style={{ justifyContent: 'center', flexDirection: 'column', padding: 10, gap: 4 }}
                      onClick={() => appealMut.mutate({ id: selected.deal_id, action: 'dismiss' })}
                      disabled={appealMut.isPending}
                    >
                      <span>🛡️</span><span style={{ fontSize: 11 }}>Dismiss Appeal</span>
                    </button>
                    <button
                      className="btn btn-primary"
                      style={{ justifyContent: 'center', flexDirection: 'column', padding: 10, gap: 4 }}
                      onClick={() => appealMut.mutate({ id: selected.deal_id, action: 'release_seller' })}
                      disabled={appealMut.isPending}
                    >
                      <span>✅</span><span style={{ fontSize: 11 }}>Release to Seller</span>
                    </button>
                    <button
                      className="btn btn-danger"
                      style={{ justifyContent: 'center', flexDirection: 'column', padding: 10, gap: 4 }}
                      onClick={() => appealMut.mutate({ id: selected.deal_id, action: 'refund_buyer' })}
                      disabled={appealMut.isPending}
                    >
                      <span>🔄</span><span style={{ fontSize: 11 }}>Refund to Buyer</span>
                    </button>
                    <button
                      className="btn btn-warning"
                      style={{ justifyContent: 'center', flexDirection: 'column', padding: 10, gap: 4 }}
                      onClick={() => appealMut.mutate({ id: selected.deal_id, action: 'split' })}
                      disabled={appealMut.isPending}
                    >
                      <span>⚖️</span><span style={{ fontSize: 11 }}>Split 50/50</span>
                    </button>
                  </div>
                )}
              </div>
            )}

            {selected.status === 'resolved' ? (
              <div style={{ fontSize: 12, color: 'var(--muted)', fontStyle: 'italic' }}>
                This dispute is already resolved — the God Judgement buttons only apply to open disputes.
              </div>
            ) : (
              <>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 10 }}>⚡ God Judgement (manual override)</div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 10 }}>
              <button
                className="btn btn-primary"
                style={{ justifyContent: 'center', flexDirection: 'column', padding: 12, gap: 4 }}
                onClick={() => resolveMut.mutate({ id: selected.deal_id, action: 'release_seller' })}
                disabled={resolveMut.isPending}
              >
                <span>✅</span><span style={{ fontSize: 11 }}>Release to Seller</span>
              </button>
              <button
                className="btn btn-danger"
                style={{ justifyContent: 'center', flexDirection: 'column', padding: 12, gap: 4 }}
                onClick={() => resolveMut.mutate({ id: selected.deal_id, action: 'refund_buyer' })}
                disabled={resolveMut.isPending}
              >
                <span>🔄</span><span style={{ fontSize: 11 }}>Refund to Buyer</span>
              </button>
              <button
                className="btn btn-warning"
                style={{ justifyContent: 'center', flexDirection: 'column', padding: 12, gap: 4 }}
                onClick={() => resolveMut.mutate({ id: selected.deal_id, action: 'split' })}
                disabled={resolveMut.isPending}
              >
                    <span>⚖️</span><span style={{ fontSize: 11 }}>Split 50/50</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
