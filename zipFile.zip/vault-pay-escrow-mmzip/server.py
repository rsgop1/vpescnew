"""FastAPI server — starts both the API and Telegram bot."""
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
import logging
import os

import db as database
import bot as bot_module

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s %(name)s %(levelname)s %(message)s'
)
log = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    await database.init_db()
    log.info("Database initialized")
    try:
        await bot_module.start_bot()
        log.info("Telegram bot started")
    except Exception as e:
        log.error(f"Bot start failed: {e}")
    yield
    try:
        await bot_module.stop_bot()
    except Exception as e:
        log.warning(f"Bot stop error: {e}")


app = FastAPI(lifespan=lifespan, title="Vault-Pay Escrow")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

from admin_api import router as admin_router
app.include_router(admin_router)

# Serve React frontend static files if built
DIST = os.path.join(os.path.dirname(__file__), "dist")
if os.path.isdir(DIST):
    app.mount("/assets", StaticFiles(directory=os.path.join(DIST, "assets")), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str):
        index = os.path.join(DIST, "index.html")
        if os.path.isfile(index):
            return FileResponse(index)
        return {"detail": "Frontend not built yet"}
else:
    @app.get("/")
    async def root():
        return {"status": "ok", "message": "Vault-Pay Escrow API running. Frontend not built."}


@app.get("/api/health")
async def health():
    return {"ok": True}
