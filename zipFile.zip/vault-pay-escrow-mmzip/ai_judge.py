"""Agentic AI dispute judge (+ deposit verifier) for Vault-Pay escrow, powered by OpenRouter.

Scope: the dispute judge only runs on wallet-based deals (payment_method == 'wallet'). Middleman
deals move funds through a third-party human off-platform — there's no ledger the AI can actually
verify, and the middleman could be the one scamming. Those disputes stay human-only.

Dispute pipeline:
1. Both parties submit evidence (text/screenshots) via bot.py's EVIDENCE_AWAIT flow.
2. `review_dispute()` builds a full case dossier (deal + evidence + cross-deal history +
   precedents) and does a cheap single-call TRIAGE pass first — it has the full picture of both
   sides' story before deciding anything. If it's confident more evidence is needed, that's a
   single AI call (cheap, and reduces daily OpenRouter-quota pressure that was causing the old
   "keeps asking / screenshots not analyzed" failures). Only once triage thinks the case is
   decidable does the heavier 3-persona jury + chief-justice pass run for the actual binding
   verdict. Jury disagreement or low confidence always escalates to a human, regardless of amount.
3. `apply_verdict()` acts on it:
   - need_more_evidence: DMs *targeted, case-specific* follow-up questions only to the party
     missing something, remembers what was already asked (so it stops repeating itself), and
     sets a 24h evidence deadline for the autonomous evidence-chase job in bot.py.
   - escalated: both parties get a short heads-up DM, admin gets the full reasoning.
   - a resolution verdict, small + confident + not escalated: auto-executes via
     admin_api.execute_dispute_resolution (which itself DMs both parties + admin the full report
     and updates the group card — single source of truth for every resolution path).
4. `file_appeal()` lets either party ask for one re-review within 24h of resolution — it never
   auto-reverses funds, only flags the case for urgent human re-check with a fresh AI opinion.

Deposit verification: `verify_deposit()` looks at a deposit screenshot with vision + the claimed
amount and either auto-credits the wallet, auto-rejects on clear mismatch/fraud signs, or leaves
it pending for manual admin review when the model isn't confident either way.
"""
import base64
import json
import logging
from datetime import datetime, timedelta

import httpx

import db
from config import (
    OPENROUTER_API_KEY, AI_JUDGE_MODEL, AI_AUTO_THRESHOLD, AI_AUTO_CONFIDENCE_MIN,
    TELEGRAM_ADMIN_ID, ADMIN_UPI_ID,
)

log = logging.getLogger(__name__)

OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
VALID_VERDICTS = ("release_seller", "refund_buyer", "split", "need_more_evidence")
EVIDENCE_DEADLINE_HOURS = 24
APPEAL_WINDOW_HOURS = 24
DEPOSIT_AUTO_APPROVE_CONFIDENCE = 70
DEPOSIT_AUTO_REJECT_CONFIDENCE = 75

VERDICT_SCHEMA_INSTRUCTIONS = """Respond with STRICT JSON ONLY (no markdown fences, no prose outside the JSON object), exactly this shape:
{
  "verdict": "release_seller" | "refund_buyer" | "split" | "need_more_evidence",
  "confidence": <integer 0-100>,
  "reasoning": "<2-4 sentences citing specific evidence you saw>",
  "split_ratio": {"seller": <0-100>, "buyer": <0-100>},
  "follow_up_questions": {"buyer": "<question or empty string>", "seller": "<question or empty string>"}
}
Only fill "split_ratio" when verdict is "split". Only fill "follow_up_questions" when verdict is \
"need_more_evidence" — ask exactly what's missing for THIS specific case (reference the actual claims made), \
never a generic template question. If a "Questions already asked" list is given below, do not repeat them — \
either ask something new and more specific, or if nothing new can reasonably be asked, stop asking and decide \
based on the evidence available (treat continued silence on a repeated ask as evidence against that party)."""

TRIAGE_PROMPT = """You are Vault-Pay's triage reviewer. Read the FULL deal details and both parties' \
sides of the story below before deciding anything. Your only job right now is: is there enough here to \
reach a fair verdict, or is something specific and important still missing? Be economical — most cases \
that already have both parties' explanations plus at least one piece of concrete evidence (screenshot, \
transaction reference, timestamp) are decidable; don't ask just to be thorough. Only pick \
"need_more_evidence" if a claim central to the outcome is genuinely unverifiable as-is, and your question \
must reference the specific claim, not a generic template. If you believe the case IS decidable, give your \
own verdict/confidence/reasoning anyway (it may be used directly or double-checked by a second pass)."""

JURY_PERSONAS = {
    "strict_evidentiary": (
        "You are a strict evidentiary judge. You only trust verifiable proof (transaction IDs, "
        "timestamped screenshots, matching amounts). Unverifiable claims count for nothing. "
        "When both sides lack proof, you lean toward the safer outcome (refund/split) rather than "
        "rewarding an unproven claim."
    ),
    "contextual": (
        "You are a contextual, common-sense judge. You weigh plausibility, tone, response speed, "
        "and consistency of each party's story, not just hard proof — real disputes rarely come with "
        "perfect evidence. You still won't rule for a story that doesn't add up."
    ),
    "fraud_skeptic": (
        "You are a fraud-skeptic judge. You actively look for scam patterns: doctored screenshots, "
        "mismatched amounts/names, stalling tactics, a party going silent right after being asked a "
        "pointed question, or an evidence story that changes between messages. You are the most "
        "suspicious of the three judges."
    ),
}

CHIEF_JUSTICE_PROMPT = """You are the Chief Justice of Vault-Pay's AI dispute panel. Three associate \
judges each independently reviewed the same case and gave a verdict. Your job is to weigh their \
opinions, resolve disagreement, and issue ONE final verdict. If the judges strongly disagree or all \
have low confidence, reflect that with a lower final confidence rather than forcing false certainty — \
downstream logic will escalate low-confidence/disagreeing cases to a human anyway, so be honest."""


def esc_md(text) -> str:
    if text is None:
        return ""
    chars = r"\_*[]()~`>#+-=|{}.!"
    return "".join(f"\\{c}" if c in chars else c for c in str(text))


def _iso_plus_hours(hours: int) -> str:
    return (datetime.utcnow() + timedelta(hours=hours)).isoformat()


async def _fetch_photo_data_url(file_id: str) -> str | None:
    """Download a Telegram photo by file_id and return a base64 data: URL for vision input."""
    try:
        import bot as bot_module
        if not bot_module._bot_app:
            log.warning("ai_judge: _bot_app not ready, cannot fetch photo for AI analysis")
            return None
        tg_file = await bot_module._bot_app.bot.get_file(file_id)
        raw = await tg_file.download_as_bytearray()
        if not raw:
            log.warning(f"ai_judge: downloaded 0 bytes for file_id {file_id}")
            return None
        b64 = base64.b64encode(bytes(raw)).decode()
        return f"data:image/jpeg;base64,{b64}"
    except Exception as e:
        log.error(f"ai_judge: photo fetch failed for {file_id}: {e}", exc_info=True)
        return None


async def _build_case_content(deal: dict, dispute: dict, note: str = "") -> list:
    """Builds the multimodal `content` list (text + any evidence images) shared by every judge call."""
    evidence = dispute.get("messages", [])
    buyer_hist = await db.get_user_dispute_history(deal.get("buyer_id"), exclude_deal_id=deal.get("deal_id"))
    seller_hist = await db.get_user_dispute_history(deal.get("seller_id"), exclude_deal_id=deal.get("deal_id"))
    precedents = await db.get_resolved_precedents(limit=5)
    asked = json.loads(dispute.get("ai_asked_questions") or "[]")

    lines = [
        f"Deal ID: {deal.get('deal_id')}",
        f"Amount: {deal.get('amount')} VC | Fee payer: {deal.get('fee_payer')}",
        f"Buyer: @{deal.get('buyer_un') or deal.get('buyer_id')} — prior disputes: {buyer_hist['total']} "
        f"(resolved against them: {buyer_hist['resolved_against']}, in their favor: {buyer_hist['resolved_favor']})",
        f"Seller: @{deal.get('seller_un') or deal.get('seller_id')} — prior disputes: {seller_hist['total']} "
        f"(resolved against them: {seller_hist['resolved_against']}, in their favor: {seller_hist['resolved_favor']})",
        f"Deal terms/ToC: {(deal.get('toc') or 'none specified')[:800]}",
        f"Deal created: {deal.get('created_at', 'unknown')} | Paid at: {deal.get('paid_at') or 'not marked paid'}",
        "",
        "── Evidence submitted, i.e. both parties' full side of the story (chronological) ──",
    ]
    if not evidence:
        lines.append("(No evidence was submitted by either party yet.)")
    for m in evidence:
        who = m.get("from", "unknown")
        if m.get("type") == "photo":
            lines.append(f"[{m.get('at', '')}] @{who} submitted a SCREENSHOT (attached as an image below — look at it).")
        else:
            lines.append(f"[{m.get('at', '')}] @{who}: {m.get('text', '')}")

    if asked:
        lines.append("")
        lines.append("── Questions already asked in previous rounds (do NOT repeat these) ──")
        for q in asked[-6:]:
            lines.append(f"- {q}")

    if precedents:
        lines.append("")
        lines.append("── Recent precedent verdicts on other deals (for consistency, not binding) ──")
        for p in precedents:
            lines.append(f"- {p['resolution']}: {p['reasoning']}")

    if note:
        lines.append("")
        lines.append(f"── Automated note ──\n{note}")

    content = [{"type": "text", "text": "\n".join(lines)}]
    photo_count = 0
    for m in evidence:
        if m.get("type") == "photo" and photo_count < 6:
            data_url = await _fetch_photo_data_url(m["file_id"])
            if data_url:
                content.append({"type": "image_url", "image_url": {"url": data_url}})
                photo_count += 1
            else:
                lines_note = f"[NOTE: the screenshot from @{m.get('from')} at {m.get('at','')} could not be downloaded for AI analysis — do not assume it supports either side.]"
                content[0]["text"] += "\n" + lines_note
    return content


def _parse_verdict_json(raw: str) -> dict | None:
    raw = (raw or "").strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:]
    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        parsed = json.loads(raw[start:end + 1])
    except Exception:
        return None
    if parsed.get("verdict") not in VALID_VERDICTS:
        return None
    return parsed


async def _call_openrouter_raw(system_prompt: str, content, model: str = None) -> dict | None:
    if not OPENROUTER_API_KEY:
        return None
    payload = {
        "model": model or AI_JUDGE_MODEL,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": content},
        ],
        "temperature": 0.2,
    }
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            resp = await client.post(
                OPENROUTER_URL,
                headers={"Authorization": f"Bearer {OPENROUTER_API_KEY}", "Content-Type": "application/json"},
                json=payload,
            )
        if resp.status_code == 429:
            log.error(f"ai_judge: OpenRouter rate-limited (429): {resp.text[:300]}")
            return None
        resp.raise_for_status()
        return resp.json()["choices"][0]["message"]["content"]
    except Exception as e:
        log.error(f"ai_judge: OpenRouter call failed: {e}")
        return None


async def _call_openrouter(system_prompt: str, content) -> dict | None:
    raw = await _call_openrouter_raw(system_prompt, content)
    if raw is None:
        return None
    return _parse_verdict_json(raw)


async def _run_full_jury(deal_id: str, content: list) -> dict:
    """The expensive, high-stakes pass: 3 personas in parallel + a chief-justice consolidation."""
    import asyncio

    base_schema = "\n\n" + VERDICT_SCHEMA_INSTRUCTIONS
    jury_calls = {
        name: _call_openrouter(persona + base_schema, content)
        for name, persona in JURY_PERSONAS.items()
    }
    results = await asyncio.gather(*jury_calls.values())
    jury = {name: v for name, v in zip(jury_calls.keys(), results) if v}

    if not jury:
        return {"error": "AI jury calls all failed"}

    jury_summary_lines = [
        f"- {name}: verdict={v.get('verdict')} confidence={v.get('confidence')} reasoning={v.get('reasoning', '')[:200]}"
        for name, v in jury.items()
    ]
    chief_content = [
        {"type": "text", "text": (
            content[0]["text"] + "\n\n── Associate judge opinions ──\n" + "\n".join(jury_summary_lines)
        )}
    ] + content[1:]

    final = await _call_openrouter(CHIEF_JUSTICE_PROMPT + "\n\n" + VERDICT_SCHEMA_INSTRUCTIONS, chief_content)
    if not final:
        final = next(iter(jury.values()))
        final["reasoning"] = "(Chief justice pass unavailable; using associate judge verdict.) " + final.get("reasoning", "")

    verdicts_seen = {v.get("verdict") for v in jury.values()}
    unanimous = len(verdicts_seen) <= 1
    low_confidence = int(final.get("confidence", 0) or 0) < 50
    final["jury_unanimous"] = unanimous
    final["escalate"] = (not unanimous) or low_confidence
    final["model"] = AI_JUDGE_MODEL

    await db.update_dispute(
        deal_id,
        ai_verdict_json=json.dumps(final),
        ai_checked_at=db.now_iso(),
        jury_json=json.dumps(jury),
        escalated=final["escalate"],
    )
    return final


async def review_dispute(deal_id: str, deadline_note: str = "", force_final: bool = False) -> dict:
    """Full review pipeline: cheap triage first, full jury only once the case looks decidable
    (or force_final=True, used by the evidence-deadline chase and appeals)."""
    if not OPENROUTER_API_KEY:
        return {"error": "OPENROUTER_API_KEY not configured"}

    deal = await db.get_deal(deal_id)
    dispute = await db.get_dispute(deal_id)
    if not deal or not dispute:
        return {"error": "deal or dispute not found"}

    if (deal.get("payment_method") or "wallet") != "wallet":
        return {"error": "not_wallet_deal"}

    content = await _build_case_content(deal, dispute, note=deadline_note)

    if not force_final:
        triage = await _call_openrouter(TRIAGE_PROMPT + "\n\n" + VERDICT_SCHEMA_INSTRUCTIONS, content)
        if triage and triage.get("verdict") == "need_more_evidence":
            triage["jury_unanimous"] = True
            triage["escalate"] = False
            triage["model"] = AI_JUDGE_MODEL
            await db.update_dispute(
                deal_id,
                ai_verdict_json=json.dumps(triage),
                ai_checked_at=db.now_iso(),
            )
            return triage
        # Triage thinks it's decidable (or triage itself failed) — fall through to the full jury
        # for a properly considered, harder-to-fool final verdict.

    return await _run_full_jury(deal_id, content)


# Kept as an alias: earlier code / callers refer to this name.
judge_dispute = review_dispute


async def _send_analysing_notices(deal: dict) -> list:
    """Tell both parties the AI is working, so the wait doesn't feel broken. Cleared once done."""
    from bot import _bot_app
    sent = []
    if not _bot_app:
        return sent
    for uid in [deal.get("buyer_id"), deal.get("seller_id")]:
        if not uid:
            continue
        try:
            m = await _bot_app.bot.send_message(uid, "🤖 Analysing your query...")
            sent.append((uid, m.message_id))
        except Exception:
            pass
    return sent


async def _clear_analysing_notices(sent: list):
    from bot import _bot_app
    if not _bot_app:
        return
    for uid, mid in sent:
        try:
            await _bot_app.bot.delete_message(uid, mid)
        except Exception:
            pass


async def apply_verdict(deal_id: str, verdict: dict) -> dict:
    """Act on a verdict: auto-resolve, ask for more evidence, or flag for admin confirmation."""
    import admin_api  # local import to avoid circular import at module load time
    from bot import send_dm, EVIDENCE_AWAIT

    deal = await db.get_deal(deal_id)
    if not deal:
        return {"outcome": "error", "detail": "deal not found"}

    action = verdict.get("verdict")
    confidence = int(verdict.get("confidence", 0) or 0)
    reasoning = verdict.get("reasoning", "")
    escalate = bool(verdict.get("escalate"))

    if action == "need_more_evidence":
        qs = verdict.get("follow_up_questions", {}) or {}
        dispute = await db.get_dispute(deal_id)
        asked = json.loads(dispute.get("ai_asked_questions") or "[]") if dispute else []
        pending = []

        if deal.get("buyer_id") and qs.get("buyer"):
            EVIDENCE_AWAIT[deal["buyer_id"]] = {"deal_id": deal_id, "count": 0}
            pending.append(deal["buyer_id"])
            asked.append(f"[buyer] {qs['buyer']}")
            await send_dm(
                deal["buyer_id"],
                f"🤖 *AI Judge needs more evidence \\(Deal \\#{esc_md(deal_id)}\\):*\n"
                f"{esc_md(qs['buyer'])}\n\nReply here with details/screenshots, then type *done*\\. "
                f"You have {EVIDENCE_DEADLINE_HOURS}h — after that we'll decide with what we have\\.",
            )
        if deal.get("seller_id") and qs.get("seller"):
            EVIDENCE_AWAIT[deal["seller_id"]] = {"deal_id": deal_id, "count": 0}
            pending.append(deal["seller_id"])
            asked.append(f"[seller] {qs['seller']}")
            await send_dm(
                deal["seller_id"],
                f"🤖 *AI Judge needs more evidence \\(Deal \\#{esc_md(deal_id)}\\):*\n"
                f"{esc_md(qs['seller'])}\n\nReply here with details/screenshots, then type *done*\\. "
                f"You have {EVIDENCE_DEADLINE_HOURS}h — after that we'll decide with what we have\\.",
            )

        await db.update_dispute(
            deal_id,
            ai_pending_from=json.dumps(pending),
            ai_asked_questions=json.dumps(asked[-12:]),
            evidence_deadline=_iso_plus_hours(EVIDENCE_DEADLINE_HOURS) if pending else "",
        )
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"🤖 *AI Judge* asked Deal \\#{esc_md(deal_id)} parties for more evidence \\(deadline {EVIDENCE_DEADLINE_HOURS}h\\)\\.",
        )
        return {"outcome": "more_evidence"}

    if action not in ("release_seller", "refund_buyer", "split"):
        return {"outcome": "error", "detail": f"unexpected verdict '{action}'"}

    amount = deal.get("amount", 0) or 0
    auto_ok = (not escalate) and amount <= AI_AUTO_THRESHOLD and confidence >= AI_AUTO_CONFIDENCE_MIN

    if auto_ok:
        await admin_api.execute_dispute_resolution(deal_id, action, resolved_by="ai_judge")
        await db.update_dispute(deal_id, ai_resolved_auto=True)
        return {"outcome": "auto_resolved", "action": action}
    else:
        if escalate:
            for uid in [deal.get("buyer_id"), deal.get("seller_id")]:
                if uid:
                    await send_dm(
                        uid,
                        f"⚠️ *Deal \\#{esc_md(deal_id)}:* your dispute needs a closer human look "
                        f"before a decision is made\\. Admin has been notified — hang tight\\.",
                    )
            prefix = "🚨 *ESCALATED* \\— jury disagreed or low confidence\\. "
        else:
            prefix = ""
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"{prefix}🤖 *AI Judge recommendation for Deal \\#{esc_md(deal_id)}*\n"
            f"Suggested: *{esc_md(action)}* \\(confidence {confidence}%\\)\n"
            f"Reason: {esc_md(reasoning[:400])}\n\nOpen the admin panel to confirm or override\\.",
        )
        return {"outcome": "needs_admin", "action": action, "escalated": escalate}


async def judge_and_apply(deal_id: str, deadline_note: str = "", force_final: bool = False) -> dict:
    """Convenience wrapper: shows an 'Analysing...' notice, runs review_dispute, applies the verdict."""
    from bot import send_dm

    deal = await db.get_deal(deal_id)
    if deal and (deal.get("payment_method") or "wallet") != "wallet":
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"⚠️ Deal \\#{esc_md(deal_id)} is a *middleman* deal \\— AI Judge only reviews wallet "
            f"deals \\(no verifiable ledger for middleman fund movement\\)\\. Please resolve manually\\.",
        )
        return {"outcome": "manual_only", "detail": "middleman deal — AI judge does not apply"}

    notices = await _send_analysing_notices(deal) if deal else []
    try:
        verdict = await review_dispute(deal_id, deadline_note=deadline_note, force_final=force_final)
    finally:
        await _clear_analysing_notices(notices)

    if verdict.get("error"):
        return {"outcome": "error", "detail": verdict["error"]}
    result = await apply_verdict(deal_id, verdict)
    result["verdict"] = verdict
    return result


async def file_appeal(deal_id: str, requester_id: int) -> dict:
    """One re-review per dispute. Never auto-reverses funds — flags for urgent human check."""
    from bot import send_dm

    deal = await db.get_deal(deal_id)
    dispute = await db.get_dispute(deal_id)
    if not deal or not dispute:
        return {"ok": False, "detail": "Deal or dispute not found."}
    if dispute.get("status") != "resolved":
        return {"ok": False, "detail": "This dispute isn't resolved yet."}
    if requester_id not in (deal.get("buyer_id"), deal.get("seller_id")):
        return {"ok": False, "detail": "Only the buyer or seller on this deal can appeal it."}
    if dispute.get("appeal_used"):
        return {"ok": False, "detail": "This dispute has already used its one appeal."}

    resolved_at = dispute.get("resolved_at") or ""
    try:
        resolved_dt = datetime.fromisoformat(resolved_at)
        if datetime.utcnow() - resolved_dt > timedelta(hours=APPEAL_WINDOW_HOURS):
            return {"ok": False, "detail": f"Appeal window ({APPEAL_WINDOW_HOURS}h after resolution) has passed."}
    except Exception:
        pass

    await db.update_dispute(deal_id, appeal_used=True, escalated=True)

    appeal_verdict = {"verdict": "n/a", "confidence": 0}
    if (deal.get("payment_method") or "wallet") == "wallet":
        note = (
            f"This is an APPEAL of a previously resolved dispute. Original resolution: "
            f"'{dispute.get('resolution')}' by {dispute.get('resolved_by')}. Re-review the full case "
            f"critically — do not simply repeat the prior verdict. This verdict will be shown to a human "
            f"admin only; it will NOT auto-execute any fund movement."
        )
        verdict = await review_dispute(deal_id, deadline_note=note, force_final=True)
        if not verdict.get("error"):
            await db.update_dispute(deal_id, appeal_verdict_json=json.dumps(verdict))
            appeal_verdict = verdict

    await send_dm(
        TELEGRAM_ADMIN_ID,
        f"🚨 *APPEAL FILED* on Deal \\#{esc_md(deal_id)} by {'buyer' if requester_id == deal.get('buyer_id') else 'seller'}\\.\n"
        f"Original: *{esc_md(dispute.get('resolution'))}* by {esc_md(dispute.get('resolved_by'))}\\.\n"
        f"AI re\\-review: *{esc_md(appeal_verdict.get('verdict', 'n/a'))}* "
        f"\\(confidence {appeal_verdict.get('confidence', 0)}%\\)\\.\n"
        f"Please open the admin panel to dismiss the appeal or apply a new verdict \\(funds were NOT auto\\-reversed\\)\\.",
    )
    return {"ok": True, "detail": "Appeal filed. Admin will manually review; you'll be notified of any change."}


# ─── Deposit screenshot verification ───────────────────────────────────────────

DEPOSIT_VERIFY_PROMPT = """You are Vault-Pay's payment verification assistant. You will see a screenshot \
that a user submitted as proof of a UPI payment, plus the amount they claim to have paid. Look carefully at \
the screenshot for: a success/completed status, the amount shown, and the destination UPI ID/name. Respond \
with STRICT JSON ONLY, exactly this shape:
{
  "verdict": "approve" | "reject" | "unclear",
  "confidence": <integer 0-100>,
  "detected_amount": <number or null>,
  "reason": "<one sentence — what you saw and why>"
}
Use "approve" only when the screenshot clearly shows a successful payment for approximately the claimed \
amount to the given UPI ID. Use "reject" only when you're confident something is actually wrong — clearly \
different amount, failed/pending status, wrong recipient, or obvious editing/tampering. If the screenshot is \
blurry, cropped, or you're simply not sure, use "unclear" rather than guessing — a human will review it."""


def _parse_deposit_json(raw: str) -> dict | None:
    raw = (raw or "").strip()
    if raw.startswith("```"):
        raw = raw.strip("`")
        if raw.lower().startswith("json"):
            raw = raw[4:]
    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end == -1:
        return None
    try:
        parsed = json.loads(raw[start:end + 1])
    except Exception:
        return None
    if parsed.get("verdict") not in ("approve", "reject", "unclear"):
        return None
    return parsed


async def verify_deposit(tx_id: str) -> dict:
    """Vision-check a deposit screenshot against the claimed amount; auto-approve/reject/leave pending."""
    from bot import send_dm

    tx = await db.get_transaction(tx_id)
    if not tx or tx.get("status") != "pending":
        return {"outcome": "skipped", "detail": "not pending"}

    try:
        data = json.loads(tx.get("data_json") or "{}")
    except Exception:
        data = {}

    amount = tx.get("amount", 0)
    file_id = data.get("photo_file_id")
    user_id = tx.get("user_id")

    if not OPENROUTER_API_KEY or not file_id:
        return {"outcome": "skipped", "detail": "no API key or no screenshot"}

    data_url = await _fetch_photo_data_url(file_id)
    if not data_url:
        log.error(f"ai_judge: deposit {tx_id} screenshot could not be downloaded — leaving for manual review")
        data["ai_note"] = "AI could not download the screenshot for analysis."
        await db.update_transaction(tx_id, data_json=json.dumps(data))
        return {"outcome": "pending", "detail": "photo fetch failed"}

    content = [
        {"type": "text", "text": (
            f"Claimed deposit amount: ₹{amount} (should be paid in INR to UPI ID {ADMIN_UPI_ID or '(not set)'})."
        )},
        {"type": "image_url", "image_url": {"url": data_url}},
    ]
    raw = await _call_openrouter_raw(DEPOSIT_VERIFY_PROMPT, content)
    result = _parse_deposit_json(raw) if raw else None

    if not result:
        data["ai_note"] = "AI verification failed (model error) — needs manual review."
        await db.update_transaction(tx_id, data_json=json.dumps(data))
        return {"outcome": "pending", "detail": "AI call failed"}

    verdict = result.get("verdict")
    confidence = int(result.get("confidence", 0) or 0)
    detected = result.get("detected_amount")
    reason = result.get("reason", "")

    data["ai_verdict"] = verdict
    data["ai_confidence"] = confidence
    data["ai_detected_amount"] = detected
    data["ai_note"] = reason

    if verdict == "approve" and confidence >= DEPOSIT_AUTO_APPROVE_CONFIDENCE:
        from db import adjust_balance
        await adjust_balance(user_id, delta_balance=amount)
        data["approved_by"] = "ai_judge"
        data["approved_at"] = db.now_iso()
        await db.update_transaction(tx_id, status="approved", data_json=json.dumps(data))
        await send_dm(
            user_id,
            f"✅ *Auto\\-deposited by AI\\!*\n"
            f"*{amount:,} VC* has been credited to your wallet\\. /wallet to check\\.\n"
            f"_{esc_md(reason)}_",
        )
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"🤖 AI auto\\-approved deposit `{esc_md(tx_id[:12])}` for @{esc_md(data.get('username'))} "
            f"\\({amount:,} VC, confidence {confidence}%\\)\\.",
        )
        return {"outcome": "approved", "confidence": confidence}

    if verdict == "reject" and confidence >= DEPOSIT_AUTO_REJECT_CONFIDENCE:
        data["rejected_by"] = "ai_judge"
        data["rejected_at"] = db.now_iso()
        data["reject_reason"] = reason
        await db.update_transaction(tx_id, status="rejected", data_json=json.dumps(data))
        await send_dm(
            user_id,
            f"❌ *Deposit rejected by AI*\n"
            f"Amount: {amount:,} VC\n"
            f"Reason: {esc_md(reason)}\n\n"
            f"If you believe this is a mistake, contact admin \\— they can still manually approve it\\.",
        )
        await send_dm(
            TELEGRAM_ADMIN_ID,
            f"🤖 AI auto\\-rejected deposit `{esc_md(tx_id[:12])}` for @{esc_md(data.get('username'))} "
            f"\\({amount:,} VC, confidence {confidence}%\\)\\. Reason: {esc_md(reason)}\\.\n"
            f"You can still manually approve it from the admin panel if the AI got it wrong\\.",
        )
        return {"outcome": "rejected", "confidence": confidence}

    # Ambiguous / low confidence either way — keep pending, but hand the admin the AI's read.
    await db.update_transaction(tx_id, data_json=json.dumps(data))
    await send_dm(
        TELEGRAM_ADMIN_ID,
        f"🤖 AI reviewed deposit `{esc_md(tx_id[:12])}` for @{esc_md(data.get('username'))} but isn't "
        f"confident enough to decide \\({esc_md(verdict)}, {confidence}%\\)\\. Detected amount: "
        f"{esc_md(detected)}\\. Reason: {esc_md(reason)}\\.\nPlease review manually in the admin panel\\.",
    )
    return {"outcome": "pending", "confidence": confidence}
