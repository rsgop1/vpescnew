"""Entry point — run with: uvicorn main:app --host 0.0.0.0 --port 8000"""
from server import app
