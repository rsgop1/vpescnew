"""Async PostgreSQL database layer using asyncpg."""
import asyncpg
import json
import uuid
from datetime import datetime, timezone
from config import DATABASE_URL

_pool: asyncpg.Pool | None = None


async def get_pool() -> asyncpg.Pool:
    global _pool
    if _pool is None:
        _pool = await asyncpg.create_pool(DATABASE_URL, min_size=2, max_size=10)
    return _pool


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def gen_id() -> str:
    return str(uuid.uuid4())


async def init_db():
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS users (
            tg_id BIGINT PRIMARY KEY,
            username TEXT DEFAULT '',
            balance_vc INTEGER DEFAULT 0,
            locked_vc INTEGER DEFAULT 0,
            total_deals INTEGER DEFAULT 0,
            total_volume INTEGER DEFAULT 0,
            rating_sum REAL DEFAULT 0,
            rating_count INTEGER DEFAULT 0,
            vouches INTEGER DEFAULT 0,
            scam_flag BOOLEAN DEFAULT FALSE,
            frozen BOOLEAN DEFAULT FALSE,
            badges TEXT DEFAULT '[]',
            referral_code TEXT DEFAULT '',
            referred_by BIGINT DEFAULT NULL,
            tier TEXT DEFAULT 'new',
            daily_withdrawn INTEGER DEFAULT 0,
            last_withdrawal_date TEXT DEFAULT '',
            notify_enabled BOOLEAN DEFAULT TRUE,
            created_at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS deals (
            deal_id TEXT PRIMARY KEY,
            chat_id BIGINT,
            buyer_id BIGINT,
            buyer_un TEXT DEFAULT '',
            seller_id BIGINT,
            seller_un TEXT DEFAULT '',
            amount INTEGER DEFAULT 0,
            fee_payer TEXT DEFAULT 'buyer',
            fee_percent REAL DEFAULT 1.0,
            toc TEXT DEFAULT '',
            role TEXT DEFAULT 'buy',
            status TEXT DEFAULT 'awaiting_acceptance',
            seller_pin TEXT DEFAULT '',
            message_id BIGINT,
            created_at TEXT DEFAULT '',
            expires_at TEXT DEFAULT '',
            paid_at TEXT,
            released_at TEXT,
            cancelled BOOLEAN DEFAULT FALSE,
            locked_amount INTEGER DEFAULT 0,
            seller_credit INTEGER DEFAULT 0,
            fee_collected INTEGER DEFAULT 0,
            buyer_accepted BOOLEAN DEFAULT FALSE,
            seller_accepted BOOLEAN DEFAULT FALSE
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            id TEXT PRIMARY KEY,
            type TEXT,
            user_id BIGINT,
            deal_id TEXT DEFAULT '',
            amount INTEGER DEFAULT 0,
            status TEXT DEFAULT 'pending',
            data_json TEXT DEFAULT '{}',
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS disputes (
            id TEXT PRIMARY KEY,
            deal_id TEXT,
            opened_by BIGINT,
            status TEXT DEFAULT 'open',
            messages_json TEXT DEFAULT '[]',
            opened_at TEXT DEFAULT '',
            resolved_at TEXT DEFAULT '',
            resolution TEXT DEFAULT '',
            resolved_by TEXT DEFAULT '',
            ai_verdict_json TEXT DEFAULT '',
            ai_resolved_auto BOOLEAN DEFAULT FALSE,
            ai_checked_at TEXT DEFAULT '',
            ai_pending_from TEXT DEFAULT '[]',
            ai_asked_questions TEXT DEFAULT '[]',
            escalated BOOLEAN DEFAULT FALSE,
            evidence_deadline TEXT DEFAULT '',
            appeal_used BOOLEAN DEFAULT FALSE,
            jury_json TEXT DEFAULT '',
            appeal_verdict_json TEXT DEFAULT ''
        )""")
        # Backfill columns for disputes tables created before the AI judge feature existed.
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS ai_verdict_json TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS ai_resolved_auto BOOLEAN DEFAULT FALSE")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS ai_checked_at TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS ai_pending_from TEXT DEFAULT '[]'")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS ai_asked_questions TEXT DEFAULT '[]'")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS escalated BOOLEAN DEFAULT FALSE")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS evidence_deadline TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS appeal_used BOOLEAN DEFAULT FALSE")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS jury_json TEXT DEFAULT ''")
        await conn.execute("ALTER TABLE disputes ADD COLUMN IF NOT EXISTS appeal_verdict_json TEXT DEFAULT ''")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS blacklist (
            id TEXT PRIMARY KEY,
            value TEXT,
            type TEXT DEFAULT 'other',
            reason TEXT DEFAULT '',
            at TEXT DEFAULT '',
            by TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS groups_tbl (
            chat_id BIGINT PRIMARY KEY,
            title TEXT DEFAULT '',
            active BOOLEAN DEFAULT TRUE,
            added_by TEXT DEFAULT '',
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id TEXT PRIMARY KEY,
            actor TEXT DEFAULT '',
            action TEXT DEFAULT '',
            details_json TEXT DEFAULT '{}',
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT DEFAULT '',
            updated_at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS vouches (
            id TEXT PRIMARY KEY,
            from_id BIGINT,
            to_id BIGINT,
            text TEXT DEFAULT '',
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS referrals (
            id TEXT PRIMARY KEY,
            referrer BIGINT,
            referred BIGINT,
            bonus_paid BOOLEAN DEFAULT FALSE,
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS broadcasts (
            id TEXT PRIMARY KEY,
            text TEXT DEFAULT '',
            by TEXT DEFAULT '',
            count INTEGER DEFAULT 0,
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS deal_templates (
            id TEXT PRIMARY KEY,
            name TEXT DEFAULT '',
            toc TEXT DEFAULT '',
            amount INTEGER DEFAULT 0,
            by TEXT DEFAULT '',
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS treasury (
            id TEXT PRIMARY KEY DEFAULT 'main',
            balance INTEGER DEFAULT 0
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS deal_counter (
            id TEXT PRIMARY KEY DEFAULT 'deal',
            seq INTEGER DEFAULT 4091
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS scam_reports (
            id TEXT PRIMARY KEY,
            reporter_id BIGINT,
            target_id BIGINT,
            target_un TEXT DEFAULT '',
            reason TEXT DEFAULT '',
            deal_id TEXT DEFAULT '',
            at TEXT DEFAULT '',
            status TEXT DEFAULT 'pending'
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS broadcast_templates (
            id TEXT PRIMARY KEY,
            name TEXT DEFAULT '',
            text TEXT DEFAULT '',
            by TEXT DEFAULT '',
            at TEXT DEFAULT ''
        )""")
        await conn.execute("""
        CREATE TABLE IF NOT EXISTS middlemen (
            tg_id BIGINT PRIMARY KEY,
            username TEXT DEFAULT '',
            active BOOLEAN DEFAULT TRUE,
            added_at TEXT DEFAULT '',
            added_by TEXT DEFAULT ''
        )""")
        # Add new columns to deals/vouches if not present
        for col_sql in [
            "ALTER TABLE deals ADD COLUMN IF NOT EXISTS payment_method TEXT DEFAULT 'wallet'",
            "ALTER TABLE deals ADD COLUMN IF NOT EXISTS middleman_id BIGINT DEFAULT NULL",
            "ALTER TABLE deals ADD COLUMN IF NOT EXISTS middleman_un TEXT DEFAULT ''",
            "ALTER TABLE deals ADD COLUMN IF NOT EXISTS product_name TEXT DEFAULT ''",
            "ALTER TABLE deals ADD COLUMN IF NOT EXISTS nudged_at TEXT DEFAULT NULL",
            "ALTER TABLE vouches ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'approved'",
            "ALTER TABLE vouches ADD COLUMN IF NOT EXISTS proof_json TEXT DEFAULT '[]'",
        ]:
            try:
                await conn.execute(col_sql)
            except Exception:
                pass
        # Unique index on disputes.deal_id so ON CONFLICT works
        try:
            await conn.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS disputes_deal_id_uidx ON disputes(deal_id)"
            )
        except Exception:
            pass
        # Insert defaults
        await conn.execute(
            "INSERT INTO treasury (id, balance) VALUES ('main', 0) ON CONFLICT (id) DO NOTHING"
        )
        await conn.execute(
            "INSERT INTO deal_counter (id, seq) VALUES ('deal', 4091) ON CONFLICT (id) DO NOTHING"
        )


def row_to_dict(row) -> dict:
    if row is None:
        return None
    return dict(row)


def rows_to_list(rows) -> list:
    return [dict(r) for r in rows]


# ─── User operations ───────────────────────────────────────────────────────────

async def get_or_create_user(tg_id: int, username: str = None) -> dict:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM users WHERE tg_id = $1", tg_id)
        if row:
            u = row_to_dict(row)
            if username and u.get('username') != username:
                await conn.execute("UPDATE users SET username = $1 WHERE tg_id = $2", username, tg_id)
                u['username'] = username
            return u
        u = {
            'tg_id': tg_id,
            'username': username or '',
            'balance_vc': 0, 'locked_vc': 0,
            'total_deals': 0, 'total_volume': 0,
            'rating_sum': 0.0, 'rating_count': 0,
            'vouches': 0, 'scam_flag': False, 'frozen': False,
            'badges': '[]',
            'referral_code': f'REF{tg_id}',
            'referred_by': None,
            'tier': 'new',
            'daily_withdrawn': 0,
            'last_withdrawal_date': '',
            'notify_enabled': True,
            'created_at': now_iso(),
        }
        await conn.execute("""
            INSERT INTO users (tg_id, username, balance_vc, locked_vc, total_deals, total_volume,
                rating_sum, rating_count, vouches, scam_flag, frozen, badges, referral_code,
                referred_by, tier, daily_withdrawn, last_withdrawal_date, notify_enabled, created_at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
        """, tg_id, u['username'], 0, 0, 0, 0, 0.0, 0, 0, False, False,
             '[]', f'REF{tg_id}', None, 'new', 0, '', True, now_iso())
        return u


async def get_user(tg_id: int) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM users WHERE tg_id = $1", tg_id)
        return row_to_dict(row)


async def get_user_by_username(username: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT * FROM users WHERE LOWER(username) = LOWER($1)", username.lstrip("@")
        )
        return row_to_dict(row)


async def update_user(tg_id: int, **kwargs):
    if not kwargs:
        return
    pool = await get_pool()
    sets = ', '.join(f"{k} = ${i+2}" for i, k in enumerate(kwargs.keys()))
    vals = list(kwargs.values())
    async with pool.acquire() as conn:
        await conn.execute(f"UPDATE users SET {sets} WHERE tg_id = $1", tg_id, *vals)


async def adjust_balance(tg_id: int, delta_balance: int = 0, delta_locked: int = 0):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE users SET balance_vc = balance_vc + $1, locked_vc = locked_vc + $2 WHERE tg_id = $3",
            delta_balance, delta_locked, tg_id
        )


async def get_all_users(limit: int = 500) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM users ORDER BY total_volume DESC LIMIT $1", limit)
        return rows_to_list(rows)


# ─── Deal operations ───────────────────────────────────────────────────────────

async def next_deal_id() -> int:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "UPDATE deal_counter SET seq = seq + 1 WHERE id = 'deal' RETURNING seq"
        )
        return row['seq']


async def create_deal(deal: dict):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO deals (deal_id, chat_id, buyer_id, buyer_un, seller_id, seller_un,
                amount, fee_payer, fee_percent, toc, role, status, seller_pin, message_id,
                created_at, expires_at, paid_at, released_at, cancelled, locked_amount,
                seller_credit, fee_collected, buyer_accepted, seller_accepted)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24)
        """, deal['deal_id'], deal['chat_id'], deal.get('buyer_id'), deal['buyer_un'],
             deal.get('seller_id'), deal['seller_un'], deal['amount'], deal['fee_payer'],
             deal['fee_percent'], deal.get('toc', ''), deal['role'], deal['status'],
             deal['seller_pin'], deal.get('message_id'), deal['created_at'], deal['expires_at'],
             deal.get('paid_at'), deal.get('released_at'), False, 0, 0, 0,
             deal.get('buyer_accepted', False), deal.get('seller_accepted', False))


async def get_deal(deal_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM deals WHERE deal_id = $1", deal_id)
        return row_to_dict(row)


async def update_deal(deal_id: str, **kwargs):
    if not kwargs:
        return
    pool = await get_pool()
    sets = ', '.join(f"{k} = ${i+2}" for i, k in enumerate(kwargs.keys()))
    vals = list(kwargs.values())
    async with pool.acquire() as conn:
        await conn.execute(f"UPDATE deals SET {sets} WHERE deal_id = $1", deal_id, *vals)


async def get_deals(status: str = None, limit: int = 200) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        if status:
            rows = await conn.fetch(
                "SELECT * FROM deals WHERE status = $1 ORDER BY created_at DESC LIMIT $2", status, limit
            )
        else:
            rows = await conn.fetch("SELECT * FROM deals ORDER BY created_at DESC LIMIT $1", limit)
        return rows_to_list(rows)


async def get_user_deals(tg_id: int) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT * FROM deals WHERE (buyer_id = $1 OR seller_id = $1) AND status NOT IN ('completed','cancelled') ORDER BY created_at DESC",
            tg_id
        )
        return rows_to_list(rows)


# ─── Transaction operations ────────────────────────────────────────────────────

async def create_transaction(tx: dict):
    pool = await get_pool()
    async with pool.acquire() as conn:
        tx_id = tx.get('id', gen_id())
        await conn.execute("""
            INSERT INTO transactions (id, type, user_id, deal_id, amount, status, data_json, at)
            VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        """, tx_id, tx['type'], tx.get('user_id'), tx.get('deal_id', ''),
             tx.get('amount', 0), tx.get('status', 'pending'),
             json.dumps(tx.get('data', {})), tx.get('at', now_iso()))
        return tx_id


async def get_transactions(tx_type: str = None, status: str = None, limit: int = 200) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        conds, vals = [], []
        if tx_type:
            conds.append(f"type = ${len(vals)+1}")
            vals.append(tx_type)
        if status:
            conds.append(f"status = ${len(vals)+1}")
            vals.append(status)
        where = f"WHERE {' AND '.join(conds)}" if conds else ""
        rows = await conn.fetch(
            f"SELECT * FROM transactions {where} ORDER BY at DESC LIMIT {limit}", *vals
        )
        return rows_to_list(rows)


async def get_transaction(tx_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM transactions WHERE id = $1", tx_id)
        return row_to_dict(row)


async def update_transaction(tx_id: str, **kwargs):
    if not kwargs:
        return
    pool = await get_pool()
    sets = ', '.join(f"{k} = ${i+2}" for i, k in enumerate(kwargs.keys()))
    vals = list(kwargs.values())
    async with pool.acquire() as conn:
        await conn.execute(f"UPDATE transactions SET {sets} WHERE id = $1", tx_id, *vals)


# ─── Dispute operations ────────────────────────────────────────────────────────

async def create_dispute(dispute: dict):
    pool = await get_pool()
    async with pool.acquire() as conn:
        d_id = gen_id()
        await conn.execute("""
            INSERT INTO disputes (id, deal_id, opened_by, status, messages_json, opened_at)
            VALUES ($1,$2,$3,$4,$5,$6)
            ON CONFLICT (deal_id) DO UPDATE SET status = 'open', opened_by = $3, opened_at = $6
        """, d_id, dispute['deal_id'], dispute['opened_by'], 'open', '[]', now_iso())


async def get_dispute(deal_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM disputes WHERE deal_id = $1", deal_id)
        if row:
            d = row_to_dict(row)
            try:
                d['messages'] = json.loads(d.get('messages_json', '[]'))
            except Exception:
                d['messages'] = []
            return d
        return None


async def add_dispute_message(deal_id: str, msg: dict):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT messages_json FROM disputes WHERE deal_id = $1", deal_id)
        if row:
            msgs = json.loads(row['messages_json'] or '[]')
            msgs.append(msg)
            await conn.execute("UPDATE disputes SET messages_json = $1 WHERE deal_id = $2", json.dumps(msgs), deal_id)


async def get_disputes(status: str = None) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        if status:
            rows = await conn.fetch("SELECT * FROM disputes WHERE status = $1 ORDER BY opened_at DESC", status)
        else:
            rows = await conn.fetch("SELECT * FROM disputes ORDER BY opened_at DESC")
        result = []
        for r in rows:
            d = dict(r)
            try:
                d['messages'] = json.loads(d.get('messages_json', '[]'))
            except Exception:
                d['messages'] = []
            result.append(d)
        return result


async def update_dispute(deal_id: str, **kwargs):
    if not kwargs:
        return
    pool = await get_pool()
    sets = ', '.join(f"{k} = ${i+2}" for i, k in enumerate(kwargs.keys()))
    vals = list(kwargs.values())
    async with pool.acquire() as conn:
        await conn.execute(f"UPDATE disputes SET {sets} WHERE deal_id = $1", deal_id, *vals)


async def get_user_dispute_history(tg_id: int, exclude_deal_id: str = None) -> dict:
    """Cross-deal pattern signal: how often this user has been in a dispute and how it went."""
    if not tg_id:
        return {"total": 0, "resolved_against": 0, "resolved_favor": 0}
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT d.resolution, deals.buyer_id, deals.seller_id
            FROM disputes d JOIN deals ON deals.deal_id = d.deal_id
            WHERE d.status = 'resolved' AND (deals.buyer_id = $1 OR deals.seller_id = $1)
              AND ($2::text IS NULL OR d.deal_id != $2)
        """, tg_id, exclude_deal_id)
    total = len(rows)
    against = 0
    favor = 0
    for r in rows:
        was_seller = r['seller_id'] == tg_id
        if r['resolution'] == 'release_seller':
            if was_seller:
                favor += 1
            else:
                against += 1
        elif r['resolution'] == 'refund_buyer':
            if was_seller:
                against += 1
            else:
                favor += 1
    return {"total": total, "resolved_against": against, "resolved_favor": favor}


async def get_resolved_precedents(limit: int = 5) -> list:
    """Recent resolved disputes (with AI reasoning) to use as precedent examples for consistency."""
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT deal_id, resolution, resolved_by, ai_verdict_json
            FROM disputes WHERE status = 'resolved' AND ai_verdict_json != ''
            ORDER BY resolved_at DESC LIMIT $1
        """, limit)
    out = []
    for r in rows:
        try:
            v = json.loads(r['ai_verdict_json'])
        except Exception:
            continue
        out.append({
            "resolution": r['resolution'],
            "reasoning": v.get("reasoning", "")[:220],
        })
    return out


async def get_open_disputes_with_expired_deadline() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT deal_id FROM disputes
            WHERE status = 'open' AND evidence_deadline != ''
              AND evidence_deadline < $1
        """, now_iso())
    return [r['deal_id'] for r in rows]


# ─── Settings ─────────────────────────────────────────────────────────────────

async def get_setting(key: str, default=None):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT value FROM settings WHERE key = $1", key)
        if not row:
            return default
        v = row['value']
        try:
            return json.loads(v)
        except Exception:
            return v


async def set_setting(key: str, value):
    pool = await get_pool()
    async with pool.acquire() as conn:
        v = json.dumps(value) if not isinstance(value, str) else value
        await conn.execute(
            "INSERT INTO settings (key, value, updated_at) VALUES ($1,$2,$3) ON CONFLICT (key) DO UPDATE SET value=$2, updated_at=$3",
            key, v, now_iso()
        )


# ─── Treasury ─────────────────────────────────────────────────────────────────

async def get_treasury() -> int:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT balance FROM treasury WHERE id = 'main'")
        return int(row['balance']) if row else 0


async def add_to_treasury(amount: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE treasury SET balance = balance + $1 WHERE id = 'main'", amount
        )


async def subtract_from_treasury(amount: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE treasury SET balance = balance - $1 WHERE id = 'main'", amount
        )


# ─── Groups ───────────────────────────────────────────────────────────────────

async def is_group_whitelisted(chat_id: int, primary_group_id: int) -> bool:
    if chat_id == primary_group_id:
        return True
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT active FROM groups_tbl WHERE chat_id = $1", chat_id)
        return bool(row and row['active'])


async def get_all_groups() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM groups_tbl ORDER BY at DESC")
        return rows_to_list(rows)


async def add_group(chat_id: int, title: str, added_by: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO groups_tbl (chat_id, title, active, added_by, at) VALUES ($1,$2,TRUE,$3,$4) ON CONFLICT (chat_id) DO UPDATE SET active=TRUE, title=$2",
            chat_id, title, added_by, now_iso()
        )


async def remove_group(chat_id: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("UPDATE groups_tbl SET active = FALSE WHERE chat_id = $1", chat_id)


# ─── Blacklist ────────────────────────────────────────────────────────────────

async def get_blacklist() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM blacklist ORDER BY at DESC")
        return rows_to_list(rows)


async def add_blacklist(value: str, bl_type: str, reason: str, by: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO blacklist (id, value, type, reason, at, by) VALUES ($1,$2,$3,$4,$5,$6)",
            gen_id(), value, bl_type, reason, now_iso(), by
        )


async def del_blacklist(value: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM blacklist WHERE value = $1", value)


async def is_blacklisted(value: str) -> bool:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT id FROM blacklist WHERE value = $1", value)
        return bool(row)


# ─── Audit log ────────────────────────────────────────────────────────────────

async def log_action(actor: str, action: str, details: dict = None):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO audit_log (id, actor, action, details_json, at) VALUES ($1,$2,$3,$4,$5)",
            gen_id(), actor, action, json.dumps(details or {}), now_iso()
        )


async def get_audit_log(limit: int = 200) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM audit_log ORDER BY at DESC LIMIT $1", limit)
        result = []
        for r in rows:
            d = dict(r)
            try:
                d['details'] = json.loads(d.get('details_json', '{}'))
            except Exception:
                d['details'] = {}
            result.append(d)
        return result


# ─── Vouches ──────────────────────────────────────────────────────────────────

async def add_vouch(from_id: int, to_id: int, text: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO vouches (id, from_id, to_id, text, at) VALUES ($1,$2,$3,$4,$5)",
            gen_id(), from_id, to_id, text, now_iso()
        )
        await conn.execute("UPDATE users SET vouches = vouches + 1 WHERE tg_id = $1", to_id)


async def get_vouches(to_id: int, limit: int = 20) -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT * FROM vouches WHERE to_id = $1 ORDER BY at DESC LIMIT $2", to_id, limit
        )
        return rows_to_list(rows)


async def get_pending_vouches() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("""
            SELECT v.*, u1.username as from_un, u2.username as to_un
            FROM vouches v
            LEFT JOIN users u1 ON u1.tg_id = v.from_id
            LEFT JOIN users u2 ON u2.tg_id = v.to_id
            WHERE v.status = 'pending'
            ORDER BY v.at DESC
        """)
        result = []
        for r in rows:
            d = dict(r)
            try:
                d['proofs'] = json.loads(d.get('proof_json', '[]'))
            except Exception:
                d['proofs'] = []
            result.append(d)
        return result


async def get_vouch_by_id(vouch_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM vouches WHERE id = $1", vouch_id)
        if row:
            d = dict(row)
            try:
                d['proofs'] = json.loads(d.get('proof_json', '[]'))
            except Exception:
                d['proofs'] = []
            return d
        return None


async def approve_vouch(vouch_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM vouches WHERE id = $1", vouch_id)
        if row:
            v = dict(row)
            if v.get('status') == 'pending':
                await conn.execute("UPDATE vouches SET status = 'approved' WHERE id = $1", vouch_id)
                await conn.execute(
                    "UPDATE users SET vouches = vouches + 1 WHERE tg_id = $1", v['to_id']
                )
            return v
        return None


async def reject_vouch(vouch_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM vouches WHERE id = $1", vouch_id)
        if row:
            await conn.execute("UPDATE vouches SET status = 'rejected' WHERE id = $1", vouch_id)
        return row_to_dict(row)


async def update_vouch_proof(vouch_id: str, proof_json: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "UPDATE vouches SET proof_json = $1 WHERE id = $2", proof_json, vouch_id
        )


# ─── Referrals ────────────────────────────────────────────────────────────────

async def add_referral(referrer: int, referred: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT id FROM referrals WHERE referred = $1", referred)
        if not row:
            await conn.execute(
                "INSERT INTO referrals (id, referrer, referred, bonus_paid, at) VALUES ($1,$2,$3,FALSE,$4)",
                gen_id(), referrer, referred, now_iso()
            )
            await conn.execute("UPDATE users SET referred_by = $1 WHERE tg_id = $2", referrer, referred)


async def get_referral_count(referrer: int) -> int:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT COUNT(*) as c FROM referrals WHERE referrer = $1", referrer)
        return int(row['c']) if row else 0


async def get_unpaid_referral(referred: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow(
            "SELECT * FROM referrals WHERE referred = $1 AND bonus_paid = FALSE", referred
        )
        return row_to_dict(row)


async def mark_referral_paid(referred: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("UPDATE referrals SET bonus_paid = TRUE WHERE referred = $1", referred)


# ─── Templates ────────────────────────────────────────────────────────────────

async def get_templates() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM deal_templates ORDER BY at DESC")
        return rows_to_list(rows)


async def get_template(tmpl_id: str) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM deal_templates WHERE id = $1", tmpl_id)
        return row_to_dict(row)


async def add_template(name: str, toc: str, amount: int, by: str) -> str:
    pool = await get_pool()
    tmpl_id = gen_id()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO deal_templates (id, name, toc, amount, by, at) VALUES ($1,$2,$3,$4,$5,$6)",
            tmpl_id, name, toc, amount, by, now_iso()
        )
    return tmpl_id


async def del_template(tmpl_id: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM deal_templates WHERE id = $1", tmpl_id)


# ─── Scam reports ─────────────────────────────────────────────────────────────

async def add_scam_report(reporter_id: int, target_id: int, target_un: str, reason: str, deal_id: str = ''):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO scam_reports (id, reporter_id, target_id, target_un, reason, deal_id, at, status)
            VALUES ($1,$2,$3,$4,$5,$6,$7,'pending')
        """, gen_id(), reporter_id, target_id, target_un, reason, deal_id, now_iso())


async def get_scam_reports() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM scam_reports ORDER BY at DESC")
        return rows_to_list(rows)


# ─── Broadcast templates ──────────────────────────────────────────────────────

async def get_broadcast_templates() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM broadcast_templates ORDER BY at DESC")
        return rows_to_list(rows)


async def add_broadcast_template(name: str, text: str, by: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute(
            "INSERT INTO broadcast_templates (id, name, text, by, at) VALUES ($1,$2,$3,$4,$5)",
            gen_id(), name, text, by, now_iso()
        )


async def del_broadcast_template(tmpl_id: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM broadcast_templates WHERE id = $1", tmpl_id)


# ─── Middlemen ────────────────────────────────────────────────────────────────

async def get_active_middlemen() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM middlemen WHERE active = TRUE ORDER BY added_at DESC")
        return rows_to_list(rows)


async def get_all_middlemen() -> list:
    pool = await get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch("SELECT * FROM middlemen ORDER BY added_at DESC")
        return rows_to_list(rows)


async def get_middleman(tg_id: int) -> dict | None:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT * FROM middlemen WHERE tg_id = $1", tg_id)
        return row_to_dict(row)


async def is_middleman(tg_id: int) -> bool:
    pool = await get_pool()
    async with pool.acquire() as conn:
        row = await conn.fetchrow("SELECT tg_id FROM middlemen WHERE tg_id = $1 AND active = TRUE", tg_id)
        return bool(row)


async def add_middleman(tg_id: int, username: str, added_by: str):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("""
            INSERT INTO middlemen (tg_id, username, active, added_at, added_by)
            VALUES ($1, $2, TRUE, $3, $4)
            ON CONFLICT (tg_id) DO UPDATE SET username=$2, active=TRUE, added_by=$4
        """, tg_id, username, now_iso(), added_by)


async def toggle_middleman(tg_id: int, active: bool):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("UPDATE middlemen SET active=$1 WHERE tg_id=$2", active, tg_id)


async def delete_middleman(tg_id: int):
    pool = await get_pool()
    async with pool.acquire() as conn:
        await conn.execute("DELETE FROM middlemen WHERE tg_id = $1", tg_id)


# ─── Stats ────────────────────────────────────────────────────────────────────

async def get_stats() -> dict:
    pool = await get_pool()
    async with pool.acquire() as conn:
        total_vc_row = await conn.fetchrow("SELECT COALESCE(SUM(balance_vc + locked_vc), 0) AS total FROM users")
        total_users = await conn.fetchval("SELECT COUNT(*) FROM users")
        active_deals = await conn.fetchval(
            "SELECT COUNT(*) FROM deals WHERE status NOT IN ('completed','cancelled')"
        )
        total_deals = await conn.fetchval("SELECT COUNT(*) FROM deals")
        pending_dep = await conn.fetchval(
            "SELECT COUNT(*) FROM transactions WHERE type='deposit_request' AND status='pending'"
        )
        pending_wd = await conn.fetchval(
            "SELECT COUNT(*) FROM transactions WHERE type='withdraw_request' AND status='pending'"
        )
        open_disputes = await conn.fetchval("SELECT COUNT(*) FROM disputes WHERE status='open'")
        treasury_bal = await conn.fetchval("SELECT balance FROM treasury WHERE id='main'")
        
        # Revenue by day (last 7 days)
        revenue_rows = await conn.fetch("""
            SELECT LEFT(at, 10) as day, SUM(amount) as total 
            FROM transactions WHERE type='deal_release'
            GROUP BY LEFT(at, 10) ORDER BY day DESC LIMIT 7
        """)
        
        recent_deals = await conn.fetch(
            "SELECT * FROM deals ORDER BY created_at DESC LIMIT 10"
        )
        
        return {
            'total_vc_circulation': int(total_vc_row['total'] or 0),
            'treasury_balance': int(treasury_bal or 0),
            'active_deals': int(active_deals or 0),
            'total_deals': int(total_deals or 0),
            'total_users': int(total_users or 0),
            'pending_deposits': int(pending_dep or 0),
            'pending_withdrawals': int(pending_wd or 0),
            'open_disputes': int(open_disputes or 0),
            'revenue_chart': [dict(r) for r in revenue_rows],
            'recent_deals': rows_to_list(recent_deals),
        }
