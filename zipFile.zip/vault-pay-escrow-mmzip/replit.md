# Vault-Pay Escrow

A Telegram escrow/wallet bot with a React admin dashboard.

## Architecture
- **Backend** (port 8000): FastAPI (`server.py` / `main.py`) + python-telegram-bot (`bot.py`), running together via FastAPI's lifespan. PostgreSQL via `DATABASE_URL` (Replit-managed).
- **Frontend** (port 5000): React + Vite admin panel (`src/`, `*.jsx` files), proxies `/api` to the backend on 8000.

## Running
- `Backend` workflow: `uvicorn main:app --host 0.0.0.0 --port 8000 --reload`
- `Start application` workflow: `npm run dev` (Vite on port 5000, shown in the preview pane)

## Secrets / config (see `config.py`)
- `TELEGRAM_BOT_TOKEN`, `TELEGRAM_GROUP_ID`, `TELEGRAM_CHANNEL_ID`, `TELEGRAM_ADMIN_ID` — Telegram bot wiring
- `ADMIN_USERNAME` / `ADMIN_PASSWORD` — web admin login
- `JWT_SECRET` — admin session signing key
- `ADMIN_UPI_ID` / `ADMIN_LTC_ADDRESS` — payout destinations shown to users
- `DATABASE_URL` — Postgres connection (provided automatically by Replit)

## User preferences
- Keep responses efficient; avoid unnecessary iteration/credit use.
