---
name: Vault-Pay Architecture
description: FastAPI+Bot on port 8000 (console), React Vite on port 5000 (webview); PostgreSQL via DATABASE_URL; bot runs inside FastAPI lifespan.
---

- FastAPI (`main.py`) hosts both the admin REST API and the Telegram bot (`bot.py`), started inside its lifespan — port 8000, no visible preview.
- React admin panel (Vite) is the actual preview surface — port 5000, calls `/api/admin/*`.
- `db.py` is the single data-access layer; `ALTER TABLE ADD COLUMN IF NOT EXISTS` in `init_db()` is the pattern for schema migrations (no separate migration tool).
- The AI dispute judge (`ai_judge.py`) is deliberately restricted to `payment_method == 'wallet'` deals only — middleman deals have no on-platform fund trail the AI can verify, and the middleman itself could be the bad actor, so those stay human-only (judge_dispute returns `{"error": "not_wallet_deal"}`).
- Dispute AI judge is a 3-persona jury (strict/contextual/fraud-skeptic) + a chief-justice consolidation pass; jury disagreement or low confidence always escalates to a human regardless of amount, since a single low-temperature model call on repeated context tends to rubber-stamp itself.
- One appeal per dispute is allowed (`/appeal <deal_id>` bot command, 24h window) — it always re-runs the AI for a second opinion but never auto-reverses funds; only a human admin can move money back.
